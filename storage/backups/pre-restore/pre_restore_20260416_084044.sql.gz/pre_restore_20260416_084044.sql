--
-- PostgreSQL database dump
--

\restrict vRruG6uxunnRbxkiAbbBLAb6SzsvpdTIPKfdAB6Bk6aO8KaflsdMYFqVmhVEMzN

-- Dumped from database version 17.9 (Debian 17.9-0+deb13u1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_processing_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_processing_logs (
    id bigint NOT NULL,
    document_id bigint,
    template_id bigint NOT NULL,
    project_id bigint NOT NULL,
    operation_type character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    input_tokens integer,
    output_tokens integer,
    cost numeric(10,6),
    error_message text,
    metadata json,
    initiated_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT ai_processing_logs_operation_type_check CHECK (((operation_type)::text = ANY ((ARRAY['paraphrase'::character varying, 'summarize'::character varying, 'extract'::character varying, 'analyze'::character varying])::text[]))),
    CONSTRAINT ai_processing_logs_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: ai_processing_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_processing_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_processing_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_processing_logs_id_seq OWNED BY public.ai_processing_logs.id;


--
-- Name: ai_query_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_query_logs (
    id bigint NOT NULL,
    client_id bigint,
    kbli_code character varying(10),
    business_context jsonb,
    prompt_text text,
    response_text text,
    tokens_used integer,
    response_time_ms integer,
    status character varying(20) DEFAULT 'success'::character varying NOT NULL,
    error_message text,
    ai_model character varying(100),
    api_cost numeric(10,6),
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: COLUMN ai_query_logs.business_context; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.business_context IS 'Additional context provided by user';


--
-- Name: COLUMN ai_query_logs.response_time_ms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.response_time_ms IS 'Response time in milliseconds';


--
-- Name: COLUMN ai_query_logs.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.status IS 'success, error, timeout';


--
-- Name: COLUMN ai_query_logs.api_cost; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.api_cost IS 'Cost in USD';


--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_query_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_query_logs_id_seq OWNED BY public.ai_query_logs.id;


--
-- Name: ai_setting_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_setting_history (
    id bigint NOT NULL,
    setting_id bigint NOT NULL,
    key character varying(255) NOT NULL,
    old_value text,
    new_value text NOT NULL,
    changed_by_name character varying(255) NOT NULL,
    changed_by bigint NOT NULL,
    reason text,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ai_setting_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_setting_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_setting_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_setting_history_id_seq OWNED BY public.ai_setting_history.id;


--
-- Name: ai_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_settings (
    id bigint NOT NULL,
    category character varying(50) NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    data_type character varying(20) DEFAULT 'string'::character varying NOT NULL,
    description text,
    is_public boolean DEFAULT false NOT NULL,
    is_encrypted boolean DEFAULT false NOT NULL,
    validation_rules json,
    default_value text,
    display_order integer DEFAULT 0 NOT NULL,
    group_name character varying(100),
    requires_restart boolean DEFAULT false NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: COLUMN ai_settings.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.category IS 'global, pricing, rag, prompts, etc';


--
-- Name: COLUMN ai_settings.key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.key IS 'Unique setting key';


--
-- Name: COLUMN ai_settings.value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.value IS 'Setting value (JSON for complex types)';


--
-- Name: COLUMN ai_settings.data_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.data_type IS 'string, number, boolean, json, array';


--
-- Name: COLUMN ai_settings.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.description IS 'Human-readable description';


--
-- Name: COLUMN ai_settings.is_public; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.is_public IS 'Can be exposed to frontend';


--
-- Name: COLUMN ai_settings.is_encrypted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.is_encrypted IS 'Encrypt sensitive data like API keys';


--
-- Name: COLUMN ai_settings.validation_rules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.validation_rules IS 'Laravel validation rules';


--
-- Name: COLUMN ai_settings.default_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.default_value IS 'Default value if not set';


--
-- Name: COLUMN ai_settings.display_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.display_order IS 'Order in UI';


--
-- Name: COLUMN ai_settings.group_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.group_name IS 'UI grouping';


--
-- Name: COLUMN ai_settings.requires_restart; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.requires_restart IS 'Requires system restart';


--
-- Name: ai_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_settings_id_seq OWNED BY public.ai_settings.id;


--
-- Name: application_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_documents (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size bigint,
    mime_type character varying(100),
    is_verified boolean DEFAULT false NOT NULL,
    verified_by bigint,
    verified_at timestamp(0) without time zone,
    verification_notes text,
    uploaded_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    review_notes text,
    CONSTRAINT application_documents_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: application_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: application_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_documents_id_seq OWNED BY public.application_documents.id;


--
-- Name: application_legality_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_legality_documents (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    document_category character varying(255) NOT NULL,
    document_name character varying(200) NOT NULL,
    is_available boolean DEFAULT false NOT NULL,
    document_number character varying(100),
    issued_date date,
    expiry_date date,
    file_path character varying(500),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT application_legality_documents_document_category_check CHECK (((document_category)::text = ANY ((ARRAY['land_ownership'::character varying, 'company_legal'::character varying, 'existing_permits'::character varying, 'power_of_attorney'::character varying, 'technical'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: application_legality_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_legality_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: application_legality_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_legality_documents_id_seq OWNED BY public.application_legality_documents.id;


--
-- Name: application_location_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_location_details (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    province character varying(100),
    city_regency character varying(100),
    district character varying(100),
    sub_district character varying(100),
    full_address text,
    postal_code character varying(10),
    latitude numeric(10,8),
    longitude numeric(11,8),
    zone_type character varying(255),
    land_status character varying(255),
    land_certificate_number character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT application_location_details_land_status_check CHECK (((land_status)::text = ANY ((ARRAY['HGB'::character varying, 'HGU'::character varying, 'Hak_Milik'::character varying, 'Girik'::character varying, 'Sewa'::character varying, 'Other'::character varying])::text[]))),
    CONSTRAINT application_location_details_zone_type_check CHECK (((zone_type)::text = ANY ((ARRAY['industrial'::character varying, 'commercial'::character varying, 'residential'::character varying, 'mixed'::character varying, 'special_economic_zone'::character varying])::text[])))
);


--
-- Name: application_location_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_location_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: application_location_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_location_details_id_seq OWNED BY public.application_location_details.id;


--
-- Name: application_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_notes (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    author_type character varying(255) NOT NULL,
    author_id bigint,
    note text NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: application_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: application_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_notes_id_seq OWNED BY public.application_notes.id;


--
-- Name: application_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_revisions (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    revision_number integer DEFAULT 1 NOT NULL,
    revision_type character varying(255) NOT NULL,
    revision_reason text,
    revised_by_id bigint,
    permits_data jsonb,
    project_data jsonb,
    total_cost numeric(15,2),
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    client_approved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT application_revisions_revision_type_check CHECK (((revision_type)::text = ANY ((ARRAY['technical_adjustment'::character varying, 'client_request'::character varying, 'document_incomplete'::character varying, 'cost_update'::character varying])::text[]))),
    CONSTRAINT application_revisions_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending_client_approval'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: application_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_revisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: application_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_revisions_id_seq OWNED BY public.application_revisions.id;


--
-- Name: application_status_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_status_logs (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    from_status character varying(50),
    to_status character varying(50) NOT NULL,
    notes text,
    changed_by_type character varying(50),
    changed_by_id bigint,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: application_status_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_status_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: application_status_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_status_logs_id_seq OWNED BY public.application_status_logs.id;


--
-- Name: article_topic_similarities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_topic_similarities (
    id bigint NOT NULL,
    topic_a_id bigint NOT NULL,
    topic_b_id bigint NOT NULL,
    similarity_score double precision NOT NULL,
    calculated_at timestamp(0) without time zone NOT NULL
);


--
-- Name: article_topic_similarities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_topic_similarities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: article_topic_similarities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_topic_similarities_id_seq OWNED BY public.article_topic_similarities.id;


--
-- Name: article_topics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_topics (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    category character varying(255) NOT NULL,
    keywords json,
    tags json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    article_id bigint,
    published_at timestamp(0) without time zone,
    scheduled_for timestamp(0) without time zone,
    generation_notes text,
    views_count integer DEFAULT 0 NOT NULL,
    similarity_score double precision,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    language character varying(255) DEFAULT 'id'::character varying NOT NULL,
    target_market character varying(255) DEFAULT 'local'::character varying NOT NULL,
    topic_cluster_id bigint,
    CONSTRAINT article_topics_language_check CHECK (((language)::text = ANY ((ARRAY['id'::character varying, 'en'::character varying])::text[]))),
    CONSTRAINT article_topics_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'published'::character varying, 'failed'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: article_topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: article_topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_topics_id_seq OWNED BY public.article_topics.id;


--
-- Name: article_view_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_view_logs (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    date date NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    unique_views integer DEFAULT 0 NOT NULL,
    top_referrer character varying(255),
    top_country character varying(5),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: article_view_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_view_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: article_view_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_view_logs_id_seq OWNED BY public.article_view_logs.id;


--
-- Name: articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.articles (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    excerpt text,
    content text NOT NULL,
    featured_image character varying(255),
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    tags json,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    views_count integer DEFAULT 0 NOT NULL,
    author_id bigint NOT NULL,
    meta_title character varying(255),
    meta_description text,
    meta_keywords character varying(255),
    is_featured boolean DEFAULT false NOT NULL,
    reading_time integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    source_type character varying(255) DEFAULT 'manual'::character varying NOT NULL,
    language character varying(2) DEFAULT 'id'::character varying NOT NULL,
    topic_cluster_id bigint,
    CONSTRAINT articles_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: auto_post_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_post_configs (
    id bigint NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    posts_per_day integer DEFAULT 3 NOT NULL,
    post_times json NOT NULL,
    timezone character varying(255) DEFAULT 'Asia/Jakarta'::character varying NOT NULL,
    ai_model character varying(255) DEFAULT 'anthropic/claude-3.5-sonnet'::character varying NOT NULL,
    min_word_count integer DEFAULT 800 NOT NULL,
    max_word_count integer DEFAULT 1500 NOT NULL,
    min_reading_time integer DEFAULT 4 NOT NULL,
    max_reading_time integer DEFAULT 8 NOT NULL,
    min_headings integer DEFAULT 3 NOT NULL,
    max_headings integer DEFAULT 6 NOT NULL,
    min_paragraphs integer DEFAULT 5 NOT NULL,
    internal_links_count integer DEFAULT 3 NOT NULL,
    include_featured_image boolean DEFAULT true NOT NULL,
    auto_publish boolean DEFAULT false NOT NULL,
    duplicate_threshold double precision DEFAULT '0.75'::double precision NOT NULL,
    cooldown_days integer DEFAULT 30 NOT NULL,
    excluded_keywords json,
    category_weights json NOT NULL,
    daily_limit integer DEFAULT 5 NOT NULL,
    retry_attempts integer DEFAULT 3 NOT NULL,
    timeout_seconds integer DEFAULT 120 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    language_distribution json,
    market_focus json
);


--
-- Name: auto_post_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_post_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auto_post_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_post_configs_id_seq OWNED BY public.auto_post_configs.id;


--
-- Name: auto_post_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_post_logs (
    id bigint NOT NULL,
    schedule_id bigint,
    article_id bigint,
    topic_id bigint,
    level character varying(255) DEFAULT 'info'::character varying NOT NULL,
    event character varying(255) NOT NULL,
    message text NOT NULL,
    context json,
    word_count integer,
    reading_time integer,
    internal_links integer,
    ai_cost double precision,
    created_at timestamp(0) without time zone NOT NULL,
    CONSTRAINT auto_post_logs_level_check CHECK (((level)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'error'::character varying, 'success'::character varying])::text[])))
);


--
-- Name: auto_post_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_post_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auto_post_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_post_logs_id_seq OWNED BY public.auto_post_logs.id;


--
-- Name: auto_post_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_post_schedules (
    id bigint NOT NULL,
    topic_id bigint NOT NULL,
    scheduled_at timestamp(0) without time zone NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    error_message text,
    attempts integer DEFAULT 0 NOT NULL,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    generation_time_seconds integer,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    article_id bigint,
    CONSTRAINT auto_post_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: auto_post_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_post_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auto_post_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_post_schedules_id_seq OWNED BY public.auto_post_schedules.id;


--
-- Name: bank_reconciliations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_reconciliations (
    id bigint NOT NULL,
    cash_account_id bigint NOT NULL,
    reconciliation_date date NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    opening_balance_book numeric(15,2) NOT NULL,
    opening_balance_bank numeric(15,2) NOT NULL,
    closing_balance_book numeric(15,2) NOT NULL,
    closing_balance_bank numeric(15,2) NOT NULL,
    total_deposits_in_transit numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_outstanding_checks numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_bank_charges numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_bank_credits numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    adjusted_bank_balance numeric(15,2) NOT NULL,
    adjusted_book_balance numeric(15,2) NOT NULL,
    difference numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    status character varying(255) DEFAULT 'in_progress'::character varying NOT NULL,
    bank_statement_file character varying(255),
    bank_statement_format character varying(50),
    notes text,
    reconciled_by bigint,
    reviewed_by bigint,
    approved_by bigint,
    completed_at timestamp(0) without time zone,
    reviewed_at timestamp(0) without time zone,
    approved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT bank_reconciliations_status_check CHECK (((status)::text = ANY ((ARRAY['in_progress'::character varying, 'completed'::character varying, 'reviewed'::character varying, 'approved'::character varying])::text[])))
);


--
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_reconciliations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_reconciliations_id_seq OWNED BY public.bank_reconciliations.id;


--
-- Name: bank_statement_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_statement_entries (
    id bigint NOT NULL,
    reconciliation_id bigint NOT NULL,
    transaction_date date NOT NULL,
    description text NOT NULL,
    debit_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    credit_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    running_balance numeric(15,2) NOT NULL,
    reference_number character varying(100),
    is_matched boolean DEFAULT false NOT NULL,
    matched_transaction_type character varying(255),
    matched_transaction_id bigint,
    match_confidence character varying(255),
    match_notes text,
    unmatch_reason character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT bank_statement_entries_match_confidence_check CHECK (((match_confidence)::text = ANY ((ARRAY['exact'::character varying, 'fuzzy'::character varying, 'manual'::character varying])::text[]))),
    CONSTRAINT bank_statement_entries_matched_transaction_type_check CHECK (((matched_transaction_type)::text = ANY ((ARRAY['payment'::character varying, 'expense'::character varying, 'invoice_payment'::character varying])::text[]))),
    CONSTRAINT bank_statement_entries_unmatch_reason_check CHECK (((unmatch_reason)::text = ANY ((ARRAY['missing_in_system'::character varying, 'bank_error'::character varying, 'timing_difference'::character varying, 'needs_investigation'::character varying])::text[])))
);


--
-- Name: bank_statement_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_statement_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_statement_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_statement_entries_id_seq OWNED BY public.bank_statement_entries.id;


--
-- Name: business_contexts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_contexts (
    id bigint NOT NULL,
    client_id bigint,
    kbli_code character varying(10) NOT NULL,
    land_area numeric(12,2),
    building_area numeric(12,2),
    number_of_floors integer,
    investment_value numeric(20,2),
    province character varying(100),
    city character varying(100),
    district character varying(100),
    zone_type character varying(255),
    coordinates character varying(100),
    location_category character varying(255),
    number_of_employees integer,
    production_capacity character varying(100),
    annual_revenue_target numeric(20,2),
    business_scale character varying(255),
    environmental_impact character varying(255) DEFAULT 'low'::character varying NOT NULL,
    waste_management character varying(255),
    near_protected_area boolean DEFAULT false NOT NULL,
    environmental_notes text,
    ownership_status character varying(255),
    existing_permits json,
    urgency_level character varying(255) DEFAULT 'standard'::character varying NOT NULL,
    additional_notes text,
    custom_fields json,
    ip_address character varying(45),
    user_agent character varying(255),
    submitted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT business_contexts_business_scale_check CHECK (((business_scale)::text = ANY ((ARRAY['mikro'::character varying, 'kecil'::character varying, 'menengah'::character varying, 'besar'::character varying])::text[]))),
    CONSTRAINT business_contexts_environmental_impact_check CHECK (((environmental_impact)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[]))),
    CONSTRAINT business_contexts_location_category_check CHECK (((location_category)::text = ANY ((ARRAY['perkotaan'::character varying, 'pedesaan'::character varying, 'kawasan_industri'::character varying])::text[]))),
    CONSTRAINT business_contexts_ownership_status_check CHECK (((ownership_status)::text = ANY ((ARRAY['owned'::character varying, 'leased'::character varying, 'partnership'::character varying])::text[]))),
    CONSTRAINT business_contexts_urgency_level_check CHECK (((urgency_level)::text = ANY ((ARRAY['standard'::character varying, 'rush'::character varying])::text[]))),
    CONSTRAINT business_contexts_waste_management_check CHECK (((waste_management)::text = ANY ((ARRAY['minimal'::character varying, 'standard'::character varying, 'complex'::character varying])::text[]))),
    CONSTRAINT business_contexts_zone_type_check CHECK (((zone_type)::text = ANY ((ARRAY['residential'::character varying, 'commercial'::character varying, 'industrial'::character varying, 'mixed'::character varying, 'special'::character varying])::text[])))
);


--
-- Name: COLUMN business_contexts.land_area; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.land_area IS 'Land area in m²';


--
-- Name: COLUMN business_contexts.building_area; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.building_area IS 'Building area in m²';


--
-- Name: COLUMN business_contexts.investment_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.investment_value IS 'Investment value in Rupiah';


--
-- Name: COLUMN business_contexts.coordinates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.coordinates IS 'Lat,Long';


--
-- Name: COLUMN business_contexts.annual_revenue_target; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.annual_revenue_target IS 'Annual revenue in Rupiah';


--
-- Name: COLUMN business_contexts.existing_permits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.existing_permits IS 'List of permits already owned';


--
-- Name: COLUMN business_contexts.custom_fields; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.custom_fields IS 'Flexible storage for KBLI-specific data';


--
-- Name: business_contexts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.business_contexts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: business_contexts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.business_contexts_id_seq OWNED BY public.business_contexts.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: cash_account_balance_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_account_balance_history (
    id bigint NOT NULL,
    cash_account_id bigint NOT NULL,
    old_balance numeric(15,2) NOT NULL,
    new_balance numeric(15,2) NOT NULL,
    change_amount numeric(15,2) NOT NULL,
    change_type character varying(50) NOT NULL,
    reference_id bigint,
    reference_type character varying(100),
    description text,
    changed_by bigint,
    changed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: COLUMN cash_account_balance_history.old_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.old_balance IS 'Saldo sebelum perubahan';


--
-- Name: COLUMN cash_account_balance_history.new_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.new_balance IS 'Saldo setelah perubahan';


--
-- Name: COLUMN cash_account_balance_history.change_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.change_amount IS 'Selisih perubahan (+ untuk income, - untuk expense)';


--
-- Name: COLUMN cash_account_balance_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.change_type IS 'Tipe perubahan: income, expense, adjustment, reconciliation, recalculation';


--
-- Name: COLUMN cash_account_balance_history.reference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.reference_id IS 'ID transaksi terkait';


--
-- Name: COLUMN cash_account_balance_history.reference_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.reference_type IS 'Model class: ProjectPayment, ProjectExpense, etc';


--
-- Name: COLUMN cash_account_balance_history.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.description IS 'Deskripsi perubahan';


--
-- Name: COLUMN cash_account_balance_history.changed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.changed_at IS 'Waktu perubahan terjadi';


--
-- Name: cash_account_balance_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cash_account_balance_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cash_account_balance_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cash_account_balance_history_id_seq OWNED BY public.cash_account_balance_history.id;


--
-- Name: cash_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_accounts (
    id bigint NOT NULL,
    account_name character varying(100) NOT NULL,
    account_type character varying(255) DEFAULT 'bank'::character varying NOT NULL,
    account_number character varying(50),
    bank_name character varying(100),
    account_holder character varying(255),
    current_balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    initial_balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT cash_accounts_account_type_check CHECK (((account_type)::text = ANY ((ARRAY['bank'::character varying, 'cash'::character varying, 'receivable'::character varying, 'payable'::character varying])::text[])))
);


--
-- Name: COLUMN cash_accounts.account_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.account_name IS 'Nama akun (Bank BTN, Cash, dll)';


--
-- Name: COLUMN cash_accounts.account_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.account_number IS 'Nomor rekening';


--
-- Name: COLUMN cash_accounts.bank_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.bank_name IS 'Nama bank';


--
-- Name: COLUMN cash_accounts.account_holder; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.account_holder IS 'Nama pemilik rekening';


--
-- Name: COLUMN cash_accounts.current_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.current_balance IS 'Saldo saat ini';


--
-- Name: COLUMN cash_accounts.initial_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.initial_balance IS 'Saldo awal';


--
-- Name: cash_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cash_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cash_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cash_accounts_id_seq OWNED BY public.cash_accounts.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    company_name character varying(255),
    industry character varying(255),
    contact_person character varying(255),
    email character varying(255),
    phone character varying(255),
    mobile character varying(255),
    address text,
    city character varying(255),
    province character varying(255),
    postal_code character varying(255),
    npwp character varying(255),
    tax_name character varying(255),
    tax_address text,
    client_type character varying(255) DEFAULT 'company'::character varying NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    password character varying(255),
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100),
    profile_picture character varying(255),
    CONSTRAINT clients_client_type_check CHECK (((client_type)::text = ANY ((ARRAY['individual'::character varying, 'company'::character varying, 'government'::character varying])::text[]))),
    CONSTRAINT clients_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'potential'::character varying])::text[])))
);


--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: competitor_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitor_analyses (
    id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    our_url character varying(255),
    our_position integer,
    top_competitors json,
    content_gaps json,
    recommendations json,
    search_volume integer,
    difficulty character varying(255),
    analyzed_at date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    data_source character varying(20) DEFAULT 'ai_estimated'::character varying NOT NULL
);


--
-- Name: competitor_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.competitor_analyses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: competitor_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.competitor_analyses_id_seq OWNED BY public.competitor_analyses.id;


--
-- Name: compliance_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_checks (
    id bigint NOT NULL,
    draft_id bigint NOT NULL,
    document_type character varying(255) DEFAULT 'UKL-UPL'::character varying NOT NULL,
    overall_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    structure_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    compliance_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    formatting_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    completeness_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    issues jsonb,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    error_message text,
    total_issues integer DEFAULT 0 NOT NULL,
    critical_issues integer DEFAULT 0 NOT NULL,
    warning_issues integer DEFAULT 0 NOT NULL,
    info_issues integer DEFAULT 0 NOT NULL,
    checked_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: compliance_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_checks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_checks_id_seq OWNED BY public.compliance_checks.id;


--
-- Name: consult_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consult_requests (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(20) NOT NULL,
    company_name character varying(255),
    kbli_code character varying(10) NOT NULL,
    business_size character varying(255) DEFAULT 'small'::character varying NOT NULL,
    location character varying(255),
    location_type character varying(255) DEFAULT 'commercial'::character varying NOT NULL,
    investment_level character varying(255) DEFAULT 'under_100m'::character varying NOT NULL,
    employee_count integer DEFAULT 0 NOT NULL,
    project_description text NOT NULL,
    deliverables_requested jsonb,
    estimate_status character varying(255) DEFAULT 'auto_estimated'::character varying NOT NULL,
    auto_estimate jsonb,
    final_quote jsonb,
    confidence_score numeric(3,2),
    admin_notes text,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    contacted boolean DEFAULT false NOT NULL,
    contacted_at timestamp(0) without time zone,
    converted_to_client boolean DEFAULT false NOT NULL,
    client_id bigint,
    ip_address character varying(45),
    user_agent character varying(255),
    referrer_url character varying(255),
    utm_params jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    rag_insights jsonb,
    rag_confidence numeric(3,2),
    rag_processed_at timestamp(0) without time zone,
    CONSTRAINT consult_requests_business_size_check CHECK (((business_size)::text = ANY ((ARRAY['micro'::character varying, 'small'::character varying, 'medium'::character varying, 'large'::character varying])::text[]))),
    CONSTRAINT consult_requests_estimate_status_check CHECK (((estimate_status)::text = ANY ((ARRAY['pending'::character varying, 'auto_estimated'::character varying, 'reviewed'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT consult_requests_investment_level_check CHECK (((investment_level)::text = ANY ((ARRAY['under_100m'::character varying, '100m_500m'::character varying, '500m_2b'::character varying, 'over_2b'::character varying])::text[]))),
    CONSTRAINT consult_requests_location_type_check CHECK (((location_type)::text = ANY ((ARRAY['industrial'::character varying, 'commercial'::character varying, 'residential'::character varying, 'rural'::character varying])::text[])))
);


--
-- Name: consult_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.consult_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consult_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.consult_requests_id_seq OWNED BY public.consult_requests.id;


--
-- Name: content_gaps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_gaps (
    id bigint NOT NULL,
    suggested_title character varying(255) NOT NULL,
    suggested_slug character varying(255) NOT NULL,
    description text NOT NULL,
    target_keyword character varying(255) NOT NULL,
    search_intent character varying(255) DEFAULT 'informational'::character varying NOT NULL,
    category character varying(255),
    service_slug character varying(255),
    language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    article_topic_id bigint,
    topic_cluster_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: content_gaps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_gaps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_gaps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_gaps_id_seq OWNED BY public.content_gaps.id;


--
-- Name: content_refresh_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_refresh_logs (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    status character varying(255) NOT NULL,
    changes json,
    before_snapshot json,
    after_snapshot json,
    error_message text,
    triggered_by character varying(255) DEFAULT 'cron'::character varying NOT NULL,
    ai_tokens_used integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: content_refresh_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_refresh_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_refresh_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_refresh_logs_id_seq OWNED BY public.content_refresh_logs.id;


--
-- Name: content_syndications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_syndications (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    platform character varying(255) NOT NULL,
    platform_url character varying(255),
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    metrics json,
    error_message text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: content_syndications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_syndications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_syndications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_syndications_id_seq OWNED BY public.content_syndications.id;


--
-- Name: document_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_drafts (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    template_id bigint NOT NULL,
    ai_log_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    sections json,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    created_by bigint NOT NULL,
    approved_at timestamp(0) without time zone,
    approved_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT document_drafts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'reviewed'::character varying, 'approved'::character varying, 'rejected'::character varying, 'exported'::character varying])::text[])))
);


--
-- Name: document_drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_drafts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_drafts_id_seq OWNED BY public.document_drafts.id;


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    permit_type character varying(255) NOT NULL,
    description text,
    file_name character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(50) NOT NULL,
    page_count smallint,
    required_fields json,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT document_templates_permit_type_check CHECK (((permit_type)::text = ANY ((ARRAY['pertek_bpn'::character varying, 'ukl_upl'::character varying, 'amdal'::character varying, 'imb'::character varying, 'pbg'::character varying, 'slf'::character varying, 'siup'::character varying, 'tdp'::character varying, 'npwp'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: document_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_templates_id_seq OWNED BY public.document_templates.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    task_id bigint,
    title character varying(255) NOT NULL,
    description text,
    category character varying(255) NOT NULL,
    document_type character varying(255),
    file_name character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    file_size character varying(255),
    mime_type character varying(255),
    version character varying(10) DEFAULT '1.0'::character varying NOT NULL,
    parent_document_id bigint,
    is_latest_version boolean DEFAULT true NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    document_date date,
    submission_date date,
    approval_date date,
    uploaded_by bigint NOT NULL,
    is_confidential boolean DEFAULT false NOT NULL,
    access_permissions json,
    notes text,
    download_count integer DEFAULT 0 NOT NULL,
    last_accessed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT documents_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'review'::character varying, 'approved'::character varying, 'submitted'::character varying, 'final'::character varying])::text[])))
);


--
-- Name: COLUMN documents.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.documents.category IS 'proposal, kontrak, kajian, surat, sk, dll';


--
-- Name: COLUMN documents.document_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.documents.document_type IS 'PDF, DOC, XLS, etc';


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: email_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_accounts (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) DEFAULT 'shared'::character varying NOT NULL,
    department character varying(255) DEFAULT 'general'::character varying NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    auto_reply_enabled boolean DEFAULT false NOT NULL,
    auto_reply_message text,
    signature text,
    assigned_users json,
    total_received integer DEFAULT 0 NOT NULL,
    total_sent integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT email_accounts_department_check CHECK (((department)::text = ANY ((ARRAY['general'::character varying, 'cs'::character varying, 'sales'::character varying, 'support'::character varying, 'finance'::character varying, 'technical'::character varying])::text[]))),
    CONSTRAINT email_accounts_type_check CHECK (((type)::text = ANY ((ARRAY['shared'::character varying, 'personal'::character varying])::text[])))
);


--
-- Name: email_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_accounts_id_seq OWNED BY public.email_accounts.id;


--
-- Name: email_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_assignments (
    id bigint NOT NULL,
    email_account_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(255) DEFAULT 'primary'::character varying NOT NULL,
    can_send boolean DEFAULT true NOT NULL,
    can_receive boolean DEFAULT true NOT NULL,
    can_delete boolean DEFAULT false NOT NULL,
    can_assign_others boolean DEFAULT false NOT NULL,
    notify_on_receive boolean DEFAULT true NOT NULL,
    notify_on_reply boolean DEFAULT false NOT NULL,
    notify_on_mention boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    assigned_by bigint,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_assignments_role_check CHECK (((role)::text = ANY ((ARRAY['primary'::character varying, 'backup'::character varying, 'viewer'::character varying])::text[])))
);


--
-- Name: email_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_assignments_id_seq OWNED BY public.email_assignments.id;


--
-- Name: email_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_campaigns (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    template_id bigint,
    content text NOT NULL,
    plain_content text,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    recipient_type character varying(255) DEFAULT 'all'::character varying NOT NULL,
    recipient_tags json,
    scheduled_at timestamp(0) without time zone,
    sent_at timestamp(0) without time zone,
    total_recipients integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    opened_count integer DEFAULT 0 NOT NULL,
    clicked_count integer DEFAULT 0 NOT NULL,
    bounced_count integer DEFAULT 0 NOT NULL,
    unsubscribed_count integer DEFAULT 0 NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_campaigns_recipient_type_check CHECK (((recipient_type)::text = ANY ((ARRAY['all'::character varying, 'active'::character varying, 'tags'::character varying])::text[]))),
    CONSTRAINT email_campaigns_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'sending'::character varying, 'sent'::character varying, 'paused'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: email_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_campaigns_id_seq OWNED BY public.email_campaigns.id;


--
-- Name: email_inbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_inbox (
    id bigint NOT NULL,
    message_id character varying(255) NOT NULL,
    from_email character varying(255) NOT NULL,
    from_name character varying(255),
    to_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    body_html text,
    body_text text,
    attachments json,
    is_read boolean DEFAULT false NOT NULL,
    is_starred boolean DEFAULT false NOT NULL,
    category character varying(255) DEFAULT 'inbox'::character varying NOT NULL,
    labels json,
    replied_to bigint,
    assigned_to bigint,
    received_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    email_account_id bigint,
    department character varying(255),
    priority character varying(255) DEFAULT 'normal'::character varying NOT NULL,
    status character varying(255) DEFAULT 'new'::character varying NOT NULL,
    first_responded_at timestamp(0) without time zone,
    resolved_at timestamp(0) without time zone,
    response_time_minutes integer,
    resolution_time_minutes integer,
    handled_by bigint,
    tags json,
    internal_notes text,
    sentiment character varying(255),
    CONSTRAINT email_inbox_category_check CHECK (((category)::text = ANY ((ARRAY['inbox'::character varying, 'sent'::character varying, 'trash'::character varying, 'spam'::character varying])::text[]))),
    CONSTRAINT email_inbox_department_check CHECK (((department)::text = ANY ((ARRAY['general'::character varying, 'cs'::character varying, 'sales'::character varying, 'support'::character varying, 'finance'::character varying, 'technical'::character varying])::text[]))),
    CONSTRAINT email_inbox_priority_check CHECK (((priority)::text = ANY ((ARRAY['urgent'::character varying, 'high'::character varying, 'normal'::character varying, 'low'::character varying])::text[]))),
    CONSTRAINT email_inbox_sentiment_check CHECK (((sentiment)::text = ANY ((ARRAY['positive'::character varying, 'neutral'::character varying, 'negative'::character varying])::text[]))),
    CONSTRAINT email_inbox_status_check CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'open'::character varying, 'pending'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: email_inbox_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_inbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_inbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_inbox_id_seq OWNED BY public.email_inbox.id;


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id bigint NOT NULL,
    campaign_id bigint,
    subscriber_id bigint,
    recipient_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'sent'::character varying NOT NULL,
    sent_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    opened_at timestamp(0) without time zone,
    clicked_at timestamp(0) without time zone,
    bounced_at timestamp(0) without time zone,
    tracking_id character varying(255),
    error_message character varying(255),
    ip_address character varying(255),
    user_agent character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_logs_status_check CHECK (((status)::text = ANY ((ARRAY['sent'::character varying, 'delivered'::character varying, 'opened'::character varying, 'clicked'::character varying, 'bounced'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;


--
-- Name: email_subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_subscribers (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    phone character varying(255),
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    source character varying(255),
    tags json,
    custom_fields json,
    subscribed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    unsubscribed_at timestamp(0) without time zone,
    unsubscribe_reason character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_subscribers_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'unsubscribed'::character varying, 'bounced'::character varying])::text[])))
);


--
-- Name: email_subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_subscribers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_subscribers_id_seq OWNED BY public.email_subscribers.id;


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_templates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    content text NOT NULL,
    plain_content text,
    thumbnail character varying(255),
    category character varying(255) DEFAULT 'newsletter'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    variables json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_templates_category_check CHECK (((category)::text = ANY ((ARRAY['newsletter'::character varying, 'promotional'::character varying, 'transactional'::character varying, 'announcement'::character varying])::text[])))
);


--
-- Name: email_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_templates_id_seq OWNED BY public.email_templates.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expense_categories (
    id bigint NOT NULL,
    slug character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "group" character varying(255),
    icon character varying(255),
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expense_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: institutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institutions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    address text,
    phone character varying(255),
    email character varying(255),
    contact_person character varying(255),
    contact_position character varying(255),
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: COLUMN institutions.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.institutions.type IS 'DLH, BPN, OSS, Notaris, dll';


--
-- Name: institutions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.institutions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: institutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.institutions_id_seq OWNED BY public.institutions.id;


--
-- Name: interview_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interview_feedback (
    id bigint NOT NULL,
    interview_schedule_id bigint NOT NULL,
    interviewer_id bigint NOT NULL,
    technical_skills smallint,
    communication smallint,
    problem_solving smallint,
    cultural_fit smallint,
    motivation smallint,
    overall_rating numeric(3,1),
    strengths text,
    weaknesses text,
    detailed_notes text,
    recommendation character varying(255) NOT NULL,
    submitted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT interview_feedback_recommendation_check CHECK (((recommendation)::text = ANY ((ARRAY['strong-hire'::character varying, 'hire'::character varying, 'maybe'::character varying, 'no-hire'::character varying])::text[])))
);


--
-- Name: COLUMN interview_feedback.technical_skills; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.technical_skills IS '1-10 rating';


--
-- Name: COLUMN interview_feedback.communication; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.communication IS '1-10 rating';


--
-- Name: COLUMN interview_feedback.problem_solving; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.problem_solving IS '1-10 rating';


--
-- Name: COLUMN interview_feedback.cultural_fit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.cultural_fit IS '1-10 rating';


--
-- Name: COLUMN interview_feedback.motivation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.motivation IS '1-10 rating';


--
-- Name: COLUMN interview_feedback.overall_rating; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.overall_rating IS 'Average score';


--
-- Name: interview_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interview_feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: interview_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interview_feedback_id_seq OWNED BY public.interview_feedback.id;


--
-- Name: interview_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interview_schedules (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    interview_type character varying(255) DEFAULT 'preliminary'::character varying NOT NULL,
    interview_stage smallint DEFAULT '1'::smallint NOT NULL,
    scheduled_at timestamp(0) without time zone NOT NULL,
    duration_minutes integer DEFAULT 60 NOT NULL,
    location character varying(255),
    meeting_type character varying(255) DEFAULT 'video-call'::character varying NOT NULL,
    meeting_link text,
    meeting_password character varying(255),
    interviewer_ids json,
    status character varying(255) DEFAULT 'scheduled'::character varying NOT NULL,
    notes text,
    reminder_sent_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    recruitment_stage_id bigint,
    CONSTRAINT interview_schedules_interview_type_check CHECK (((interview_type)::text = ANY ((ARRAY['preliminary'::character varying, 'technical'::character varying, 'hr'::character varying, 'final'::character varying])::text[]))),
    CONSTRAINT interview_schedules_meeting_type_check CHECK (((meeting_type)::text = ANY ((ARRAY['in-person'::character varying, 'video-call'::character varying, 'phone'::character varying])::text[]))),
    CONSTRAINT interview_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['scheduled'::character varying, 'confirmed'::character varying, 'rescheduled'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'no-show'::character varying])::text[])))
);


--
-- Name: COLUMN interview_schedules.interview_stage; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.interview_stage IS 'Stage number in sequence';


--
-- Name: COLUMN interview_schedules.location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.location IS 'online, office, or specific address';


--
-- Name: COLUMN interview_schedules.meeting_link; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.meeting_link IS 'Zoom/Jitsi meeting URL';


--
-- Name: COLUMN interview_schedules.interviewer_ids; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.interviewer_ids IS 'Array of user IDs';


--
-- Name: interview_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interview_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: interview_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interview_schedules_id_seq OWNED BY public.interview_schedules.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_items (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    description character varying(255) NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    invoice_number character varying(255) NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    subtotal numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    paid_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    remaining_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    notes text,
    client_name character varying(255),
    client_address text,
    client_tax_id character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'sent'::character varying, 'partial'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: job_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_applications (
    id bigint NOT NULL,
    job_vacancy_id bigint NOT NULL,
    full_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    birth_date date,
    gender character varying(255),
    address text,
    education_level character varying(255) NOT NULL,
    major character varying(255) NOT NULL,
    institution character varying(255) NOT NULL,
    graduation_year integer,
    gpa numeric(3,2),
    work_experience text,
    has_experience_ukl_upl boolean DEFAULT false NOT NULL,
    skills text,
    cv_path character varying(255),
    portfolio_path character varying(255),
    cover_letter text,
    expected_salary integer,
    available_from date,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    notes text,
    reviewed_at timestamp(0) without time zone,
    reviewed_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT job_applications_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'reviewed'::character varying, 'interview'::character varying, 'accepted'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: job_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_applications_id_seq OWNED BY public.job_applications.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- Name: job_vacancies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_vacancies (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    "position" character varying(255) NOT NULL,
    description text NOT NULL,
    responsibilities text NOT NULL,
    qualifications text NOT NULL,
    benefits text,
    employment_type character varying(255) DEFAULT 'full-time'::character varying NOT NULL,
    location character varying(255) DEFAULT 'Jakarta'::character varying NOT NULL,
    salary_min integer,
    salary_max integer,
    salary_negotiable boolean DEFAULT true NOT NULL,
    deadline date,
    status character varying(255) DEFAULT 'open'::character varying NOT NULL,
    google_form_url character varying(255),
    applications_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT job_vacancies_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'closed'::character varying, 'draft'::character varying])::text[])))
);


--
-- Name: job_vacancies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_vacancies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_vacancies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_vacancies_id_seq OWNED BY public.job_vacancies.id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: kbli; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kbli (
    id bigint NOT NULL,
    code character varying(10) NOT NULL,
    description text NOT NULL,
    sector character varying(1) NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    category character varying(255),
    activities text,
    examples text,
    complexity_level character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    default_direct_costs jsonb,
    default_hours_estimate jsonb,
    default_hourly_rates jsonb,
    regulatory_flags jsonb,
    recommended_services jsonb,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT kbli_complexity_level_check CHECK (((complexity_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])))
);


--
-- Name: COLUMN kbli.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.code IS 'KBLI code (e.g., 62010)';


--
-- Name: COLUMN kbli.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.description IS 'Business activity description';


--
-- Name: COLUMN kbli.sector; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.sector IS 'Business sector (A-U)';


--
-- Name: COLUMN kbli.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.notes IS 'Additional notes or clarifications';


--
-- Name: COLUMN kbli.default_direct_costs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.default_direct_costs IS 'Direct costs: {"printing": 200000, "lab_tests": 0, "permits": 500000}';


--
-- Name: COLUMN kbli.default_hours_estimate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.default_hours_estimate IS 'Hours by role: {"admin": 2, "technical": 16, "review": 4, "field": 8}';


--
-- Name: COLUMN kbli.default_hourly_rates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.default_hourly_rates IS 'Rates by role: {"admin": 100000, "technical": 200000, "review": 150000, "field": 175000}';


--
-- Name: COLUMN kbli.regulatory_flags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.regulatory_flags IS 'Flags: ["requires_permit", "environmental_assessment", "amdal_required"]';


--
-- Name: COLUMN kbli.recommended_services; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.recommended_services IS 'Services: [{"name": "UKL/UPL", "priority": "required"}, ...]';


--
-- Name: kbli_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kbli_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kbli_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kbli_id_seq OWNED BY public.kbli.id;


--
-- Name: kbli_permit_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kbli_permit_recommendations (
    id bigint NOT NULL,
    kbli_code character varying(10) NOT NULL,
    business_scale character varying(50),
    location_type character varying(50),
    recommended_permits jsonb NOT NULL,
    required_documents jsonb NOT NULL,
    risk_assessment jsonb,
    estimated_timeline jsonb,
    additional_notes text,
    ai_model character varying(100),
    ai_prompt_hash character varying(64),
    confidence_score numeric(3,2),
    cache_hits integer DEFAULT 0 NOT NULL,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: COLUMN kbli_permit_recommendations.business_scale; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.business_scale IS 'micro, small, medium, large';


--
-- Name: COLUMN kbli_permit_recommendations.location_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.location_type IS 'urban, rural, industrial_zone';


--
-- Name: COLUMN kbli_permit_recommendations.recommended_permits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.recommended_permits IS 'Array of permit objects with details';


--
-- Name: COLUMN kbli_permit_recommendations.required_documents; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.required_documents IS 'Documents needed per permit';


--
-- Name: COLUMN kbli_permit_recommendations.risk_assessment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.risk_assessment IS 'Risk level and considerations';


--
-- Name: COLUMN kbli_permit_recommendations.estimated_timeline; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.estimated_timeline IS 'Processing time per permit';


--
-- Name: COLUMN kbli_permit_recommendations.ai_prompt_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.ai_prompt_hash IS 'Track if prompt changed';


--
-- Name: kbli_permit_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kbli_permit_recommendations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kbli_permit_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kbli_permit_recommendations_id_seq OWNED BY public.kbli_permit_recommendations.id;


--
-- Name: kblis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kblis (
    id bigint NOT NULL,
    code character varying(10) NOT NULL,
    title character varying(255) NOT NULL,
    category character varying(255) NOT NULL,
    description text,
    activities text,
    complexity_level character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    default_direct_costs json,
    default_hours_estimate json,
    default_hourly_rates json,
    regulatory_flags json,
    recommended_services json,
    examples text,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT kblis_complexity_level_check CHECK (((complexity_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])))
);


--
-- Name: kblis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kblis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kblis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kblis_id_seq OWNED BY public.kblis.id;


--
-- Name: keyword_clusters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keyword_clusters (
    id bigint NOT NULL,
    seed_keyword character varying(255) NOT NULL,
    cluster_name character varying(255) NOT NULL,
    search_intent character varying(255) DEFAULT 'informational'::character varying NOT NULL,
    keywords json NOT NULL,
    long_tail_keywords json,
    language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    category character varying(255),
    service_slug character varying(255),
    estimated_volume integer DEFAULT 0 NOT NULL,
    difficulty_score integer DEFAULT 0 NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    articles_count integer DEFAULT 0 NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    last_researched_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    gsc_clicks integer,
    gsc_impressions integer,
    gsc_avg_position numeric(5,1),
    gsc_ctr numeric(5,2),
    gsc_synced_at timestamp(0) without time zone
);


--
-- Name: COLUMN keyword_clusters.gsc_clicks; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_clicks IS 'Real total clicks from GSC in last sync window';


--
-- Name: COLUMN keyword_clusters.gsc_impressions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_impressions IS 'Real total impressions from GSC in last sync window';


--
-- Name: COLUMN keyword_clusters.gsc_avg_position; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_avg_position IS 'Real average SERP position from GSC';


--
-- Name: COLUMN keyword_clusters.gsc_ctr; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_ctr IS 'Real average CTR (%) from GSC';


--
-- Name: COLUMN keyword_clusters.gsc_synced_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_synced_at IS 'When GSC data was last synced for this cluster';


--
-- Name: keyword_clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.keyword_clusters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: keyword_clusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.keyword_clusters_id_seq OWNED BY public.keyword_clusters.id;


--
-- Name: keyword_position_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keyword_position_history (
    id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    our_url character varying(255),
    "position" smallint,
    previous_position smallint,
    position_change smallint DEFAULT '0'::smallint NOT NULL,
    data_source character varying(255) DEFAULT 'searxng'::character varying NOT NULL,
    top_competitors json,
    search_volume integer,
    search_intent character varying(255),
    tracked_at date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: keyword_position_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.keyword_position_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: keyword_position_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.keyword_position_history_id_seq OWNED BY public.keyword_position_history.id;


--
-- Name: meta_ab_tests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meta_ab_tests (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    test_type character varying(255) NOT NULL,
    variant_a_title character varying(255),
    variant_a_description character varying(255),
    variant_b_title character varying(255),
    variant_b_description character varying(255),
    variant_a_impressions integer DEFAULT 0 NOT NULL,
    variant_a_clicks integer DEFAULT 0 NOT NULL,
    variant_b_impressions integer DEFAULT 0 NOT NULL,
    variant_b_clicks integer DEFAULT 0 NOT NULL,
    winner character varying(255),
    confidence numeric(5,2),
    status character varying(255) DEFAULT 'running'::character varying NOT NULL,
    started_at timestamp(0) without time zone NOT NULL,
    ended_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: meta_ab_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meta_ab_tests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meta_ab_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meta_ab_tests_id_seq OWNED BY public.meta_ab_tests.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.milestones (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.milestones_id_seq OWNED BY public.milestones.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    notifiable_type character varying(50) NOT NULL,
    notifiable_id bigint NOT NULL,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    icon character varying(50),
    related_type character varying(50),
    related_id bigint,
    action_url character varying(500),
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    data text
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    requires_cash_account boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- Name: payment_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_schedules (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    invoice_id bigint,
    description character varying(255) NOT NULL,
    amount numeric(15,2) NOT NULL,
    due_date date NOT NULL,
    paid_date date,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    payment_method character varying(255),
    reference_number character varying(255),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_reconciled boolean DEFAULT false NOT NULL,
    reconciled_at timestamp(0) without time zone,
    reconciliation_id bigint,
    cash_account_id bigint,
    CONSTRAINT payment_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: payment_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_schedules_id_seq OWNED BY public.payment_schedules.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    payment_number character varying(50) NOT NULL,
    payable_type character varying(50) NOT NULL,
    payable_id bigint NOT NULL,
    client_id bigint NOT NULL,
    quotation_id bigint,
    amount numeric(15,2) NOT NULL,
    payment_type character varying(255),
    payment_method character varying(255),
    gateway_provider character varying(50),
    gateway_transaction_id character varying(255),
    gateway_response json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    bank_name character varying(100),
    account_number character varying(50),
    account_holder character varying(255),
    transfer_proof_path character varying(500),
    verified_by bigint,
    verified_at timestamp(0) without time zone,
    verification_notes text,
    paid_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT payments_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['bank_transfer'::character varying, 'ewallet'::character varying, 'credit_card'::character varying, 'virtual_account'::character varying, 'manual'::character varying])::text[]))),
    CONSTRAINT payments_payment_type_check CHECK (((payment_type)::text = ANY ((ARRAY['down_payment'::character varying, 'installment'::character varying, 'final_payment'::character varying])::text[]))),
    CONSTRAINT payments_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'success'::character varying, 'failed'::character varying, 'refunded'::character varying])::text[])))
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: permission_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_role (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    permission_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permission_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permission_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permission_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permission_role_id_seq OWNED BY public.permission_role.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    "group" character varying(255) NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: permit_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_applications (
    id bigint NOT NULL,
    application_number character varying(50) NOT NULL,
    client_id bigint,
    permit_type_id bigint,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    form_data json,
    notes text,
    admin_notes text,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    quoted_price numeric(15,2),
    quoted_at timestamp(0) without time zone,
    quotation_expires_at timestamp(0) without time zone,
    quotation_notes text,
    down_payment_amount numeric(15,2),
    down_payment_percentage integer DEFAULT 30 NOT NULL,
    payment_status character varying(255),
    project_id bigint,
    converted_at timestamp(0) without time zone,
    submitted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    kbli_code character varying(10),
    kbli_description text,
    ai_recommendation_id bigint,
    business_context jsonb,
    terms_accepted_at timestamp(0) without time zone,
    terms_version character varying(20),
    terms_accepted_language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    terms_ip_address inet,
    terms_user_agent text,
    CONSTRAINT permit_applications_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['pending'::character varying, 'down_paid'::character varying, 'partially_paid'::character varying, 'fully_paid'::character varying])::text[]))),
    CONSTRAINT permit_applications_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'submitted'::character varying, 'under_review'::character varying, 'document_incomplete'::character varying, 'quoted'::character varying, 'quotation_accepted'::character varying, 'quotation_rejected'::character varying, 'payment_pending'::character varying, 'payment_verified'::character varying, 'converted_to_project'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: COLUMN permit_applications.business_context; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permit_applications.business_context IS 'Business scale, location type, and other context';


--
-- Name: permit_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permit_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_applications_id_seq OWNED BY public.permit_applications.id;


--
-- Name: permit_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_documents (
    id bigint NOT NULL,
    project_permit_id bigint NOT NULL,
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    file_type character varying(50) NOT NULL,
    file_size integer NOT NULL,
    description text,
    uploaded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permit_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permit_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_documents_id_seq OWNED BY public.permit_documents.id;


--
-- Name: permit_template_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_template_dependencies (
    id bigint NOT NULL,
    template_id bigint NOT NULL,
    permit_item_id bigint NOT NULL,
    depends_on_item_id bigint NOT NULL,
    dependency_type character varying(255) DEFAULT 'MANDATORY'::character varying NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT permit_template_dependencies_dependency_type_check CHECK (((dependency_type)::text = ANY ((ARRAY['MANDATORY'::character varying, 'OPTIONAL'::character varying, 'RECOMMENDED'::character varying])::text[])))
);


--
-- Name: permit_template_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_template_dependencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permit_template_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_template_dependencies_id_seq OWNED BY public.permit_template_dependencies.id;


--
-- Name: permit_template_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_template_items (
    id bigint NOT NULL,
    template_id bigint NOT NULL,
    permit_type_id bigint,
    custom_permit_name character varying(100),
    sequence_order integer DEFAULT 0 NOT NULL,
    is_goal_permit boolean DEFAULT false NOT NULL,
    estimated_days integer,
    estimated_cost numeric(15,2),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permit_template_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_template_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permit_template_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_template_items_id_seq OWNED BY public.permit_template_items.id;


--
-- Name: permit_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_templates (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    description text,
    use_case text,
    category character varying(50),
    created_by_user_id bigint,
    is_public boolean DEFAULT false NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permit_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permit_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_templates_id_seq OWNED BY public.permit_templates.id;


--
-- Name: permit_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_types (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(50) NOT NULL,
    category character varying(255) NOT NULL,
    institution_id bigint,
    avg_processing_days integer,
    description text,
    required_documents json,
    estimated_cost_min numeric(15,2),
    estimated_cost_max numeric(15,2),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT permit_types_category_check CHECK (((category)::text = ANY ((ARRAY['environmental'::character varying, 'land'::character varying, 'building'::character varying, 'transportation'::character varying, 'business'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: permit_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permit_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_types_id_seq OWNED BY public.permit_types.id;


--
-- Name: project_expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_expenses (
    id bigint NOT NULL,
    project_id bigint,
    expense_date date NOT NULL,
    vendor_name character varying(255),
    amount numeric(15,2) NOT NULL,
    bank_account_id bigint,
    description text,
    receipt_file character varying(255),
    is_billable boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_receivable boolean DEFAULT false NOT NULL,
    receivable_from character varying(255),
    receivable_status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    receivable_paid_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    receivable_notes text,
    category character varying(50) NOT NULL,
    payment_method character varying(50) DEFAULT 'transfer'::character varying NOT NULL,
    is_reconciled boolean DEFAULT false NOT NULL,
    reconciled_at timestamp(0) without time zone,
    reconciliation_id bigint,
    CONSTRAINT project_expenses_receivable_status_check CHECK (((receivable_status)::text = ANY ((ARRAY['pending'::character varying, 'partial'::character varying, 'paid'::character varying])::text[])))
);


--
-- Name: COLUMN project_expenses.expense_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.expense_date IS 'Tanggal pengeluaran';


--
-- Name: COLUMN project_expenses.vendor_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.vendor_name IS 'Nama rekanan/penerima pembayaran';


--
-- Name: COLUMN project_expenses.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.amount IS 'Nominal pengeluaran';


--
-- Name: COLUMN project_expenses.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.description IS 'Keterangan pengeluaran';


--
-- Name: COLUMN project_expenses.receipt_file; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receipt_file IS 'Path file bukti pembayaran';


--
-- Name: COLUMN project_expenses.is_billable; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.is_billable IS 'Apakah bisa ditagihkan ke klien?';


--
-- Name: COLUMN project_expenses.is_receivable; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.is_receivable IS 'Apakah pengeluaran ini merupakan kasbon/piutang yang perlu dikembalikan oleh karyawan/pihak internal';


--
-- Name: COLUMN project_expenses.receivable_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_from IS 'Nama karyawan/pihak yang berhutang';


--
-- Name: COLUMN project_expenses.receivable_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_status IS 'Status pembayaran kasbon: pending, partial, paid';


--
-- Name: COLUMN project_expenses.receivable_paid_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_paid_amount IS 'Jumlah yang sudah dibayar/dikembalikan';


--
-- Name: COLUMN project_expenses.receivable_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_notes IS 'Catatan pembayaran kasbon';


--
-- Name: project_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_expenses_id_seq OWNED BY public.project_expenses.id;


--
-- Name: project_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_logs (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    entity_type character varying(255),
    entity_id bigint,
    description text NOT NULL,
    old_values json,
    new_values json,
    notes text,
    ip_address character varying(45),
    user_agent character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: COLUMN project_logs.action; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_logs.action IS 'created, updated, status_changed, document_uploaded, dll';


--
-- Name: COLUMN project_logs.entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_logs.entity_type IS 'project, task, document, dll';


--
-- Name: project_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_logs_id_seq OWNED BY public.project_logs.id;


--
-- Name: project_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_payments (
    id bigint NOT NULL,
    project_id bigint,
    payment_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    payment_type character varying(255) DEFAULT 'other'::character varying NOT NULL,
    bank_account_id bigint,
    reference_number character varying(100),
    description text,
    receipt_file character varying(255),
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    payment_method character varying(255) DEFAULT 'bank_transfer'::character varying NOT NULL,
    invoice_id bigint,
    is_reconciled boolean DEFAULT false NOT NULL,
    reconciled_at timestamp(0) without time zone,
    reconciliation_id bigint,
    CONSTRAINT project_payments_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['cash'::character varying, 'bank_transfer'::character varying, 'check'::character varying, 'giro'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT project_payments_payment_type_check CHECK (((payment_type)::text = ANY ((ARRAY['dp'::character varying, 'progress'::character varying, 'final'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: COLUMN project_payments.payment_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.payment_date IS 'Tanggal terima pembayaran';


--
-- Name: COLUMN project_payments.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.amount IS 'Nominal pembayaran';


--
-- Name: COLUMN project_payments.reference_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.reference_number IS 'Nomor referensi/bukti transfer';


--
-- Name: COLUMN project_payments.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.description IS 'Keterangan tambahan';


--
-- Name: COLUMN project_payments.receipt_file; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.receipt_file IS 'Path file bukti pembayaran';


--
-- Name: project_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_payments_id_seq OWNED BY public.project_payments.id;


--
-- Name: project_permit_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_permit_dependencies (
    id bigint NOT NULL,
    project_permit_id bigint NOT NULL,
    depends_on_permit_id bigint NOT NULL,
    dependency_type character varying(255) DEFAULT 'MANDATORY'::character varying NOT NULL,
    can_proceed_without boolean DEFAULT false NOT NULL,
    override_reason text,
    override_document_path character varying(255),
    overridden_by_user_id bigint,
    overridden_at timestamp(0) without time zone,
    created_by_user_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT project_permit_dependencies_dependency_type_check CHECK (((dependency_type)::text = ANY ((ARRAY['MANDATORY'::character varying, 'OPTIONAL'::character varying])::text[])))
);


--
-- Name: project_permit_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_permit_dependencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_permit_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_permit_dependencies_id_seq OWNED BY public.project_permit_dependencies.id;


--
-- Name: project_permits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_permits (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    permit_type_id bigint,
    custom_permit_name character varying(100),
    custom_institution_name character varying(100),
    sequence_order integer DEFAULT 0 NOT NULL,
    is_goal_permit boolean DEFAULT false NOT NULL,
    status character varying(255) DEFAULT 'NOT_STARTED'::character varying NOT NULL,
    has_existing_document boolean DEFAULT false NOT NULL,
    existing_document_id bigint,
    assigned_to_user_id bigint,
    started_at timestamp(0) without time zone,
    submitted_at timestamp(0) without time zone,
    approved_at timestamp(0) without time zone,
    rejected_at timestamp(0) without time zone,
    target_date date,
    estimated_cost numeric(15,2),
    actual_cost numeric(15,2),
    permit_number character varying(100),
    valid_until date,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    override_dependencies boolean DEFAULT false NOT NULL,
    override_reason text,
    override_by_user_id bigint,
    override_at timestamp(0) without time zone,
    CONSTRAINT project_permits_status_check CHECK (((status)::text = ANY ((ARRAY['NOT_STARTED'::character varying, 'IN_PROGRESS'::character varying, 'WAITING_DOC'::character varying, 'SUBMITTED'::character varying, 'UNDER_REVIEW'::character varying, 'APPROVED'::character varying, 'REJECTED'::character varying, 'EXISTING'::character varying, 'CANCELLED'::character varying])::text[])))
);


--
-- Name: project_permits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_permits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_permits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_permits_id_seq OWNED BY public.project_permits.id;


--
-- Name: project_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_statuses (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#6B7280'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_final boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: COLUMN project_statuses.is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_statuses.is_final IS 'Status akhir/selesai';


--
-- Name: project_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_statuses_id_seq OWNED BY public.project_statuses.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    client_name character varying(255) NOT NULL,
    client_address text,
    status_id bigint NOT NULL,
    institution_id bigint,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    client_contact character varying(255),
    start_date date,
    deadline date,
    progress_percentage integer DEFAULT 0 NOT NULL,
    budget numeric(15,2),
    actual_cost numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    contract_value numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    down_payment numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    payment_received numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_expenses numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    profit_margin numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    payment_terms text,
    payment_status character varying(255) DEFAULT 'unpaid'::character varying NOT NULL,
    client_id bigint,
    permit_application_id bigint,
    completed_at timestamp(0) without time zone,
    completion_notes text,
    actual_completion_date date,
    CONSTRAINT projects_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['unpaid'::character varying, 'partial'::character varying, 'paid'::character varying])::text[])))
);


--
-- Name: COLUMN projects.contract_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.contract_value IS 'Nilai kontrak total';


--
-- Name: COLUMN projects.down_payment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.down_payment IS 'Uang muka (DP)';


--
-- Name: COLUMN projects.payment_received; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.payment_received IS 'Total pembayaran diterima';


--
-- Name: COLUMN projects.total_expenses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.total_expenses IS 'Total pengeluaran';


--
-- Name: COLUMN projects.profit_margin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.profit_margin IS 'Profit margin (%)';


--
-- Name: COLUMN projects.payment_terms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.payment_terms IS 'Termin pembayaran';


--
-- Name: COLUMN projects.completed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.completed_at IS 'Tanggal aktual proyek selesai (untuk tracking on-time/late)';


--
-- Name: COLUMN projects.completion_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.completion_notes IS 'Catatan saat proyek selesai';


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id bigint NOT NULL,
    subscribable_type character varying(255) NOT NULL,
    subscribable_id bigint NOT NULL,
    endpoint character varying(500) NOT NULL,
    public_key character varying(255),
    auth_token character varying(255),
    content_encoding character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotation_items (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    revision_id bigint,
    item_type character varying(255) DEFAULT 'permit'::character varying NOT NULL,
    permit_type_id bigint,
    item_name character varying(200) NOT NULL,
    description text,
    unit_price numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    subtotal numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    service_type character varying(255) DEFAULT 'bizmark'::character varying NOT NULL,
    estimated_days integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT quotation_items_item_type_check CHECK (((item_type)::text = ANY ((ARRAY['permit'::character varying, 'consultation'::character varying, 'survey'::character varying, 'processing'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT quotation_items_service_type_check CHECK (((service_type)::text = ANY ((ARRAY['bizmark'::character varying, 'owned'::character varying, 'self'::character varying])::text[])))
);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotation_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotations (
    id bigint NOT NULL,
    quotation_number character varying(50) NOT NULL,
    application_id bigint NOT NULL,
    client_id bigint NOT NULL,
    base_price numeric(15,2) NOT NULL,
    additional_fees json,
    discount_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    tax_percentage numeric(5,2) DEFAULT '11'::numeric NOT NULL,
    tax_amount numeric(15,2),
    total_amount numeric(15,2) NOT NULL,
    down_payment_percentage integer DEFAULT 30 NOT NULL,
    down_payment_amount numeric(15,2),
    payment_terms text,
    valid_until timestamp(0) without time zone NOT NULL,
    terms_and_conditions text,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    accepted_at timestamp(0) without time zone,
    rejected_at timestamp(0) without time zone,
    rejection_reason text,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT quotations_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'sent'::character varying, 'accepted'::character varying, 'rejected'::character varying, 'expired'::character varying])::text[])))
);


--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: ranking_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ranking_alerts (
    id bigint NOT NULL,
    position_history_id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    alert_type character varying(255) NOT NULL,
    severity smallint NOT NULL,
    old_position smallint,
    new_position smallint,
    message character varying(255) NOT NULL,
    details json,
    is_read boolean DEFAULT false NOT NULL,
    is_actioned boolean DEFAULT false NOT NULL,
    actioned_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ranking_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ranking_alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ranking_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ranking_alerts_id_seq OWNED BY public.ranking_alerts.id;


--
-- Name: recruitment_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recruitment_stages (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    stage_name character varying(100) NOT NULL,
    stage_order integer NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    score numeric(5,2),
    notes text,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT recruitment_stages_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in-progress'::character varying, 'passed'::character varying, 'failed'::character varying, 'skipped'::character varying])::text[])))
);


--
-- Name: COLUMN recruitment_stages.stage_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.recruitment_stages.stage_name IS 'screening, psych-test, technical-test, interview-1, etc';


--
-- Name: COLUMN recruitment_stages.stage_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.recruitment_stages.stage_order IS 'Sequential order';


--
-- Name: COLUMN recruitment_stages.score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.recruitment_stages.score IS 'Stage score if applicable';


--
-- Name: recruitment_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recruitment_stages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recruitment_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recruitment_stages_id_seq OWNED BY public.recruitment_stages.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: search_console_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_console_data (
    id bigint NOT NULL,
    page_url character varying(255) NOT NULL,
    query character varying(255) NOT NULL,
    date date NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    ctr numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    "position" numeric(5,1) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: search_console_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.search_console_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: search_console_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.search_console_data_id_seq OWNED BY public.search_console_data.id;


--
-- Name: security_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_settings (
    id bigint NOT NULL,
    min_password_length smallint DEFAULT '8'::smallint NOT NULL,
    require_special_char boolean DEFAULT true NOT NULL,
    require_number boolean DEFAULT true NOT NULL,
    require_mixed_case boolean DEFAULT true NOT NULL,
    enforce_password_expiration boolean DEFAULT false NOT NULL,
    password_expiration_days smallint DEFAULT '90'::smallint NOT NULL,
    session_timeout_minutes smallint DEFAULT '30'::smallint NOT NULL,
    allow_concurrent_sessions boolean DEFAULT true NOT NULL,
    two_factor_enabled boolean DEFAULT false NOT NULL,
    activity_log_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: security_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.security_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: security_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.security_settings_id_seq OWNED BY public.security_settings.id;


--
-- Name: seo_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_reports (
    id bigint NOT NULL,
    period character varying(255) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    metrics json NOT NULL,
    top_articles json,
    alerts json,
    emailed boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: seo_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seo_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_reports_id_seq OWNED BY public.seo_reports.id;


--
-- Name: seo_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_scores (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    total_score smallint DEFAULT '0'::smallint NOT NULL,
    factors json NOT NULL,
    recommendations json,
    scored_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: seo_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_scores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seo_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_scores_id_seq OWNED BY public.seo_scores.id;


--
-- Name: service_cost_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_cost_requests (
    id bigint NOT NULL,
    request_number character varying(20) NOT NULL,
    applicant_type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(20) NOT NULL,
    address character varying(255),
    city character varying(255),
    province character varying(255),
    nik character varying(20),
    occupation character varying(255),
    company_name character varying(255),
    npwp character varying(30),
    nib character varying(30),
    business_type character varying(255),
    business_sector character varying(255),
    pic_name character varying(255),
    pic_position character varying(255),
    service_category character varying(255) NOT NULL,
    services_requested json NOT NULL,
    project_description text,
    project_location character varying(255),
    estimated_budget numeric(15,2),
    timeline_expectation character varying(255),
    documents json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    admin_notes text,
    quoted_price numeric(15,2),
    quote_details text,
    quoted_at timestamp(0) without time zone,
    responded_at timestamp(0) without time zone,
    source character varying(255) DEFAULT 'website'::character varying NOT NULL,
    referral_code character varying(255),
    ip_address character varying(45),
    user_agent text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT service_cost_requests_applicant_type_check CHECK (((applicant_type)::text = ANY ((ARRAY['perorangan'::character varying, 'badan'::character varying])::text[]))),
    CONSTRAINT service_cost_requests_business_type_check CHECK (((business_type)::text = ANY ((ARRAY['pt'::character varying, 'cv'::character varying, 'ud'::character varying, 'yayasan'::character varying, 'koperasi'::character varying, 'lainnya'::character varying])::text[]))),
    CONSTRAINT service_cost_requests_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'reviewing'::character varying, 'quoted'::character varying, 'accepted'::character varying, 'rejected'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: service_cost_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_cost_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_cost_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_cost_requests_id_seq OWNED BY public.service_cost_requests.id;


--
-- Name: service_inquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_inquiries (
    id bigint NOT NULL,
    inquiry_number character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    company_name character varying(255) NOT NULL,
    company_type character varying(100),
    phone character varying(50) NOT NULL,
    contact_person character varying(255) NOT NULL,
    "position" character varying(100),
    kbli_code character varying(10),
    kbli_description text,
    business_activity text NOT NULL,
    form_data json NOT NULL,
    ai_analysis json,
    ai_model_used character varying(50) DEFAULT 'gpt-3.5-turbo'::character varying,
    ai_processing_time integer,
    ai_tokens_used integer,
    analyzed_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'new'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    source character varying(50) DEFAULT 'landing_page'::character varying NOT NULL,
    utm_source character varying(100),
    utm_medium character varying(100),
    utm_campaign character varying(100),
    client_id bigint,
    converted_to_application_id bigint,
    converted_at timestamp(0) without time zone,
    ip_address inet,
    user_agent text,
    session_id character varying(255),
    last_contacted_at timestamp(0) without time zone,
    contacted_by bigint,
    admin_notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT service_inquiries_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[]))),
    CONSTRAINT service_inquiries_status_check CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'processing'::character varying, 'analyzed'::character varying, 'contacted'::character varying, 'qualified'::character varying, 'converted'::character varying, 'registered'::character varying, 'lost'::character varying])::text[])))
);


--
-- Name: COLUMN service_inquiries.inquiry_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.inquiry_number IS 'Format: INQ-2025-XXXX';


--
-- Name: COLUMN service_inquiries.company_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.company_type IS 'PT, CV, Individual, etc';


--
-- Name: COLUMN service_inquiries.business_activity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.business_activity IS 'User description of business';


--
-- Name: COLUMN service_inquiries.form_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.form_data IS 'All form fields in JSON format';


--
-- Name: COLUMN service_inquiries.ai_analysis; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.ai_analysis IS 'AI recommendations and analysis';


--
-- Name: COLUMN service_inquiries.ai_processing_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.ai_processing_time IS 'Processing time in milliseconds';


--
-- Name: service_inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_inquiries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_inquiries_id_seq OWNED BY public.service_inquiries.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


--
-- Name: shapefile_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shapefile_projects (
    id bigint NOT NULL,
    user_id bigint,
    name character varying(255) NOT NULL,
    geojson json NOT NULL,
    area_m2 numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    area_ha numeric(12,6) DEFAULT '0'::numeric NOT NULL,
    perimeter_m numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    metadata json,
    file_path character varying(255),
    session_token character varying(64),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    company_name character varying(150),
    contact_person character varying(100),
    email character varying(150),
    phone character varying(30),
    agreed_terms_at timestamp(0) without time zone,
    service_inquiry_id bigint,
    ip_address inet,
    user_agent text,
    rtrw_zona character varying(200),
    rtrw_perda character varying(100),
    rtrw_remark text,
    rtrw_raw json
);


--
-- Name: shapefile_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shapefile_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shapefile_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shapefile_projects_id_seq OWNED BY public.shapefile_projects.id;


--
-- Name: social_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_posts (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    platform character varying(255) NOT NULL,
    caption text,
    platform_post_id character varying(255),
    platform_url character varying(255),
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    posted_at timestamp(0) without time zone,
    scheduled_for timestamp(0) without time zone,
    metrics json,
    error_message text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: social_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: social_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_posts_id_seq OWNED BY public.social_posts.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id bigint NOT NULL,
    company_name character varying(255),
    company_email character varying(255),
    company_phone character varying(255),
    company_website character varying(255),
    company_address text,
    maintenance_mode boolean DEFAULT false NOT NULL,
    email_notifications boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    sop_notes text,
    assigned_user_id bigint,
    due_date date,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'todo'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'normal'::character varying NOT NULL,
    institution_id bigint,
    depends_on_task_id bigint,
    completion_notes text,
    estimated_hours integer,
    actual_hours integer,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    project_permit_id bigint,
    CONSTRAINT tasks_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'normal'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT tasks_status_check CHECK (((status)::text = ANY ((ARRAY['todo'::character varying, 'in_progress'::character varying, 'done'::character varying, 'blocked'::character varying])::text[])))
);


--
-- Name: COLUMN tasks.sop_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.sop_notes IS 'SOP atau checklist tugas';


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    rate numeric(5,2) NOT NULL,
    description character varying(255),
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: tax_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tax_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tax_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tax_rates_id_seq OWNED BY public.tax_rates.id;


--
-- Name: technical_test_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technical_test_submissions (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    test_title character varying(255) NOT NULL,
    test_description text,
    original_file_path character varying(500),
    submission_file_path character varying(500) NOT NULL,
    file_type character varying(50),
    format_score numeric(5,2),
    format_issues json,
    reviewer_id bigint,
    review_score numeric(5,2),
    review_notes text,
    reviewed_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'submitted'::character varying NOT NULL,
    submitted_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT technical_test_submissions_status_check CHECK (((status)::text = ANY ((ARRAY['submitted'::character varying, 'under-review'::character varying, 'reviewed'::character varying])::text[])))
);


--
-- Name: COLUMN technical_test_submissions.original_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.original_file_path IS 'Template file provided';


--
-- Name: COLUMN technical_test_submissions.submission_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.submission_file_path IS 'Candidate submission';


--
-- Name: COLUMN technical_test_submissions.file_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.file_type IS 'docx, xlsx, pdf, etc';


--
-- Name: COLUMN technical_test_submissions.format_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.format_score IS 'Auto-scoring format compliance';


--
-- Name: COLUMN technical_test_submissions.format_issues; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.format_issues IS 'Array of detected issues';


--
-- Name: COLUMN technical_test_submissions.review_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.review_score IS 'Manual score 0-100';


--
-- Name: technical_test_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.technical_test_submissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: technical_test_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.technical_test_submissions_id_seq OWNED BY public.technical_test_submissions.id;


--
-- Name: test_answers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_answers (
    id bigint NOT NULL,
    test_session_id bigint NOT NULL,
    question_id character varying(100) NOT NULL,
    answer_data json NOT NULL,
    is_correct boolean,
    points_earned numeric(5,2),
    time_spent_seconds integer,
    answered_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: COLUMN test_answers.question_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_answers.question_id IS 'References question in test_template';


--
-- Name: COLUMN test_answers.answer_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_answers.answer_data IS 'Flexible: multiple choice, text, etc.';


--
-- Name: test_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.test_answers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: test_answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.test_answers_id_seq OWNED BY public.test_answers.id;


--
-- Name: test_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_sessions (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    test_template_id bigint NOT NULL,
    session_token character varying(64) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    starts_at timestamp(0) without time zone NOT NULL,
    expires_at timestamp(0) without time zone NOT NULL,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    score numeric(5,2),
    passed boolean DEFAULT false NOT NULL,
    time_taken_minutes integer,
    ip_address character varying(45),
    user_agent text,
    tab_switches integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    submitted_file_path character varying(500),
    submitted_at timestamp(0) without time zone,
    evaluation_scores json,
    evaluator_id bigint,
    evaluator_notes text,
    evaluated_at timestamp(0) without time zone,
    requires_manual_review boolean DEFAULT false NOT NULL,
    recruitment_stage_id bigint,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT test_sessions_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in-progress'::character varying, 'completed'::character varying, 'expired'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: COLUMN test_sessions.score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.score IS '0-100 percentage';


--
-- Name: COLUMN test_sessions.tab_switches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.tab_switches IS 'Anti-cheat: detect tab switching';


--
-- Name: COLUMN test_sessions.submitted_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.submitted_file_path IS 'Path to submitted document';


--
-- Name: COLUMN test_sessions.submitted_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.submitted_at IS 'When candidate uploaded the file';


--
-- Name: COLUMN test_sessions.evaluation_scores; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.evaluation_scores IS 'Detailed scores per criteria';


--
-- Name: COLUMN test_sessions.evaluator_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.evaluator_notes IS 'Notes from evaluator';


--
-- Name: COLUMN test_sessions.evaluated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.evaluated_at IS 'When evaluation completed';


--
-- Name: COLUMN test_sessions.requires_manual_review; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.requires_manual_review IS 'For document-editing type';


--
-- Name: test_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.test_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: test_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.test_sessions_id_seq OWNED BY public.test_sessions.id;


--
-- Name: test_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_templates (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    test_type character varying(50) NOT NULL,
    description text,
    duration_minutes integer NOT NULL,
    passing_score integer NOT NULL,
    questions_data json,
    instructions text,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    template_file_path character varying(500),
    evaluation_criteria json
);


--
-- Name: COLUMN test_templates.passing_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.passing_score IS 'Percentage (0-100)';


--
-- Name: COLUMN test_templates.questions_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.questions_data IS 'Question bank with answers';


--
-- Name: COLUMN test_templates.template_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.template_file_path IS 'Path to template document file';


--
-- Name: COLUMN test_templates.evaluation_criteria; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.evaluation_criteria IS 'Checklist/rubrik penilaian untuk document editing';


--
-- Name: test_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.test_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: test_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.test_templates_id_seq OWNED BY public.test_templates.id;


--
-- Name: topic_clusters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.topic_clusters (
    id bigint NOT NULL,
    pillar_title character varying(255) NOT NULL,
    pillar_slug character varying(255) NOT NULL,
    pillar_description text NOT NULL,
    service_slug character varying(255),
    language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    subtopics json NOT NULL,
    article_ids json,
    keyword_cluster_ids json,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    internal_links_built integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: topic_clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.topic_clusters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: topic_clusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.topic_clusters_id_seq OWNED BY public.topic_clusters.id;


--
-- Name: trending_topics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trending_topics (
    id bigint NOT NULL,
    topic character varying(255) NOT NULL,
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    language character varying(255) DEFAULT 'id'::character varying NOT NULL,
    data_source character varying(255) DEFAULT 'searxng'::character varying NOT NULL,
    trend_score integer DEFAULT 0 NOT NULL,
    search_volume integer,
    related_keywords json,
    top_sources json,
    sample_headline text,
    is_processed boolean DEFAULT false NOT NULL,
    article_id bigint,
    discovered_at timestamp(0) without time zone NOT NULL,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: trending_topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trending_topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trending_topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trending_topics_id_seq OWNED BY public.trending_topics.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    full_name character varying(255),
    "position" character varying(255),
    phone character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(0) without time zone,
    notes text,
    avatar character varying(255),
    role_id bigint,
    company_email character varying(255),
    department character varying(255) NOT NULL,
    email_signature text,
    job_title character varying(255),
    notification_preferences json,
    working_hours json,
    username character varying(255),
    employee_id character varying(255),
    bio text,
    expertise character varying(500),
    linkedin_url character varying(255),
    twitter_url character varying(255),
    CONSTRAINT users_department_check CHECK (((department)::text = ANY (ARRAY[('general'::character varying)::text, ('cs'::character varying)::text, ('sales'::character varying)::text, ('support'::character varying)::text, ('finance'::character varying)::text, ('technical'::character varying)::text])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: ai_processing_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_processing_logs_id_seq'::regclass);


--
-- Name: ai_query_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_query_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_query_logs_id_seq'::regclass);


--
-- Name: ai_setting_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history ALTER COLUMN id SET DEFAULT nextval('public.ai_setting_history_id_seq'::regclass);


--
-- Name: ai_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings ALTER COLUMN id SET DEFAULT nextval('public.ai_settings_id_seq'::regclass);


--
-- Name: application_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents ALTER COLUMN id SET DEFAULT nextval('public.application_documents_id_seq'::regclass);


--
-- Name: application_legality_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_legality_documents ALTER COLUMN id SET DEFAULT nextval('public.application_legality_documents_id_seq'::regclass);


--
-- Name: application_location_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details ALTER COLUMN id SET DEFAULT nextval('public.application_location_details_id_seq'::regclass);


--
-- Name: application_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes ALTER COLUMN id SET DEFAULT nextval('public.application_notes_id_seq'::regclass);


--
-- Name: application_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions ALTER COLUMN id SET DEFAULT nextval('public.application_revisions_id_seq'::regclass);


--
-- Name: application_status_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_status_logs ALTER COLUMN id SET DEFAULT nextval('public.application_status_logs_id_seq'::regclass);


--
-- Name: article_topic_similarities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities ALTER COLUMN id SET DEFAULT nextval('public.article_topic_similarities_id_seq'::regclass);


--
-- Name: article_topics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics ALTER COLUMN id SET DEFAULT nextval('public.article_topics_id_seq'::regclass);


--
-- Name: article_view_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs ALTER COLUMN id SET DEFAULT nextval('public.article_view_logs_id_seq'::regclass);


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: auto_post_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_configs ALTER COLUMN id SET DEFAULT nextval('public.auto_post_configs_id_seq'::regclass);


--
-- Name: auto_post_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs ALTER COLUMN id SET DEFAULT nextval('public.auto_post_logs_id_seq'::regclass);


--
-- Name: auto_post_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules ALTER COLUMN id SET DEFAULT nextval('public.auto_post_schedules_id_seq'::regclass);


--
-- Name: bank_reconciliations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations ALTER COLUMN id SET DEFAULT nextval('public.bank_reconciliations_id_seq'::regclass);


--
-- Name: bank_statement_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_entries ALTER COLUMN id SET DEFAULT nextval('public.bank_statement_entries_id_seq'::regclass);


--
-- Name: business_contexts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts ALTER COLUMN id SET DEFAULT nextval('public.business_contexts_id_seq'::regclass);


--
-- Name: cash_account_balance_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history ALTER COLUMN id SET DEFAULT nextval('public.cash_account_balance_history_id_seq'::regclass);


--
-- Name: cash_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_accounts ALTER COLUMN id SET DEFAULT nextval('public.cash_accounts_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: competitor_analyses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_analyses ALTER COLUMN id SET DEFAULT nextval('public.competitor_analyses_id_seq'::regclass);


--
-- Name: compliance_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checks ALTER COLUMN id SET DEFAULT nextval('public.compliance_checks_id_seq'::regclass);


--
-- Name: consult_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests ALTER COLUMN id SET DEFAULT nextval('public.consult_requests_id_seq'::regclass);


--
-- Name: content_gaps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps ALTER COLUMN id SET DEFAULT nextval('public.content_gaps_id_seq'::regclass);


--
-- Name: content_refresh_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_refresh_logs ALTER COLUMN id SET DEFAULT nextval('public.content_refresh_logs_id_seq'::regclass);


--
-- Name: content_syndications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_syndications ALTER COLUMN id SET DEFAULT nextval('public.content_syndications_id_seq'::regclass);


--
-- Name: document_drafts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts ALTER COLUMN id SET DEFAULT nextval('public.document_drafts_id_seq'::regclass);


--
-- Name: document_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates ALTER COLUMN id SET DEFAULT nextval('public.document_templates_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: email_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_accounts ALTER COLUMN id SET DEFAULT nextval('public.email_accounts_id_seq'::regclass);


--
-- Name: email_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments ALTER COLUMN id SET DEFAULT nextval('public.email_assignments_id_seq'::regclass);


--
-- Name: email_campaigns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns ALTER COLUMN id SET DEFAULT nextval('public.email_campaigns_id_seq'::regclass);


--
-- Name: email_inbox id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox ALTER COLUMN id SET DEFAULT nextval('public.email_inbox_id_seq'::regclass);


--
-- Name: email_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);


--
-- Name: email_subscribers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_subscribers ALTER COLUMN id SET DEFAULT nextval('public.email_subscribers_id_seq'::regclass);


--
-- Name: email_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates ALTER COLUMN id SET DEFAULT nextval('public.email_templates_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: institutions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions ALTER COLUMN id SET DEFAULT nextval('public.institutions_id_seq'::regclass);


--
-- Name: interview_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback ALTER COLUMN id SET DEFAULT nextval('public.interview_feedback_id_seq'::regclass);


--
-- Name: interview_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules ALTER COLUMN id SET DEFAULT nextval('public.interview_schedules_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: job_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications ALTER COLUMN id SET DEFAULT nextval('public.job_applications_id_seq'::regclass);


--
-- Name: job_vacancies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_vacancies ALTER COLUMN id SET DEFAULT nextval('public.job_vacancies_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: kbli id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli ALTER COLUMN id SET DEFAULT nextval('public.kbli_id_seq'::regclass);


--
-- Name: kbli_permit_recommendations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli_permit_recommendations ALTER COLUMN id SET DEFAULT nextval('public.kbli_permit_recommendations_id_seq'::regclass);


--
-- Name: kblis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kblis ALTER COLUMN id SET DEFAULT nextval('public.kblis_id_seq'::regclass);


--
-- Name: keyword_clusters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_clusters ALTER COLUMN id SET DEFAULT nextval('public.keyword_clusters_id_seq'::regclass);


--
-- Name: keyword_position_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_position_history ALTER COLUMN id SET DEFAULT nextval('public.keyword_position_history_id_seq'::regclass);


--
-- Name: meta_ab_tests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_ab_tests ALTER COLUMN id SET DEFAULT nextval('public.meta_ab_tests_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: milestones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones ALTER COLUMN id SET DEFAULT nextval('public.milestones_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- Name: payment_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules ALTER COLUMN id SET DEFAULT nextval('public.payment_schedules_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: permission_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role ALTER COLUMN id SET DEFAULT nextval('public.permission_role_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: permit_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications ALTER COLUMN id SET DEFAULT nextval('public.permit_applications_id_seq'::regclass);


--
-- Name: permit_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents ALTER COLUMN id SET DEFAULT nextval('public.permit_documents_id_seq'::regclass);


--
-- Name: permit_template_dependencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies ALTER COLUMN id SET DEFAULT nextval('public.permit_template_dependencies_id_seq'::regclass);


--
-- Name: permit_template_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items ALTER COLUMN id SET DEFAULT nextval('public.permit_template_items_id_seq'::regclass);


--
-- Name: permit_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_templates ALTER COLUMN id SET DEFAULT nextval('public.permit_templates_id_seq'::regclass);


--
-- Name: permit_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types ALTER COLUMN id SET DEFAULT nextval('public.permit_types_id_seq'::regclass);


--
-- Name: project_expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses ALTER COLUMN id SET DEFAULT nextval('public.project_expenses_id_seq'::regclass);


--
-- Name: project_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs ALTER COLUMN id SET DEFAULT nextval('public.project_logs_id_seq'::regclass);


--
-- Name: project_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments ALTER COLUMN id SET DEFAULT nextval('public.project_payments_id_seq'::regclass);


--
-- Name: project_permit_dependencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies ALTER COLUMN id SET DEFAULT nextval('public.project_permit_dependencies_id_seq'::regclass);


--
-- Name: project_permits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits ALTER COLUMN id SET DEFAULT nextval('public.project_permits_id_seq'::regclass);


--
-- Name: project_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses ALTER COLUMN id SET DEFAULT nextval('public.project_statuses_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: ranking_alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranking_alerts ALTER COLUMN id SET DEFAULT nextval('public.ranking_alerts_id_seq'::regclass);


--
-- Name: recruitment_stages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages ALTER COLUMN id SET DEFAULT nextval('public.recruitment_stages_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: search_console_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_console_data ALTER COLUMN id SET DEFAULT nextval('public.search_console_data_id_seq'::regclass);


--
-- Name: security_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_settings ALTER COLUMN id SET DEFAULT nextval('public.security_settings_id_seq'::regclass);


--
-- Name: seo_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_reports ALTER COLUMN id SET DEFAULT nextval('public.seo_reports_id_seq'::regclass);


--
-- Name: seo_scores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores ALTER COLUMN id SET DEFAULT nextval('public.seo_scores_id_seq'::regclass);


--
-- Name: service_cost_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_cost_requests ALTER COLUMN id SET DEFAULT nextval('public.service_cost_requests_id_seq'::regclass);


--
-- Name: service_inquiries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries ALTER COLUMN id SET DEFAULT nextval('public.service_inquiries_id_seq'::regclass);


--
-- Name: shapefile_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects ALTER COLUMN id SET DEFAULT nextval('public.shapefile_projects_id_seq'::regclass);


--
-- Name: social_posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_posts ALTER COLUMN id SET DEFAULT nextval('public.social_posts_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: tax_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates ALTER COLUMN id SET DEFAULT nextval('public.tax_rates_id_seq'::regclass);


--
-- Name: technical_test_submissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions ALTER COLUMN id SET DEFAULT nextval('public.technical_test_submissions_id_seq'::regclass);


--
-- Name: test_answers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_answers ALTER COLUMN id SET DEFAULT nextval('public.test_answers_id_seq'::regclass);


--
-- Name: test_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions ALTER COLUMN id SET DEFAULT nextval('public.test_sessions_id_seq'::regclass);


--
-- Name: test_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_templates ALTER COLUMN id SET DEFAULT nextval('public.test_templates_id_seq'::regclass);


--
-- Name: topic_clusters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topic_clusters ALTER COLUMN id SET DEFAULT nextval('public.topic_clusters_id_seq'::regclass);


--
-- Name: trending_topics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trending_topics ALTER COLUMN id SET DEFAULT nextval('public.trending_topics_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ai_processing_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_processing_logs (id, document_id, template_id, project_id, operation_type, status, input_tokens, output_tokens, cost, error_message, metadata, initiated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_query_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_query_logs (id, client_id, kbli_code, business_context, prompt_text, response_text, tokens_used, response_time_ms, status, error_message, ai_model, api_cost, created_at) FROM stdin;
\.


--
-- Data for Name: ai_setting_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_setting_history (id, setting_id, key, old_value, new_value, changed_by_name, changed_by, reason, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_settings (id, category, key, value, data_type, description, is_public, is_encrypted, validation_rules, default_value, display_order, group_name, requires_restart, created_by, updated_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: application_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, is_verified, verified_by, verified_at, verification_notes, uploaded_at, created_at, updated_at, status, reviewed_by, reviewed_at, review_notes) FROM stdin;
\.


--
-- Data for Name: application_legality_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_legality_documents (id, application_id, document_category, document_name, is_available, document_number, issued_date, expiry_date, file_path, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: application_location_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_location_details (id, application_id, province, city_regency, district, sub_district, full_address, postal_code, latitude, longitude, zone_type, land_status, land_certificate_number, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: application_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_notes (id, application_id, author_type, author_id, note, is_internal, is_read, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: application_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_revisions (id, application_id, revision_number, revision_type, revision_reason, revised_by_id, permits_data, project_data, total_cost, status, client_approved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: application_status_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_status_logs (id, application_id, from_status, to_status, notes, changed_by_type, changed_by_id, created_at) FROM stdin;
\.


--
-- Data for Name: article_topic_similarities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_topic_similarities (id, topic_a_id, topic_b_id, similarity_score, calculated_at) FROM stdin;
\.


--
-- Data for Name: article_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_topics (id, title, slug, description, category, keywords, tags, status, priority, article_id, published_at, scheduled_for, generation_notes, views_count, similarity_score, created_at, updated_at, deleted_at, language, target_market, topic_cluster_id) FROM stdin;
\.


--
-- Data for Name: article_view_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_view_logs (id, article_id, date, views, unique_views, top_referrer, top_country, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.articles (id, title, slug, excerpt, content, featured_image, category, tags, status, published_at, views_count, author_id, meta_title, meta_description, meta_keywords, is_featured, reading_time, created_at, updated_at, deleted_at, source_type, language, topic_cluster_id) FROM stdin;
\.


--
-- Data for Name: auto_post_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_post_configs (id, is_enabled, posts_per_day, post_times, timezone, ai_model, min_word_count, max_word_count, min_reading_time, max_reading_time, min_headings, max_headings, min_paragraphs, internal_links_count, include_featured_image, auto_publish, duplicate_threshold, cooldown_days, excluded_keywords, category_weights, daily_limit, retry_attempts, timeout_seconds, created_at, updated_at, language_distribution, market_focus) FROM stdin;
\.


--
-- Data for Name: auto_post_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_post_logs (id, schedule_id, article_id, topic_id, level, event, message, context, word_count, reading_time, internal_links, ai_cost, created_at) FROM stdin;
\.


--
-- Data for Name: auto_post_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_post_schedules (id, topic_id, scheduled_at, status, error_message, attempts, started_at, completed_at, generation_time_seconds, metadata, created_at, updated_at, article_id) FROM stdin;
\.


--
-- Data for Name: bank_reconciliations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_reconciliations (id, cash_account_id, reconciliation_date, start_date, end_date, opening_balance_book, opening_balance_bank, closing_balance_book, closing_balance_bank, total_deposits_in_transit, total_outstanding_checks, total_bank_charges, total_bank_credits, adjusted_bank_balance, adjusted_book_balance, difference, status, bank_statement_file, bank_statement_format, notes, reconciled_by, reviewed_by, approved_by, completed_at, reviewed_at, approved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bank_statement_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_statement_entries (id, reconciliation_id, transaction_date, description, debit_amount, credit_amount, running_balance, reference_number, is_matched, matched_transaction_type, matched_transaction_id, match_confidence, match_notes, unmatch_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: business_contexts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_contexts (id, client_id, kbli_code, land_area, building_area, number_of_floors, investment_value, province, city, district, zone_type, coordinates, location_category, number_of_employees, production_capacity, annual_revenue_target, business_scale, environmental_impact, waste_management, near_protected_area, environmental_notes, ownership_status, existing_permits, urgency_level, additional_notes, custom_fields, ip_address, user_agent, submitted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache (key, value, expiration) FROM stdin;
bizmark-administration-cache-neural_metrics:2026-04-16-15	a:18:{i:0;a:3:{s:5:"route";N;s:13:"response_time";d:402.87;s:9:"timestamp";i:1776328358;}i:1;a:3:{s:5:"route";s:5:"login";s:13:"response_time";d:2.61;s:9:"timestamp";i:1776328358;}i:2;a:3:{s:5:"route";s:32:"programmatic.service-location.id";s:13:"response_time";d:14.28;s:9:"timestamp";i:1776328365;}i:3;a:3:{s:5:"route";s:5:"login";s:13:"response_time";d:2.32;s:9:"timestamp";i:1776328420;}i:4;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:5.69;s:9:"timestamp";i:1776328425;}i:5;a:3:{s:5:"route";s:11:"admin.login";s:13:"response_time";d:4.3;s:9:"timestamp";i:1776328432;}i:6;a:3:{s:5:"route";N;s:13:"response_time";d:412.83;s:9:"timestamp";i:1776328438;}i:7;a:3:{s:5:"route";s:11:"admin.login";s:13:"response_time";d:1.95;s:9:"timestamp";i:1776328438;}i:8;a:3:{s:5:"route";s:17:"permohonan.result";s:13:"response_time";d:5.29;s:9:"timestamp";i:1776328466;}i:9;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:5.85;s:9:"timestamp";i:1776328472;}i:10;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:14.72;s:9:"timestamp";i:1776328474;}i:11;a:3:{s:5:"route";s:16:"permohonan.index";s:13:"response_time";d:7.18;s:9:"timestamp";i:1776328476;}i:12;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:6.85;s:9:"timestamp";i:1776328550;}i:13;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:5.03;s:9:"timestamp";i:1776328555;}i:14;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:3.82;s:9:"timestamp";i:1776328555;}i:15;a:3:{s:5:"route";s:10:"landing.en";s:13:"response_time";d:11.92;s:9:"timestamp";i:1776328584;}i:16;a:3:{s:5:"route";s:13:"blog.index.en";s:13:"response_time";d:11.3;s:9:"timestamp";i:1776328585;}i:17;a:3:{s:5:"route";s:13:"blog.index.en";s:13:"response_time";d:6.86;s:9:"timestamp";i:1776328841;}}	1776415241
bizmark-administration-cache-fba8077d8d00c70f420d092866cfd5ae88ef4c94:timer	i:1776328418;	1776328418
bizmark-administration-cache-fba8077d8d00c70f420d092866cfd5ae88ef4c94	i:1;	1776328418
bizmark-administration-cache-pseo.articles.izin-operasional.magelang	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776414765
bizmark-administration-cache-c02c10a9c295d4dfc0d67a55593507829c3afc6e:timer	i:1776328497;	1776328497
bizmark-administration-cache-c02c10a9c295d4dfc0d67a55593507829c3afc6e	i:1;	1776328497
bizmark-administration-cache-hadez@bizmark.id|172.71.82.93:timer	i:1776328498;	1776328498
bizmark-administration-cache-hadez@bizmark.id|172.71.82.93	i:1;	1776328498
bizmark-administration-cache-landing.latest_articles.id	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776329074
bizmark-administration-cache-landing.latest_articles.en	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776329184
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: cash_account_balance_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_account_balance_history (id, cash_account_id, old_balance, new_balance, change_amount, change_type, reference_id, reference_type, description, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: cash_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_accounts (id, account_name, account_type, account_number, bank_name, account_holder, current_balance, initial_balance, is_active, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, name, company_name, industry, contact_person, email, phone, mobile, address, city, province, postal_code, npwp, tax_name, tax_address, client_type, status, notes, created_at, updated_at, deleted_at, password, email_verified_at, remember_token, profile_picture) FROM stdin;
\.


--
-- Data for Name: competitor_analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.competitor_analyses (id, keyword, our_url, our_position, top_competitors, content_gaps, recommendations, search_volume, difficulty, analyzed_at, created_at, updated_at, data_source) FROM stdin;
\.


--
-- Data for Name: compliance_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_checks (id, draft_id, document_type, overall_score, structure_score, compliance_score, formatting_score, completeness_score, issues, status, error_message, total_issues, critical_issues, warning_issues, info_issues, checked_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: consult_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consult_requests (id, name, email, phone, company_name, kbli_code, business_size, location, location_type, investment_level, employee_count, project_description, deliverables_requested, estimate_status, auto_estimate, final_quote, confidence_score, admin_notes, reviewed_by, reviewed_at, contacted, contacted_at, converted_to_client, client_id, ip_address, user_agent, referrer_url, utm_params, created_at, updated_at, deleted_at, rag_insights, rag_confidence, rag_processed_at) FROM stdin;
\.


--
-- Data for Name: content_gaps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_gaps (id, suggested_title, suggested_slug, description, target_keyword, search_intent, category, service_slug, language, priority, status, article_topic_id, topic_cluster_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: content_refresh_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_refresh_logs (id, article_id, status, changes, before_snapshot, after_snapshot, error_message, triggered_by, ai_tokens_used, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: content_syndications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_syndications (id, article_id, platform, platform_url, status, published_at, metrics, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_drafts (id, project_id, template_id, ai_log_id, title, content, sections, status, created_by, approved_at, approved_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_templates (id, name, permit_type, description, file_name, file_path, file_size, mime_type, page_count, required_fields, is_active, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, project_id, task_id, title, description, category, document_type, file_name, file_path, file_size, mime_type, version, parent_document_id, is_latest_version, status, document_date, submission_date, approval_date, uploaded_by, is_confidential, access_permissions, notes, download_count, last_accessed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_accounts (id, email, name, type, department, description, is_active, auto_reply_enabled, auto_reply_message, signature, assigned_users, total_received, total_sent, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: email_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_assignments (id, email_account_id, user_id, role, can_send, can_receive, can_delete, can_assign_others, notify_on_receive, notify_on_reply, notify_on_mention, priority, is_active, assigned_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_campaigns (id, name, subject, template_id, content, plain_content, status, recipient_type, recipient_tags, scheduled_at, sent_at, total_recipients, sent_count, opened_count, clicked_count, bounced_count, unsubscribed_count, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_inbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_inbox (id, message_id, from_email, from_name, to_email, subject, body_html, body_text, attachments, is_read, is_starred, category, labels, replied_to, assigned_to, received_at, created_at, updated_at, email_account_id, department, priority, status, first_responded_at, resolved_at, response_time_minutes, resolution_time_minutes, handled_by, tags, internal_notes, sentiment) FROM stdin;
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, campaign_id, subscriber_id, recipient_email, subject, status, sent_at, opened_at, clicked_at, bounced_at, tracking_id, error_message, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_subscribers (id, email, name, phone, status, source, tags, custom_fields, subscribed_at, unsubscribed_at, unsubscribe_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_templates (id, name, subject, content, plain_content, thumbnail, category, is_active, variables, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expense_categories (id, slug, name, "group", icon, is_default, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: institutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutions (id, name, type, address, phone, email, contact_person, contact_position, notes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: interview_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interview_feedback (id, interview_schedule_id, interviewer_id, technical_skills, communication, problem_solving, cultural_fit, motivation, overall_rating, strengths, weaknesses, detailed_notes, recommendation, submitted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: interview_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interview_schedules (id, job_application_id, interview_type, interview_stage, scheduled_at, duration_minutes, location, meeting_type, meeting_link, meeting_password, interviewer_ids, status, notes, reminder_sent_at, completed_at, created_by, created_at, updated_at, recruitment_stage_id) FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_items (id, invoice_id, description, quantity, unit_price, amount, "order", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, project_id, invoice_number, invoice_date, due_date, subtotal, tax_rate, tax_amount, total_amount, paid_amount, remaining_amount, status, notes, client_name, client_address, client_tax_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_applications (id, job_vacancy_id, full_name, email, phone, birth_date, gender, address, education_level, major, institution, graduation_year, gpa, work_experience, has_experience_ukl_upl, skills, cv_path, portfolio_path, cover_letter, expected_salary, available_from, status, notes, reviewed_at, reviewed_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: job_vacancies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_vacancies (id, title, slug, "position", description, responsibilities, qualifications, benefits, employment_type, location, salary_min, salary_max, salary_negotiable, deadline, status, google_form_url, applications_count, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: kbli; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kbli (id, code, description, sector, notes, created_at, updated_at, category, activities, examples, complexity_level, default_direct_costs, default_hours_estimate, default_hourly_rates, regulatory_flags, recommended_services, is_active, usage_count, deleted_at) FROM stdin;
\.


--
-- Data for Name: kbli_permit_recommendations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kbli_permit_recommendations (id, kbli_code, business_scale, location_type, recommended_permits, required_documents, risk_assessment, estimated_timeline, additional_notes, ai_model, ai_prompt_hash, confidence_score, cache_hits, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kblis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kblis (id, code, title, category, description, activities, complexity_level, default_direct_costs, default_hours_estimate, default_hourly_rates, regulatory_flags, recommended_services, examples, notes, is_active, usage_count, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: keyword_clusters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keyword_clusters (id, seed_keyword, cluster_name, search_intent, keywords, long_tail_keywords, language, category, service_slug, estimated_volume, difficulty_score, priority, articles_count, status, last_researched_at, created_at, updated_at, gsc_clicks, gsc_impressions, gsc_avg_position, gsc_ctr, gsc_synced_at) FROM stdin;
\.


--
-- Data for Name: keyword_position_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keyword_position_history (id, keyword, our_url, "position", previous_position, position_change, data_source, top_competitors, search_volume, search_intent, tracked_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meta_ab_tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meta_ab_tests (id, article_id, test_type, variant_a_title, variant_a_description, variant_b_title, variant_b_description, variant_a_impressions, variant_a_clicks, variant_b_impressions, variant_b_clicks, winner, confidence, status, started_at, ended_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_10_01_154236_create_institutions_table	1
5	2025_10_01_154240_create_project_statuses_table	1
6	2025_10_01_154249_create_projects_table	1
7	2025_10_01_154250_create_tasks_table	1
8	2025_10_01_154251_create_documents_table	1
9	2025_10_01_154252_create_project_logs_table	1
10	2025_10_01_154525_modify_users_table_for_perizinan	1
11	2025_10_01_162642_update_projects_table_structure	1
12	2025_10_01_162947_update_project_logs_user_id_nullable	1
13	2025_10_02_083808_add_financial_columns_to_projects_table	1
14	2025_10_02_083820_create_cash_accounts_table	1
15	2025_10_02_083827_create_project_payments_table	1
16	2025_10_02_083833_create_project_expenses_table	1
17	2025_10_02_091228_fix_payment_method_enum_values	1
18	2025_10_02_094020_create_permit_types_table	1
19	2025_10_02_094048_create_permit_templates_table	1
20	2025_10_02_094049_create_permit_template_items_table	1
21	2025_10_02_094050_create_permit_template_dependencies_table	1
22	2025_10_02_094102_create_project_permits_table	1
23	2025_10_02_094103_create_project_permit_dependencies_table	1
24	2025_10_02_155735_create_invoices_table	1
25	2025_10_02_155743_create_invoice_items_table	1
26	2025_10_02_155750_create_payment_schedules_table	1
27	2025_10_02_211614_create_permit_documents_table	1
28	2025_10_03_140559_add_permit_id_to_tasks_table	1
29	2025_10_03_163452_create_clients_table	1
30	2025_10_03_163524_add_client_id_to_projects_table	1
31	2025_10_03_194740_add_receivable_fields_to_project_expenses_table	1
32	2025_10_03_200841_update_category_enum_in_project_expenses_table	1
33	2025_10_03_204402_update_payment_method_in_project_expenses_table	1
34	2025_10_03_223304_add_invoice_id_to_project_payments_table	1
35	2025_10_04_000000_add_override_fields_to_project_permits_table	1
36	2025_10_09_190642_make_client_fields_nullable_in_projects_table	1
37	2025_10_09_223659_create_roles_and_permissions_tables	1
38	2025_10_10_115340_create_milestones_table	1
39	2025_10_10_181053_create_bank_reconciliations_table	1
40	2025_10_10_181100_create_bank_statement_entries_table	1
41	2025_10_10_181107_add_reconciliation_columns_to_transactions	1
42	2025_10_10_201930_create_articles_table	1
43	2025_10_11_000000_add_role_id_to_users_table	1
44	2025_10_11_000100_create_system_settings_table	1
45	2025_10_11_000200_create_expense_categories_table	1
46	2025_10_11_000300_create_payment_methods_table	1
47	2025_10_11_000400_create_tax_rates_table	1
48	2025_10_11_000500_create_security_settings_table	1
49	2025_11_03_130751_create_document_templates_table	1
50	2025_11_03_130753_create_ai_processing_logs_table	1
51	2025_11_03_130754_create_document_drafts_table	1
52	2025_11_03_163009_add_soft_deletes_to_document_drafts_table	1
53	2025_11_03_170000_create_compliance_checks_table	1
54	2025_11_11_183329_add_auth_fields_to_clients_table	1
55	2025_11_13_064858_create_job_vacancies_table	1
56	2025_11_13_064910_create_job_applications_table	1
57	2025_11_13_072934_add_unique_email_per_job_to_job_applications	1
58	2025_11_13_081830_create_email_subscribers_table	1
59	2025_11_13_081832_create_email_templates_table	1
60	2025_11_13_081834_create_email_campaigns_table	1
61	2025_11_13_081836_create_email_logs_table	1
62	2025_11_13_081839_create_email_inbox_table	1
63	2025_11_13_141344_add_email_fields_to_users_table	1
64	2025_11_13_141345_create_email_accounts_table	1
65	2025_11_13_141346_create_email_assignments_table	1
66	2025_11_13_141347_add_assignment_fields_to_email_inbox_table	1
67	2025_11_14_000001_add_menu_permissions	1
68	2025_11_14_061948_add_user_extended_fields_to_users_table	1
69	2025_11_14_072139_create_permit_applications_table	1
70	2025_11_14_072140_create_application_documents_table	1
71	2025_11_14_072140_create_quotations_table	1
72	2025_11_14_072141_create_application_status_logs_table	1
73	2025_11_14_072141_create_notifications_table	1
74	2025_11_14_072142_create_payments_table	1
75	2025_11_14_094703_add_permit_application_id_to_projects_table	1
76	2025_11_14_112756_add_converted_to_project_status_to_permit_applications	1
77	2025_11_14_122851_add_review_fields_to_application_documents_table	1
78	2025_11_14_123519_create_application_notes_table	1
79	2025_11_14_130916_add_kbli_to_permit_applications_table	1
80	2025_11_14_133029_create_kbli_table	1
81	2025_11_14_135102_remove_category_from_kbli_table	1
82	2025_11_14_135612_remove_kbli_category_from_permit_applications_table	1
83	2025_11_14_143524_create_kbli_permit_recommendations_table	1
84	2025_11_14_143536_create_ai_query_logs_table	1
85	2025_11_14_143545_add_ai_fields_to_permit_applications_table	1
86	2025_11_14_170218_make_permit_type_id_nullable_in_permit_applications_table	1
87	2025_11_16_105656_create_push_subscriptions_table	1
88	2025_11_16_194237_add_data_column_to_notifications_table	1
89	2025_11_16_232528_make_application_notes_author_id_nullable	1
90	2025_11_17_102953_create_application_revisions_table	1
91	2025_11_17_102954_create_application_location_details_table	1
92	2025_11_17_102955_create_application_legality_documents_table	1
93	2025_11_17_102955_create_quotation_items_table	1
94	2025_11_17_114542_create_business_contexts_table	1
95	2025_11_17_173223_add_profile_picture_to_clients_table	1
96	2025_11_17_210428_add_terms_acceptance_to_permit_applications_table	1
97	2025_11_19_073938_make_client_id_nullable_in_permit_applications	1
98	2025_11_21_043131_create_service_inquiries_table	1
99	2025_11_22_181209_create_notifications_table	1
100	2025_11_22_205447_add_completed_at_to_projects_table	1
101	2025_11_22_224959_make_project_id_nullable_in_project_payments_table	1
102	2025_11_23_000815_create_cash_account_balance_history_table	1
103	2025_11_23_001129_add_cash_account_id_to_payment_schedules_table	1
104	2025_11_23_041541_add_actual_completion_date_to_projects_table	1
105	2025_11_23_111131_create_interview_schedules_table	1
106	2025_11_23_111138_create_interview_feedback_table	1
107	2025_11_23_111138_create_test_templates_table	1
108	2025_11_23_111139_create_recruitment_stages_table	1
109	2025_11_23_111139_create_technical_test_submissions_table	1
110	2025_11_23_111139_create_test_sessions_table	1
111	2025_11_23_111140_create_test_answers_table	1
112	2025_11_23_123025_add_reminder_sent_at_to_interview_schedules_table	1
113	2025_11_23_164516_add_document_editing_fields_to_test_templates_table	1
114	2025_11_23_164602_add_document_editing_fields_to_test_sessions_table	1
115	2025_11_23_174732_drop_test_type_constraint_from_test_templates	1
116	2025_11_24_120001_add_recruitment_stage_links	1
117	2025_11_25_055219_add_soft_deletes_to_test_sessions_table	1
118	2025_11_27_065746_add_reference_attachments_to_test_templates_table	1
119	2025_11_27_114641_create_kblis_table	1
120	2025_11_27_150000_create_kblis_table	1
121	2025_11_27_151000_add_pricing_fields_to_kbli_table	1
122	2025_11_27_160000_create_consult_requests_table	1
123	2025_12_04_105016_add_rag_insights_to_consult_requests	1
124	2025_12_08_165544_create_ai_settings_table	1
125	2025_12_08_172724_create_ai_setting_history_table	1
126	2025_12_12_100000_create_article_topics_table	1
127	2025_12_12_100001_create_auto_post_configs_table	1
128	2025_12_12_100002_create_auto_post_schedules_table	1
129	2025_12_12_100003_create_auto_post_logs_table	1
130	2025_12_12_100004_create_article_topic_similarities_table	1
131	2025_12_17_130415_add_source_type_to_articles_table	1
132	2025_12_17_131711_create_content_syndications_table	1
133	2026_01_03_202134_add_language_support_to_auto_post_system	1
134	2026_01_04_100801_add_language_to_articles_table	1
135	2026_04_09_100000_create_keyword_clusters_table	1
136	2026_04_09_200000_create_seo_analytics_tables	1
137	2026_04_09_210000_create_seo_enhancement_tables	1
138	2026_04_11_120000_add_data_source_to_competitor_analyses	1
139	2026_04_12_140932_create_shapefile_projects_table	1
140	2026_04_12_165126_add_lead_fields_to_shapefile_projects_table	1
141	2026_04_13_100000_add_rtrw_fields_to_shapefile_projects_table	1
142	2026_04_13_120000_add_article_id_to_auto_post_schedules_table	1
143	2026_04_13_192831_add_topic_cluster_id_to_articles_and_topics	1
144	2026_04_13_202448_create_social_posts_table	1
145	2026_04_13_212324_create_keyword_position_history_table	1
146	2026_04_13_223841_add_eeat_fields_to_users_table	1
147	2026_04_14_100000_add_gsc_columns_to_keyword_clusters	1
148	2026_04_15_120000_create_trending_topics_table	1
149	2026_04_16_000001_create_service_cost_requests_table	1
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.milestones (id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, notifiable_type, notifiable_id, type, title, message, icon, related_type, related_id, action_url, read_at, created_at, updated_at, data) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_methods (id, code, name, description, requires_cash_account, is_default, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_schedules (id, project_id, invoice_id, description, amount, due_date, paid_date, status, payment_method, reference_number, notes, created_at, updated_at, is_reconciled, reconciled_at, reconciliation_id, cash_account_id) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, payment_number, payable_type, payable_id, client_id, quotation_id, amount, payment_type, payment_method, gateway_provider, gateway_transaction_id, gateway_response, status, bank_name, account_number, account_holder, transfer_proof_path, verified_by, verified_at, verification_notes, paid_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permission_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_role (id, role_id, permission_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, display_name, "group", description, created_at, updated_at) FROM stdin;
1	recruitment.view_jobs	View Jobs	recruitment	Can view job listings	2026-04-16 15:32:00	2026-04-16 15:32:00
2	recruitment.manage_jobs	Manage Jobs	recruitment	Can create, edit, and delete jobs	2026-04-16 15:32:00	2026-04-16 15:32:00
3	recruitment.view_applications	View Applications	recruitment	Can view job applications	2026-04-16 15:32:00	2026-04-16 15:32:00
4	recruitment.process_applications	Process Applications	recruitment	Can review and process applications	2026-04-16 15:32:00	2026-04-16 15:32:00
5	email.view_inbox	View Inbox	email	Can view email inbox	2026-04-16 15:32:00	2026-04-16 15:32:00
6	email.send_email	Send Email	email	Can send emails	2026-04-16 15:32:00	2026-04-16 15:32:00
7	email.manage_accounts	Manage Email Accounts	email	Can manage email accounts	2026-04-16 15:32:00	2026-04-16 15:32:00
8	email.manage_campaigns	Manage Campaigns	email	Can create and manage email campaigns	2026-04-16 15:32:00	2026-04-16 15:32:00
9	email.manage_subscribers	Manage Subscribers	email	Can manage email subscribers	2026-04-16 15:32:00	2026-04-16 15:32:00
10	email.manage_templates	Manage Templates	email	Can manage email templates	2026-04-16 15:32:00	2026-04-16 15:32:00
11	email.manage_settings	Manage Email Settings	email	Can configure email settings	2026-04-16 15:32:00	2026-04-16 15:32:00
12	institutions.view	View Institutions	institutions	Can view institutions	2026-04-16 15:32:00	2026-04-16 15:32:00
13	institutions.create	Create Institutions	institutions	Can create new institutions	2026-04-16 15:32:00	2026-04-16 15:32:00
14	institutions.edit	Edit Institutions	institutions	Can edit institutions	2026-04-16 15:32:00	2026-04-16 15:32:00
15	institutions.delete	Delete Institutions	institutions	Can delete institutions	2026-04-16 15:32:00	2026-04-16 15:32:00
16	master_data.view	View Master Data	master_data	Can view master data	2026-04-16 15:32:00	2026-04-16 15:32:00
17	master_data.edit_permit_types	Edit Permit Types	master_data	Can edit permit types	2026-04-16 15:32:00	2026-04-16 15:32:00
18	master_data.edit_permit_templates	Edit Permit Templates	master_data	Can edit permit templates	2026-04-16 15:32:00	2026-04-16 15:32:00
19	content.view_articles	View Articles	content	Can view articles	2026-04-16 15:32:00	2026-04-16 15:32:00
20	content.create_articles	Create Articles	content	Can create new articles	2026-04-16 15:32:00	2026-04-16 15:32:00
21	content.edit_articles	Edit Articles	content	Can edit articles	2026-04-16 15:32:00	2026-04-16 15:32:00
22	content.delete_articles	Delete Articles	content	Can delete articles	2026-04-16 15:32:00	2026-04-16 15:32:00
23	content.publish_articles	Publish Articles	content	Can publish articles	2026-04-16 15:32:00	2026-04-16 15:32:00
\.


--
-- Data for Name: permit_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_applications (id, application_number, client_id, permit_type_id, status, form_data, notes, admin_notes, reviewed_by, reviewed_at, quoted_price, quoted_at, quotation_expires_at, quotation_notes, down_payment_amount, down_payment_percentage, payment_status, project_id, converted_at, submitted_at, created_at, updated_at, deleted_at, kbli_code, kbli_description, ai_recommendation_id, business_context, terms_accepted_at, terms_version, terms_accepted_language, terms_ip_address, terms_user_agent) FROM stdin;
\.


--
-- Data for Name: permit_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_documents (id, project_permit_id, filename, original_filename, file_path, file_type, file_size, description, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permit_template_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_template_dependencies (id, template_id, permit_item_id, depends_on_item_id, dependency_type, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permit_template_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_template_items (id, template_id, permit_type_id, custom_permit_name, sequence_order, is_goal_permit, estimated_days, estimated_cost, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permit_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_templates (id, name, description, use_case, category, created_by_user_id, is_public, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permit_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_types (id, name, code, category, institution_id, avg_processing_days, description, required_documents, estimated_cost_min, estimated_cost_max, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_expenses (id, project_id, expense_date, vendor_name, amount, bank_account_id, description, receipt_file, is_billable, created_by, created_at, updated_at, is_receivable, receivable_from, receivable_status, receivable_paid_amount, receivable_notes, category, payment_method, is_reconciled, reconciled_at, reconciliation_id) FROM stdin;
\.


--
-- Data for Name: project_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_logs (id, project_id, user_id, action, entity_type, entity_id, description, old_values, new_values, notes, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_payments (id, project_id, payment_date, amount, payment_type, bank_account_id, reference_number, description, receipt_file, created_by, created_at, updated_at, payment_method, invoice_id, is_reconciled, reconciled_at, reconciliation_id) FROM stdin;
\.


--
-- Data for Name: project_permit_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_permit_dependencies (id, project_permit_id, depends_on_permit_id, dependency_type, can_proceed_without, override_reason, override_document_path, overridden_by_user_id, overridden_at, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_permits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_permits (id, project_id, permit_type_id, custom_permit_name, custom_institution_name, sequence_order, is_goal_permit, status, has_existing_document, existing_document_id, assigned_to_user_id, started_at, submitted_at, approved_at, rejected_at, target_date, estimated_cost, actual_cost, permit_number, valid_until, notes, created_at, updated_at, override_dependencies, override_reason, override_by_user_id, override_at) FROM stdin;
\.


--
-- Data for Name: project_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_statuses (id, name, code, description, color, sort_order, is_active, is_final, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, description, client_name, client_address, status_id, institution_id, notes, created_at, updated_at, client_contact, start_date, deadline, progress_percentage, budget, actual_cost, contract_value, down_payment, payment_received, total_expenses, profit_margin, payment_terms, payment_status, client_id, permit_application_id, completed_at, completion_notes, actual_completion_date) FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_subscriptions (id, subscribable_type, subscribable_id, endpoint, public_key, auth_token, content_encoding, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quotation_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotation_items (id, application_id, revision_id, item_type, permit_type_id, item_name, description, unit_price, quantity, subtotal, service_type, estimated_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotations (id, quotation_number, application_id, client_id, base_price, additional_fees, discount_amount, tax_percentage, tax_amount, total_amount, down_payment_percentage, down_payment_amount, payment_terms, valid_until, terms_and_conditions, status, accepted_at, rejected_at, rejection_reason, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ranking_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ranking_alerts (id, position_history_id, keyword, alert_type, severity, old_position, new_position, message, details, is_read, is_actioned, actioned_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recruitment_stages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recruitment_stages (id, job_application_id, stage_name, stage_order, status, score, notes, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, display_name, description, is_system, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: search_console_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.search_console_data (id, page_url, query, date, clicks, impressions, ctr, "position", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_settings (id, min_password_length, require_special_char, require_number, require_mixed_case, enforce_password_expiration, password_expiration_days, session_timeout_minutes, allow_concurrent_sessions, two_factor_enabled, activity_log_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seo_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_reports (id, period, period_start, period_end, metrics, top_articles, alerts, emailed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seo_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_scores (id, article_id, total_score, factors, recommendations, scored_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_cost_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_cost_requests (id, request_number, applicant_type, name, email, phone, address, city, province, nik, occupation, company_name, npwp, nib, business_type, business_sector, pic_name, pic_position, service_category, services_requested, project_description, project_location, estimated_budget, timeline_expectation, documents, status, admin_notes, quoted_price, quote_details, quoted_at, responded_at, source, referral_code, ip_address, user_agent, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: service_inquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_inquiries (id, inquiry_number, email, company_name, company_type, phone, contact_person, "position", kbli_code, kbli_description, business_activity, form_data, ai_analysis, ai_model_used, ai_processing_time, ai_tokens_used, analyzed_at, status, priority, source, utm_source, utm_medium, utm_campaign, client_id, converted_to_application_id, converted_at, ip_address, user_agent, session_id, last_contacted_at, contacted_by, admin_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
Scg6r0i5mQCIg9ClU5Hf3uKzEdbwpLRuw87rUkI1	\N	104.22.24.210	Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.177 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZnpudDMzVnBTMVEwSHRENERTUHZia0RLUjNXclJITTRMOFVtNUZxeiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxMDM6Imh0dHBzOi8vYml6bWFyay5pZC9ibG9nL25ldy1oYWxhbC1jZXJ0aWZpY2F0aW9uLXJlcXVpcmVtZW50cy1mb3ItaW50ZXJuYXRpb25hbC1mYi1jb21wYW5pZXMtMjAyNi11cGRhdGUiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776328326
DoUaNc5Hzc85tZEAqaUElbzdpVt6rQpbMy0zjKv9	\N	172.71.124.162	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3.1 Safari/605.1.15	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiU05TMlAyNUhEdlo0dHdTZjFQZmNiYjVldFpzOW1NU3hEMzdUemJNUSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo1MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4vaXppbi1vcGVyYXNpb25hbC9tYWdlbGFuZyI7czo1OiJyb3V0ZSI7czozMjoicHJvZ3JhbW1hdGljLnNlcnZpY2UtbG9jYXRpb24uaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776328365
GU2WvfOiR8qkrIXAqTmnV8rLWSfkq3EVtiakM4V6	\N	172.69.176.12	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNTV1Q1gyNGo1clJPaU96cUZtRVFpZTF5b2VHT1MwV0I5dW1iRVZjeCI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6OTM6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nLzctY3JpdGljYWwtY2hhbmdlcy10by1pbmRvbmVzaWFzLWludmVzdG1lbnQtcHJpb3JpdHktbGlzdC1kc3AtMjAyNiI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776328425
gDy7FS5YFb0czWR2zrv21SoCnnkAYT7LeC7z8ZRa	\N	172.71.82.93	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoidW1vVldVVTFxcTU4bnhnOThxTlpmbDdmVHY3MVhqdzFMb2hPR3VOOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjQ6Imh0dHBzOi8vYml6bWFyay5pZC9oYWRleiI7czo1OiJyb3V0ZSI7czoxMToiYWRtaW4ubG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776328438
Y15CuylSsZcvYf7wIUVRd0UiqCFDBnqVkMm8NruB	\N	172.71.159.112	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiQnZnU1NuanpjN2dCbkpKMm45S0dLc0ozNGNFNFloekk0UnhZdllBUyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxMTA6Imh0dHBzOi8vYml6bWFyay5pZC9ibG9nL3RoZS1ldm9sdXRpb24tb2YtZW52aXJvbm1lbnRhbC1pbXBhY3QtYXNzZXNzbWVudC1hbWRhbC1pbi1pbmRvbmVzaWEtd2hhdHMtbmV3LWZvci0yMDI2IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776328472
JDIzxaevLoLxsvjO8DWUfGT5hEVLfevYA1LtBBDd	\N	172.70.34.34	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiM05mRlVEY29jNjJ3aEpwbFBsSWhTNUNqRmhLYzZKYlBqTmhNdHNTbCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo5MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvYmlheWEtaGlkZGVuLWRhbGFtLXByb3Nlcy1wZXJpemluYW4tdXNhaGEteWFuZy1oYXJ1cy1kaXdhc3BhZGFpLTIwMjYiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776328550
8fB9hzvjJvKbmyL8tL65bGp7lANrUXGdVFnd8OA6	\N	172.68.87.233	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoidm5XMGhhMTBEbElNRU1HUTJMNlZ1dDhnSTUwMDkydVlwbjFER0YxbSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGltZWxpbmUtcHJvc2VzLXBlcml6aW5hbi1iZXJhcGEtbGFtYS1zZXRpYXAtaXppbi1kaXByb3NlcyI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776328555
WQzgz0YQWdg4g4gLyg19a9b7R1O8OktDMTPTki4a	\N	172.70.142.199	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRllzV1lmSmlvNXc3cGhCTHkxUUlnTXUyaHZKbjN0ejBzazNKY0NjeCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGltZWxpbmUtcHJvc2VzLXBlcml6aW5hbi1iZXJhcGEtbGFtYS1zZXRpYXAtaXppbi1kaXByb3NlcyI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776328555
Xo2mx0HHC30k4EVmlgGBdbjUe5q7zdysMGasa1WL	\N	162.158.170.218	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWm42c1ZSSXYzbm1rQmpIM2RxUnVJd2t4NnVkbmd3dWFmTHVxMzF0MSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nIjtzOjU6InJvdXRlIjtzOjEzOiJibG9nLmluZGV4LmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7fQ==	1776328841
\.


--
-- Data for Name: shapefile_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shapefile_projects (id, user_id, name, geojson, area_m2, area_ha, perimeter_m, metadata, file_path, session_token, created_at, updated_at, company_name, contact_person, email, phone, agreed_terms_at, service_inquiry_id, ip_address, user_agent, rtrw_zona, rtrw_perda, rtrw_remark, rtrw_raw) FROM stdin;
\.


--
-- Data for Name: social_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_posts (id, article_id, platform, caption, platform_post_id, platform_url, status, posted_at, scheduled_for, metrics, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, company_name, company_email, company_phone, company_website, company_address, maintenance_mode, email_notifications, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, project_id, title, description, sop_notes, assigned_user_id, due_date, started_at, completed_at, status, priority, institution_id, depends_on_task_id, completion_notes, estimated_hours, actual_hours, sort_order, created_at, updated_at, project_permit_id) FROM stdin;
\.


--
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_rates (id, name, rate, description, is_default, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: technical_test_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technical_test_submissions (id, job_application_id, test_title, test_description, original_file_path, submission_file_path, file_type, format_score, format_issues, reviewer_id, review_score, review_notes, reviewed_at, status, submitted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_answers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_answers (id, test_session_id, question_id, answer_data, is_correct, points_earned, time_spent_seconds, answered_at) FROM stdin;
\.


--
-- Data for Name: test_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_sessions (id, job_application_id, test_template_id, session_token, status, starts_at, expires_at, started_at, completed_at, score, passed, time_taken_minutes, ip_address, user_agent, tab_switches, created_at, updated_at, submitted_file_path, submitted_at, evaluation_scores, evaluator_id, evaluator_notes, evaluated_at, requires_manual_review, recruitment_stage_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: test_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_templates (id, title, test_type, description, duration_minutes, passing_score, questions_data, instructions, is_active, created_by, created_at, updated_at, template_file_path, evaluation_criteria) FROM stdin;
\.


--
-- Data for Name: topic_clusters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.topic_clusters (id, pillar_title, pillar_slug, pillar_description, service_slug, language, subtopics, article_ids, keyword_cluster_ids, status, internal_links_built, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trending_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trending_topics (id, topic, category, language, data_source, trend_score, search_volume, related_keywords, top_sources, sample_headline, is_processed, article_id, discovered_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, full_name, "position", phone, is_active, last_login_at, notes, avatar, role_id, company_email, department, email_signature, job_title, notification_preferences, working_hours, username, employee_id, bio, expertise, linkedin_url, twitter_url) FROM stdin;
\.


--
-- Name: ai_processing_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_processing_logs_id_seq', 1, false);


--
-- Name: ai_query_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_query_logs_id_seq', 1, false);


--
-- Name: ai_setting_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_setting_history_id_seq', 1, false);


--
-- Name: ai_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_settings_id_seq', 1, false);


--
-- Name: application_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_documents_id_seq', 1, false);


--
-- Name: application_legality_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_legality_documents_id_seq', 1, false);


--
-- Name: application_location_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_location_details_id_seq', 1, false);


--
-- Name: application_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_notes_id_seq', 1, false);


--
-- Name: application_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_revisions_id_seq', 1, false);


--
-- Name: application_status_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_status_logs_id_seq', 1, false);


--
-- Name: article_topic_similarities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_topic_similarities_id_seq', 1, false);


--
-- Name: article_topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_topics_id_seq', 1, false);


--
-- Name: article_view_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_view_logs_id_seq', 1, false);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.articles_id_seq', 1, false);


--
-- Name: auto_post_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_post_configs_id_seq', 1, false);


--
-- Name: auto_post_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_post_logs_id_seq', 1, false);


--
-- Name: auto_post_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_post_schedules_id_seq', 1, false);


--
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_reconciliations_id_seq', 1, false);


--
-- Name: bank_statement_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_statement_entries_id_seq', 1, false);


--
-- Name: business_contexts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.business_contexts_id_seq', 1, false);


--
-- Name: cash_account_balance_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cash_account_balance_history_id_seq', 1, false);


--
-- Name: cash_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cash_accounts_id_seq', 1, false);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clients_id_seq', 1, false);


--
-- Name: competitor_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.competitor_analyses_id_seq', 1, false);


--
-- Name: compliance_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_checks_id_seq', 1, false);


--
-- Name: consult_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.consult_requests_id_seq', 1, false);


--
-- Name: content_gaps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_gaps_id_seq', 1, false);


--
-- Name: content_refresh_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_refresh_logs_id_seq', 1, false);


--
-- Name: content_syndications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_syndications_id_seq', 1, false);


--
-- Name: document_drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_drafts_id_seq', 1, false);


--
-- Name: document_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_templates_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: email_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_accounts_id_seq', 1, false);


--
-- Name: email_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_assignments_id_seq', 1, false);


--
-- Name: email_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_campaigns_id_seq', 1, false);


--
-- Name: email_inbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_inbox_id_seq', 1, false);


--
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_logs_id_seq', 1, false);


--
-- Name: email_subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_subscribers_id_seq', 1, false);


--
-- Name: email_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_templates_id_seq', 1, false);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: institutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.institutions_id_seq', 1, false);


--
-- Name: interview_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.interview_feedback_id_seq', 1, false);


--
-- Name: interview_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.interview_schedules_id_seq', 1, false);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: job_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_applications_id_seq', 1, false);


--
-- Name: job_vacancies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_vacancies_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: kbli_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kbli_id_seq', 1, false);


--
-- Name: kbli_permit_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kbli_permit_recommendations_id_seq', 1, false);


--
-- Name: kblis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kblis_id_seq', 1, false);


--
-- Name: keyword_clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.keyword_clusters_id_seq', 1, false);


--
-- Name: keyword_position_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.keyword_position_history_id_seq', 1, false);


--
-- Name: meta_ab_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meta_ab_tests_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 149, true);


--
-- Name: milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.milestones_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 1, false);


--
-- Name: payment_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_schedules_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: permission_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permission_role_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 23, true);


--
-- Name: permit_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_applications_id_seq', 1, false);


--
-- Name: permit_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_documents_id_seq', 1, false);


--
-- Name: permit_template_dependencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_template_dependencies_id_seq', 1, false);


--
-- Name: permit_template_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_template_items_id_seq', 1, false);


--
-- Name: permit_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_templates_id_seq', 1, false);


--
-- Name: permit_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_types_id_seq', 1, false);


--
-- Name: project_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_expenses_id_seq', 1, false);


--
-- Name: project_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_logs_id_seq', 1, false);


--
-- Name: project_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_payments_id_seq', 1, false);


--
-- Name: project_permit_dependencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_permit_dependencies_id_seq', 1, false);


--
-- Name: project_permits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_permits_id_seq', 1, false);


--
-- Name: project_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_statuses_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 1, false);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotation_items_id_seq', 1, false);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, false);


--
-- Name: ranking_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ranking_alerts_id_seq', 1, false);


--
-- Name: recruitment_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recruitment_stages_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: search_console_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.search_console_data_id_seq', 1, false);


--
-- Name: security_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.security_settings_id_seq', 1, false);


--
-- Name: seo_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_reports_id_seq', 1, false);


--
-- Name: seo_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_scores_id_seq', 1, false);


--
-- Name: service_cost_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_cost_requests_id_seq', 1, false);


--
-- Name: service_inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_inquiries_id_seq', 1, false);


--
-- Name: shapefile_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shapefile_projects_id_seq', 1, false);


--
-- Name: social_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_posts_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: tax_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tax_rates_id_seq', 1, false);


--
-- Name: technical_test_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.technical_test_submissions_id_seq', 1, false);


--
-- Name: test_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.test_answers_id_seq', 1, false);


--
-- Name: test_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.test_sessions_id_seq', 1, false);


--
-- Name: test_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.test_templates_id_seq', 1, false);


--
-- Name: topic_clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.topic_clusters_id_seq', 1, false);


--
-- Name: trending_topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trending_topics_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: ai_processing_logs ai_processing_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_pkey PRIMARY KEY (id);


--
-- Name: ai_query_logs ai_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_pkey PRIMARY KEY (id);


--
-- Name: ai_setting_history ai_setting_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history
    ADD CONSTRAINT ai_setting_history_pkey PRIMARY KEY (id);


--
-- Name: ai_settings ai_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_key_unique UNIQUE (key);


--
-- Name: ai_settings ai_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_pkey PRIMARY KEY (id);


--
-- Name: application_documents application_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_pkey PRIMARY KEY (id);


--
-- Name: application_legality_documents application_legality_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_legality_documents
    ADD CONSTRAINT application_legality_documents_pkey PRIMARY KEY (id);


--
-- Name: application_location_details application_location_details_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details
    ADD CONSTRAINT application_location_details_application_id_unique UNIQUE (application_id);


--
-- Name: application_location_details application_location_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details
    ADD CONSTRAINT application_location_details_pkey PRIMARY KEY (id);


--
-- Name: application_notes application_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes
    ADD CONSTRAINT application_notes_pkey PRIMARY KEY (id);


--
-- Name: application_revisions application_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions
    ADD CONSTRAINT application_revisions_pkey PRIMARY KEY (id);


--
-- Name: application_status_logs application_status_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_status_logs
    ADD CONSTRAINT application_status_logs_pkey PRIMARY KEY (id);


--
-- Name: article_topic_similarities article_topic_similarities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_pkey PRIMARY KEY (id);


--
-- Name: article_topic_similarities article_topic_similarities_topic_a_id_topic_b_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_topic_a_id_topic_b_id_unique UNIQUE (topic_a_id, topic_b_id);


--
-- Name: article_topics article_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_pkey PRIMARY KEY (id);


--
-- Name: article_topics article_topics_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_slug_unique UNIQUE (slug);


--
-- Name: article_topics article_topics_title_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_title_unique UNIQUE (title);


--
-- Name: article_view_logs article_view_logs_article_id_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs
    ADD CONSTRAINT article_view_logs_article_id_date_unique UNIQUE (article_id, date);


--
-- Name: article_view_logs article_view_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs
    ADD CONSTRAINT article_view_logs_pkey PRIMARY KEY (id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles articles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_unique UNIQUE (slug);


--
-- Name: auto_post_configs auto_post_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_configs
    ADD CONSTRAINT auto_post_configs_pkey PRIMARY KEY (id);


--
-- Name: auto_post_logs auto_post_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_pkey PRIMARY KEY (id);


--
-- Name: auto_post_schedules auto_post_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules
    ADD CONSTRAINT auto_post_schedules_pkey PRIMARY KEY (id);


--
-- Name: bank_reconciliations bank_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: bank_statement_entries bank_statement_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_entries
    ADD CONSTRAINT bank_statement_entries_pkey PRIMARY KEY (id);


--
-- Name: business_contexts business_contexts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts
    ADD CONSTRAINT business_contexts_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: cash_account_balance_history cash_account_balance_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history
    ADD CONSTRAINT cash_account_balance_history_pkey PRIMARY KEY (id);


--
-- Name: cash_accounts cash_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_accounts
    ADD CONSTRAINT cash_accounts_pkey PRIMARY KEY (id);


--
-- Name: clients clients_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_email_unique UNIQUE (email);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: competitor_analyses competitor_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_analyses
    ADD CONSTRAINT competitor_analyses_pkey PRIMARY KEY (id);


--
-- Name: compliance_checks compliance_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_pkey PRIMARY KEY (id);


--
-- Name: consult_requests consult_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_pkey PRIMARY KEY (id);


--
-- Name: content_gaps content_gaps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps
    ADD CONSTRAINT content_gaps_pkey PRIMARY KEY (id);


--
-- Name: content_refresh_logs content_refresh_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_refresh_logs
    ADD CONSTRAINT content_refresh_logs_pkey PRIMARY KEY (id);


--
-- Name: content_syndications content_syndications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_syndications
    ADD CONSTRAINT content_syndications_pkey PRIMARY KEY (id);


--
-- Name: document_drafts document_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_accounts email_accounts_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_accounts
    ADD CONSTRAINT email_accounts_email_unique UNIQUE (email);


--
-- Name: email_accounts email_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_accounts
    ADD CONSTRAINT email_accounts_pkey PRIMARY KEY (id);


--
-- Name: email_assignments email_assignments_email_account_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_email_account_id_user_id_unique UNIQUE (email_account_id, user_id);


--
-- Name: email_assignments email_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_pkey PRIMARY KEY (id);


--
-- Name: email_campaigns email_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_pkey PRIMARY KEY (id);


--
-- Name: email_inbox email_inbox_message_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_message_id_unique UNIQUE (message_id);


--
-- Name: email_inbox email_inbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_tracking_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_tracking_id_unique UNIQUE (tracking_id);


--
-- Name: email_subscribers email_subscribers_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_subscribers
    ADD CONSTRAINT email_subscribers_email_unique UNIQUE (email);


--
-- Name: email_subscribers email_subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_subscribers
    ADD CONSTRAINT email_subscribers_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_slug_unique UNIQUE (slug);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: institutions institutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_pkey PRIMARY KEY (id);


--
-- Name: interview_feedback interview_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT interview_feedback_pkey PRIMARY KEY (id);


--
-- Name: interview_schedules interview_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_unique UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: job_vacancies job_vacancies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_vacancies
    ADD CONSTRAINT job_vacancies_pkey PRIMARY KEY (id);


--
-- Name: job_vacancies job_vacancies_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_vacancies
    ADD CONSTRAINT job_vacancies_slug_unique UNIQUE (slug);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: kbli kbli_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli
    ADD CONSTRAINT kbli_code_unique UNIQUE (code);


--
-- Name: kbli_permit_recommendations kbli_permit_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli_permit_recommendations
    ADD CONSTRAINT kbli_permit_recommendations_pkey PRIMARY KEY (id);


--
-- Name: kbli kbli_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli
    ADD CONSTRAINT kbli_pkey PRIMARY KEY (id);


--
-- Name: kblis kblis_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kblis
    ADD CONSTRAINT kblis_code_unique UNIQUE (code);


--
-- Name: kblis kblis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kblis
    ADD CONSTRAINT kblis_pkey PRIMARY KEY (id);


--
-- Name: keyword_clusters keyword_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_clusters
    ADD CONSTRAINT keyword_clusters_pkey PRIMARY KEY (id);


--
-- Name: keyword_position_history keyword_position_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_position_history
    ADD CONSTRAINT keyword_position_history_pkey PRIMARY KEY (id);


--
-- Name: meta_ab_tests meta_ab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_ab_tests
    ADD CONSTRAINT meta_ab_tests_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: payment_methods payment_methods_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_code_unique UNIQUE (code);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_schedules payment_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_pkey PRIMARY KEY (id);


--
-- Name: payments payments_payment_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_number_unique UNIQUE (payment_number);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permission_role permission_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_pkey PRIMARY KEY (id);


--
-- Name: permission_role permission_role_role_id_permission_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_role_id_permission_id_unique UNIQUE (role_id, permission_id);


--
-- Name: permissions permissions_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_unique UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: permit_applications permit_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_application_number_unique UNIQUE (application_number);


--
-- Name: permit_applications permit_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_pkey PRIMARY KEY (id);


--
-- Name: permit_documents permit_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents
    ADD CONSTRAINT permit_documents_pkey PRIMARY KEY (id);


--
-- Name: permit_template_dependencies permit_template_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_pkey PRIMARY KEY (id);


--
-- Name: permit_template_items permit_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items
    ADD CONSTRAINT permit_template_items_pkey PRIMARY KEY (id);


--
-- Name: permit_templates permit_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_templates
    ADD CONSTRAINT permit_templates_pkey PRIMARY KEY (id);


--
-- Name: permit_types permit_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types
    ADD CONSTRAINT permit_types_code_unique UNIQUE (code);


--
-- Name: permit_types permit_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types
    ADD CONSTRAINT permit_types_pkey PRIMARY KEY (id);


--
-- Name: project_expenses project_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_pkey PRIMARY KEY (id);


--
-- Name: project_logs project_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs
    ADD CONSTRAINT project_logs_pkey PRIMARY KEY (id);


--
-- Name: project_payments project_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_pkey PRIMARY KEY (id);


--
-- Name: project_permit_dependencies project_permit_dep_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dep_unique UNIQUE (project_permit_id, depends_on_permit_id);


--
-- Name: project_permit_dependencies project_permit_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_pkey PRIMARY KEY (id);


--
-- Name: project_permits project_permits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_pkey PRIMARY KEY (id);


--
-- Name: project_statuses project_statuses_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT project_statuses_code_unique UNIQUE (code);


--
-- Name: project_statuses project_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT project_statuses_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_unique UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_quotation_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_quotation_number_unique UNIQUE (quotation_number);


--
-- Name: ranking_alerts ranking_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranking_alerts
    ADD CONSTRAINT ranking_alerts_pkey PRIMARY KEY (id);


--
-- Name: recruitment_stages recruitment_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages
    ADD CONSTRAINT recruitment_stages_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: search_console_data search_console_data_page_url_query_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_console_data
    ADD CONSTRAINT search_console_data_page_url_query_date_unique UNIQUE (page_url, query, date);


--
-- Name: search_console_data search_console_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_console_data
    ADD CONSTRAINT search_console_data_pkey PRIMARY KEY (id);


--
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- Name: seo_reports seo_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_reports
    ADD CONSTRAINT seo_reports_pkey PRIMARY KEY (id);


--
-- Name: seo_scores seo_scores_article_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores
    ADD CONSTRAINT seo_scores_article_id_unique UNIQUE (article_id);


--
-- Name: seo_scores seo_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores
    ADD CONSTRAINT seo_scores_pkey PRIMARY KEY (id);


--
-- Name: service_cost_requests service_cost_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_cost_requests
    ADD CONSTRAINT service_cost_requests_pkey PRIMARY KEY (id);


--
-- Name: service_cost_requests service_cost_requests_request_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_cost_requests
    ADD CONSTRAINT service_cost_requests_request_number_unique UNIQUE (request_number);


--
-- Name: service_inquiries service_inquiries_inquiry_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_inquiry_number_unique UNIQUE (inquiry_number);


--
-- Name: service_inquiries service_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shapefile_projects shapefile_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects
    ADD CONSTRAINT shapefile_projects_pkey PRIMARY KEY (id);


--
-- Name: social_posts social_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_posts
    ADD CONSTRAINT social_posts_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- Name: technical_test_submissions technical_test_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions
    ADD CONSTRAINT technical_test_submissions_pkey PRIMARY KEY (id);


--
-- Name: test_answers test_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_answers
    ADD CONSTRAINT test_answers_pkey PRIMARY KEY (id);


--
-- Name: test_sessions test_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_pkey PRIMARY KEY (id);


--
-- Name: test_sessions test_sessions_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_session_token_unique UNIQUE (session_token);


--
-- Name: test_templates test_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_templates
    ADD CONSTRAINT test_templates_pkey PRIMARY KEY (id);


--
-- Name: topic_clusters topic_clusters_pillar_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topic_clusters
    ADD CONSTRAINT topic_clusters_pillar_slug_unique UNIQUE (pillar_slug);


--
-- Name: topic_clusters topic_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topic_clusters
    ADD CONSTRAINT topic_clusters_pkey PRIMARY KEY (id);


--
-- Name: trending_topics trending_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trending_topics
    ADD CONSTRAINT trending_topics_pkey PRIMARY KEY (id);


--
-- Name: job_applications unique_email_per_job; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT unique_email_per_job UNIQUE (job_vacancy_id, email);


--
-- Name: interview_feedback unique_feedback; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT unique_feedback UNIQUE (interview_schedule_id, interviewer_id);


--
-- Name: recruitment_stages unique_stage; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages
    ADD CONSTRAINT unique_stage UNIQUE (job_application_id, stage_name);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_employee_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_id_unique UNIQUE (employee_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: ai_processing_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_processing_logs_created_at_index ON public.ai_processing_logs USING btree (created_at);


--
-- Name: ai_processing_logs_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_processing_logs_project_id_index ON public.ai_processing_logs USING btree (project_id);


--
-- Name: ai_processing_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_processing_logs_status_index ON public.ai_processing_logs USING btree (status);


--
-- Name: ai_query_logs_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_client_id_index ON public.ai_query_logs USING btree (client_id);


--
-- Name: ai_query_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_created_at_index ON public.ai_query_logs USING btree (created_at);


--
-- Name: ai_query_logs_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_kbli_code_index ON public.ai_query_logs USING btree (kbli_code);


--
-- Name: ai_query_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_status_index ON public.ai_query_logs USING btree (status);


--
-- Name: ai_setting_history_changed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_changed_by_index ON public.ai_setting_history USING btree (changed_by);


--
-- Name: ai_setting_history_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_created_at_index ON public.ai_setting_history USING btree (created_at);


--
-- Name: ai_setting_history_key_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_key_index ON public.ai_setting_history USING btree (key);


--
-- Name: ai_setting_history_setting_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_setting_id_index ON public.ai_setting_history USING btree (setting_id);


--
-- Name: ai_settings_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_settings_category_index ON public.ai_settings USING btree (category);


--
-- Name: ai_settings_group_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_settings_group_name_index ON public.ai_settings USING btree (group_name);


--
-- Name: application_documents_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_documents_application_id_index ON public.application_documents USING btree (application_id);


--
-- Name: application_documents_document_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_documents_document_type_index ON public.application_documents USING btree (document_type);


--
-- Name: application_legality_documents_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_legality_documents_application_id_index ON public.application_legality_documents USING btree (application_id);


--
-- Name: application_legality_documents_document_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_legality_documents_document_category_index ON public.application_legality_documents USING btree (document_category);


--
-- Name: application_legality_documents_is_available_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_legality_documents_is_available_index ON public.application_legality_documents USING btree (is_available);


--
-- Name: application_location_details_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_location_details_application_id_index ON public.application_location_details USING btree (application_id);


--
-- Name: application_location_details_city_regency_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_location_details_city_regency_index ON public.application_location_details USING btree (city_regency);


--
-- Name: application_location_details_province_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_location_details_province_index ON public.application_location_details USING btree (province);


--
-- Name: application_notes_application_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_notes_application_id_created_at_index ON public.application_notes USING btree (application_id, created_at);


--
-- Name: application_revisions_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_revisions_application_id_index ON public.application_revisions USING btree (application_id);


--
-- Name: application_revisions_application_id_revision_number_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_revisions_application_id_revision_number_index ON public.application_revisions USING btree (application_id, revision_number);


--
-- Name: application_revisions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_revisions_status_index ON public.application_revisions USING btree (status);


--
-- Name: application_status_logs_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_status_logs_application_id_index ON public.application_status_logs USING btree (application_id);


--
-- Name: application_status_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_status_logs_created_at_index ON public.application_status_logs USING btree (created_at);


--
-- Name: article_topic_similarities_similarity_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topic_similarities_similarity_score_index ON public.article_topic_similarities USING btree (similarity_score);


--
-- Name: article_topics_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_category_index ON public.article_topics USING btree (category);


--
-- Name: article_topics_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_scheduled_for_index ON public.article_topics USING btree (scheduled_for);


--
-- Name: article_topics_status_language_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_status_language_priority_index ON public.article_topics USING btree (status, language, priority);


--
-- Name: article_topics_status_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_status_priority_index ON public.article_topics USING btree (status, priority);


--
-- Name: article_view_logs_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_view_logs_date_index ON public.article_view_logs USING btree (date);


--
-- Name: articles_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_category_index ON public.articles USING btree (category);


--
-- Name: articles_is_featured_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_is_featured_index ON public.articles USING btree (is_featured);


--
-- Name: articles_language_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_language_index ON public.articles USING btree (language);


--
-- Name: articles_source_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_source_type_index ON public.articles USING btree (source_type);


--
-- Name: articles_status_published_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_status_published_at_index ON public.articles USING btree (status, published_at);


--
-- Name: articles_title_content_fulltext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_title_content_fulltext ON public.articles USING gin (((to_tsvector('english'::regconfig, (title)::text) || to_tsvector('english'::regconfig, content))));


--
-- Name: auto_post_logs_created_at_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_logs_created_at_level_index ON public.auto_post_logs USING btree (created_at, level);


--
-- Name: auto_post_logs_event_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_logs_event_index ON public.auto_post_logs USING btree (event);


--
-- Name: auto_post_schedules_scheduled_at_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_schedules_scheduled_at_status_index ON public.auto_post_schedules USING btree (scheduled_at, status);


--
-- Name: auto_post_schedules_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_schedules_status_index ON public.auto_post_schedules USING btree (status);


--
-- Name: bank_reconciliations_cash_account_id_reconciliation_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_reconciliations_cash_account_id_reconciliation_date_index ON public.bank_reconciliations USING btree (cash_account_id, reconciliation_date);


--
-- Name: bank_reconciliations_start_date_end_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_reconciliations_start_date_end_date_index ON public.bank_reconciliations USING btree (start_date, end_date);


--
-- Name: bank_reconciliations_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_reconciliations_status_index ON public.bank_reconciliations USING btree (status);


--
-- Name: bank_statement_entries_is_matched_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_entries_is_matched_index ON public.bank_statement_entries USING btree (is_matched);


--
-- Name: bank_statement_entries_reconciliation_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_entries_reconciliation_id_index ON public.bank_statement_entries USING btree (reconciliation_id);


--
-- Name: bank_statement_entries_transaction_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_entries_transaction_date_index ON public.bank_statement_entries USING btree (transaction_date);


--
-- Name: business_contexts_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX business_contexts_client_id_index ON public.business_contexts USING btree (client_id);


--
-- Name: business_contexts_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX business_contexts_kbli_code_index ON public.business_contexts USING btree (kbli_code);


--
-- Name: business_contexts_submitted_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX business_contexts_submitted_at_index ON public.business_contexts USING btree (submitted_at);


--
-- Name: cash_account_balance_history_cash_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_cash_account_id_index ON public.cash_account_balance_history USING btree (cash_account_id);


--
-- Name: cash_account_balance_history_change_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_change_type_index ON public.cash_account_balance_history USING btree (change_type);


--
-- Name: cash_account_balance_history_changed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_changed_at_index ON public.cash_account_balance_history USING btree (changed_at);


--
-- Name: cash_account_balance_history_reference_type_reference_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_reference_type_reference_id_index ON public.cash_account_balance_history USING btree (reference_type, reference_id);


--
-- Name: cash_accounts_account_type_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_accounts_account_type_is_active_index ON public.cash_accounts USING btree (account_type, is_active);


--
-- Name: clients_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clients_email_index ON public.clients USING btree (email);


--
-- Name: clients_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clients_name_index ON public.clients USING btree (name);


--
-- Name: clients_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clients_status_index ON public.clients USING btree (status);


--
-- Name: competitor_analyses_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX competitor_analyses_analyzed_at_index ON public.competitor_analyses USING btree (analyzed_at);


--
-- Name: competitor_analyses_keyword_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX competitor_analyses_keyword_index ON public.competitor_analyses USING btree (keyword);


--
-- Name: compliance_checks_draft_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compliance_checks_draft_id_index ON public.compliance_checks USING btree (draft_id);


--
-- Name: compliance_checks_overall_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compliance_checks_overall_score_index ON public.compliance_checks USING btree (overall_score);


--
-- Name: compliance_checks_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compliance_checks_status_index ON public.compliance_checks USING btree (status);


--
-- Name: consult_requests_business_size_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_business_size_index ON public.consult_requests USING btree (business_size);


--
-- Name: consult_requests_contacted_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_contacted_index ON public.consult_requests USING btree (contacted);


--
-- Name: consult_requests_converted_to_client_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_converted_to_client_index ON public.consult_requests USING btree (converted_to_client);


--
-- Name: consult_requests_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_created_at_index ON public.consult_requests USING btree (created_at);


--
-- Name: consult_requests_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_email_index ON public.consult_requests USING btree (email);


--
-- Name: consult_requests_estimate_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_estimate_status_index ON public.consult_requests USING btree (estimate_status);


--
-- Name: consult_requests_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_kbli_code_index ON public.consult_requests USING btree (kbli_code);


--
-- Name: consult_requests_phone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_phone_index ON public.consult_requests USING btree (phone);


--
-- Name: consult_requests_rag_confidence_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_rag_confidence_index ON public.consult_requests USING btree (rag_confidence);


--
-- Name: content_gaps_service_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_gaps_service_slug_index ON public.content_gaps USING btree (service_slug);


--
-- Name: content_gaps_status_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_gaps_status_priority_index ON public.content_gaps USING btree (status, priority);


--
-- Name: content_refresh_logs_article_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_refresh_logs_article_id_created_at_index ON public.content_refresh_logs USING btree (article_id, created_at);


--
-- Name: content_refresh_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_refresh_logs_status_index ON public.content_refresh_logs USING btree (status);


--
-- Name: content_syndications_article_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_syndications_article_id_status_index ON public.content_syndications USING btree (article_id, status);


--
-- Name: content_syndications_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_syndications_platform_index ON public.content_syndications USING btree (platform);


--
-- Name: document_drafts_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_drafts_project_id_index ON public.document_drafts USING btree (project_id);


--
-- Name: document_drafts_project_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_drafts_project_id_status_index ON public.document_drafts USING btree (project_id, status);


--
-- Name: document_drafts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_drafts_status_index ON public.document_drafts USING btree (status);


--
-- Name: document_templates_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_templates_is_active_index ON public.document_templates USING btree (is_active);


--
-- Name: document_templates_permit_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_templates_permit_type_index ON public.document_templates USING btree (permit_type);


--
-- Name: documents_project_id_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_project_id_category_index ON public.documents USING btree (project_id, category);


--
-- Name: documents_status_is_latest_version_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_status_is_latest_version_index ON public.documents USING btree (status, is_latest_version);


--
-- Name: documents_uploaded_by_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_uploaded_by_created_at_index ON public.documents USING btree (uploaded_by, created_at);


--
-- Name: email_accounts_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_accounts_email_index ON public.email_accounts USING btree (email);


--
-- Name: email_accounts_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_accounts_is_active_index ON public.email_accounts USING btree (is_active);


--
-- Name: email_assignments_email_account_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_assignments_email_account_id_is_active_index ON public.email_assignments USING btree (email_account_id, is_active);


--
-- Name: email_assignments_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_assignments_user_id_is_active_index ON public.email_assignments USING btree (user_id, is_active);


--
-- Name: email_campaigns_scheduled_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_campaigns_scheduled_at_index ON public.email_campaigns USING btree (scheduled_at);


--
-- Name: email_campaigns_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_campaigns_status_index ON public.email_campaigns USING btree (status);


--
-- Name: email_inbox_assigned_to_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_assigned_to_is_read_index ON public.email_inbox USING btree (assigned_to, is_read);


--
-- Name: email_inbox_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_category_index ON public.email_inbox USING btree (category);


--
-- Name: email_inbox_department_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_department_index ON public.email_inbox USING btree (department);


--
-- Name: email_inbox_email_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_email_account_id_index ON public.email_inbox USING btree (email_account_id);


--
-- Name: email_inbox_from_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_from_email_index ON public.email_inbox USING btree (from_email);


--
-- Name: email_inbox_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_is_read_index ON public.email_inbox USING btree (is_read);


--
-- Name: email_inbox_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_priority_index ON public.email_inbox USING btree (priority);


--
-- Name: email_inbox_received_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_received_at_index ON public.email_inbox USING btree (received_at);


--
-- Name: email_inbox_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_status_index ON public.email_inbox USING btree (status);


--
-- Name: email_inbox_to_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_to_email_index ON public.email_inbox USING btree (to_email);


--
-- Name: email_logs_campaign_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_campaign_id_index ON public.email_logs USING btree (campaign_id);


--
-- Name: email_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_status_index ON public.email_logs USING btree (status);


--
-- Name: email_logs_subscriber_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_subscriber_id_index ON public.email_logs USING btree (subscriber_id);


--
-- Name: email_logs_tracking_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_tracking_id_index ON public.email_logs USING btree (tracking_id);


--
-- Name: email_subscribers_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_subscribers_email_index ON public.email_subscribers USING btree (email);


--
-- Name: email_subscribers_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_subscribers_status_index ON public.email_subscribers USING btree (status);


--
-- Name: email_templates_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_templates_category_index ON public.email_templates USING btree (category);


--
-- Name: email_templates_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_templates_is_active_index ON public.email_templates USING btree (is_active);


--
-- Name: interview_schedules_job_application_id_interview_stage_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_job_application_id_interview_stage_index ON public.interview_schedules USING btree (job_application_id, interview_stage);


--
-- Name: interview_schedules_recruitment_stage_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_recruitment_stage_id_index ON public.interview_schedules USING btree (recruitment_stage_id);


--
-- Name: interview_schedules_scheduled_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_scheduled_at_index ON public.interview_schedules USING btree (scheduled_at);


--
-- Name: interview_schedules_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_status_index ON public.interview_schedules USING btree (status);


--
-- Name: invoice_items_invoice_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoice_items_invoice_id_index ON public.invoice_items USING btree (invoice_id);


--
-- Name: invoices_invoice_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_invoice_date_index ON public.invoices USING btree (invoice_date);


--
-- Name: invoices_invoice_number_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_invoice_number_index ON public.invoices USING btree (invoice_number);


--
-- Name: invoices_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_project_id_index ON public.invoices USING btree (project_id);


--
-- Name: invoices_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_status_index ON public.invoices USING btree (status);


--
-- Name: job_applications_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_applications_email_index ON public.job_applications USING btree (email);


--
-- Name: job_applications_job_vacancy_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_applications_job_vacancy_id_status_index ON public.job_applications USING btree (job_vacancy_id, status);


--
-- Name: job_applications_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_applications_status_index ON public.job_applications USING btree (status);


--
-- Name: job_vacancies_deadline_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_vacancies_deadline_index ON public.job_vacancies USING btree (deadline);


--
-- Name: job_vacancies_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_vacancies_status_index ON public.job_vacancies USING btree (status);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: kbli_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_category_index ON public.kbli USING btree (category);


--
-- Name: kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_code_index ON public.kbli USING btree (code);


--
-- Name: kbli_complexity_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_complexity_level_index ON public.kbli USING btree (complexity_level);


--
-- Name: kbli_description_fulltext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_description_fulltext ON public.kbli USING btree (to_tsvector('indonesian'::regconfig, description));


--
-- Name: kbli_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_is_active_index ON public.kbli USING btree (is_active);


--
-- Name: kbli_permit_recommendations_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_permit_recommendations_expires_at_index ON public.kbli_permit_recommendations USING btree (expires_at);


--
-- Name: kbli_permit_recommendations_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_permit_recommendations_kbli_code_index ON public.kbli_permit_recommendations USING btree (kbli_code);


--
-- Name: kbli_recommendations_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_recommendations_unique ON public.kbli_permit_recommendations USING btree (kbli_code, business_scale, location_type);


--
-- Name: kbli_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_search_idx ON public.kbli USING gin (to_tsvector('indonesian'::regconfig, (((((((code)::text || ' '::text) || description) || ' '::text) || COALESCE(activities, ''::text)) || ' '::text) || (COALESCE(category, ''::character varying))::text)));


--
-- Name: kbli_sector_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_sector_index ON public.kbli USING btree (sector);


--
-- Name: kbli_usage_count_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_usage_count_index ON public.kbli USING btree (usage_count);


--
-- Name: kblis_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kblis_category_index ON public.kblis USING btree (category);


--
-- Name: kblis_complexity_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kblis_complexity_level_index ON public.kblis USING btree (complexity_level);


--
-- Name: kblis_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kblis_is_active_index ON public.kblis USING btree (is_active);


--
-- Name: keyword_clusters_language_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_language_status_index ON public.keyword_clusters USING btree (language, status);


--
-- Name: keyword_clusters_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_priority_index ON public.keyword_clusters USING btree (priority);


--
-- Name: keyword_clusters_search_intent_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_search_intent_index ON public.keyword_clusters USING btree (search_intent);


--
-- Name: keyword_clusters_service_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_service_slug_index ON public.keyword_clusters USING btree (service_slug);


--
-- Name: keyword_position_history_keyword_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_keyword_index ON public.keyword_position_history USING btree (keyword);


--
-- Name: keyword_position_history_keyword_tracked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_keyword_tracked_at_index ON public.keyword_position_history USING btree (keyword, tracked_at);


--
-- Name: keyword_position_history_position_change_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_position_change_index ON public.keyword_position_history USING btree (position_change);


--
-- Name: keyword_position_history_position_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_position_index ON public.keyword_position_history USING btree ("position");


--
-- Name: keyword_position_history_tracked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_tracked_at_index ON public.keyword_position_history USING btree (tracked_at);


--
-- Name: meta_ab_tests_article_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_ab_tests_article_id_status_index ON public.meta_ab_tests USING btree (article_id, status);


--
-- Name: notifications_notifiable_type_notifiable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_notifiable_type_notifiable_id_index ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: notifications_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_read_at_index ON public.notifications USING btree (read_at);


--
-- Name: notifications_related_type_related_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_related_type_related_id_index ON public.notifications USING btree (related_type, related_id);


--
-- Name: payment_schedules_cash_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_cash_account_id_index ON public.payment_schedules USING btree (cash_account_id);


--
-- Name: payment_schedules_due_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_due_date_index ON public.payment_schedules USING btree (due_date);


--
-- Name: payment_schedules_invoice_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_invoice_id_index ON public.payment_schedules USING btree (invoice_id);


--
-- Name: payment_schedules_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_project_id_index ON public.payment_schedules USING btree (project_id);


--
-- Name: payment_schedules_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_status_index ON public.payment_schedules USING btree (status);


--
-- Name: payments_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_client_id_index ON public.payments USING btree (client_id);


--
-- Name: payments_payable_type_payable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_payable_type_payable_id_index ON public.payments USING btree (payable_type, payable_id);


--
-- Name: payments_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_status_index ON public.payments USING btree (status);


--
-- Name: permit_applications_client_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_applications_client_id_status_index ON public.permit_applications USING btree (client_id, status);


--
-- Name: permit_applications_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_applications_status_index ON public.permit_applications USING btree (status);


--
-- Name: permit_applications_submitted_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_applications_submitted_at_index ON public.permit_applications USING btree (submitted_at);


--
-- Name: permit_documents_project_permit_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_documents_project_permit_id_index ON public.permit_documents USING btree (project_permit_id);


--
-- Name: permit_template_dependencies_template_id_permit_item_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_template_dependencies_template_id_permit_item_id_index ON public.permit_template_dependencies USING btree (template_id, permit_item_id);


--
-- Name: permit_template_items_template_id_sequence_order_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_template_items_template_id_sequence_order_index ON public.permit_template_items USING btree (template_id, sequence_order);


--
-- Name: permit_templates_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_templates_category_index ON public.permit_templates USING btree (category);


--
-- Name: permit_templates_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_templates_is_public_index ON public.permit_templates USING btree (is_public);


--
-- Name: permit_types_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_types_category_index ON public.permit_types USING btree (category);


--
-- Name: permit_types_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_types_is_active_index ON public.permit_types USING btree (is_active);


--
-- Name: project_expenses_expense_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_expenses_expense_date_index ON public.project_expenses USING btree (expense_date);


--
-- Name: project_expenses_project_id_expense_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_expenses_project_id_expense_date_index ON public.project_expenses USING btree (project_id, expense_date);


--
-- Name: project_logs_entity_type_entity_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_logs_entity_type_entity_id_index ON public.project_logs USING btree (entity_type, entity_id);


--
-- Name: project_logs_project_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_logs_project_id_created_at_index ON public.project_logs USING btree (project_id, created_at);


--
-- Name: project_logs_user_id_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_logs_user_id_action_index ON public.project_logs USING btree (user_id, action);


--
-- Name: project_payments_payment_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_payments_payment_date_index ON public.project_payments USING btree (payment_date);


--
-- Name: project_payments_project_id_payment_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_payments_project_id_payment_date_index ON public.project_payments USING btree (project_id, payment_date);


--
-- Name: project_permit_dependencies_project_permit_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_permit_dependencies_project_permit_id_index ON public.project_permit_dependencies USING btree (project_permit_id);


--
-- Name: project_permits_project_id_sequence_order_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_permits_project_id_sequence_order_index ON public.project_permits USING btree (project_id, sequence_order);


--
-- Name: project_permits_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_permits_status_index ON public.project_permits USING btree (status);


--
-- Name: projects_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_client_id_index ON public.projects USING btree (client_id);


--
-- Name: push_subscriptions_subscribable_type_subscribable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subscriptions_subscribable_type_subscribable_id_index ON public.push_subscriptions USING btree (subscribable_type, subscribable_id);


--
-- Name: quotation_items_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_application_id_index ON public.quotation_items USING btree (application_id);


--
-- Name: quotation_items_item_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_item_type_index ON public.quotation_items USING btree (item_type);


--
-- Name: quotation_items_permit_type_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_permit_type_id_index ON public.quotation_items USING btree (permit_type_id);


--
-- Name: quotation_items_revision_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_revision_id_index ON public.quotation_items USING btree (revision_id);


--
-- Name: quotations_application_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotations_application_id_status_index ON public.quotations USING btree (application_id, status);


--
-- Name: quotations_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotations_client_id_index ON public.quotations USING btree (client_id);


--
-- Name: ranking_alerts_alert_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_alert_type_index ON public.ranking_alerts USING btree (alert_type);


--
-- Name: ranking_alerts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_created_at_index ON public.ranking_alerts USING btree (created_at);


--
-- Name: ranking_alerts_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_is_read_index ON public.ranking_alerts USING btree (is_read);


--
-- Name: ranking_alerts_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_severity_index ON public.ranking_alerts USING btree (severity);


--
-- Name: recruitment_stages_job_application_id_stage_order_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recruitment_stages_job_application_id_stage_order_index ON public.recruitment_stages USING btree (job_application_id, stage_order);


--
-- Name: recruitment_stages_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recruitment_stages_status_index ON public.recruitment_stages USING btree (status);


--
-- Name: search_console_data_page_url_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_console_data_page_url_date_index ON public.search_console_data USING btree (page_url, date);


--
-- Name: search_console_data_query_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_console_data_query_date_index ON public.search_console_data USING btree (query, date);


--
-- Name: seo_reports_period_period_start_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seo_reports_period_period_start_index ON public.seo_reports USING btree (period, period_start);


--
-- Name: service_cost_requests_applicant_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_cost_requests_applicant_type_index ON public.service_cost_requests USING btree (applicant_type);


--
-- Name: service_cost_requests_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_cost_requests_created_at_index ON public.service_cost_requests USING btree (created_at);


--
-- Name: service_cost_requests_service_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_cost_requests_service_category_index ON public.service_cost_requests USING btree (service_category);


--
-- Name: service_cost_requests_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_cost_requests_status_index ON public.service_cost_requests USING btree (status);


--
-- Name: service_inquiries_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_created_at_index ON public.service_inquiries USING btree (created_at);


--
-- Name: service_inquiries_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_email_index ON public.service_inquiries USING btree (email);


--
-- Name: service_inquiries_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_priority_index ON public.service_inquiries USING btree (priority);


--
-- Name: service_inquiries_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_status_index ON public.service_inquiries USING btree (status);


--
-- Name: service_inquiries_status_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_status_priority_index ON public.service_inquiries USING btree (status, priority);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: shapefile_projects_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shapefile_projects_email_index ON public.shapefile_projects USING btree (email);


--
-- Name: shapefile_projects_session_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shapefile_projects_session_token_index ON public.shapefile_projects USING btree (session_token);


--
-- Name: social_posts_article_id_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_posts_article_id_platform_index ON public.social_posts USING btree (article_id, platform);


--
-- Name: social_posts_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_posts_platform_index ON public.social_posts USING btree (platform);


--
-- Name: social_posts_status_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_posts_status_scheduled_for_index ON public.social_posts USING btree (status, scheduled_for);


--
-- Name: tasks_assigned_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_assigned_user_id_status_index ON public.tasks USING btree (assigned_user_id, status);


--
-- Name: tasks_due_date_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_due_date_status_index ON public.tasks USING btree (due_date, status);


--
-- Name: tasks_project_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_project_id_status_index ON public.tasks USING btree (project_id, status);


--
-- Name: tasks_project_permit_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_project_permit_id_index ON public.tasks USING btree (project_permit_id);


--
-- Name: technical_test_submissions_job_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX technical_test_submissions_job_application_id_index ON public.technical_test_submissions USING btree (job_application_id);


--
-- Name: technical_test_submissions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX technical_test_submissions_status_index ON public.technical_test_submissions USING btree (status);


--
-- Name: test_answers_test_session_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_answers_test_session_id_index ON public.test_answers USING btree (test_session_id);


--
-- Name: test_answers_test_session_id_question_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_answers_test_session_id_question_id_index ON public.test_answers USING btree (test_session_id, question_id);


--
-- Name: test_sessions_job_application_id_test_template_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_job_application_id_test_template_id_index ON public.test_sessions USING btree (job_application_id, test_template_id);


--
-- Name: test_sessions_recruitment_stage_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_recruitment_stage_id_index ON public.test_sessions USING btree (recruitment_stage_id);


--
-- Name: test_sessions_session_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_session_token_index ON public.test_sessions USING btree (session_token);


--
-- Name: test_sessions_status_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_status_expires_at_index ON public.test_sessions USING btree (status, expires_at);


--
-- Name: test_templates_test_type_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_templates_test_type_is_active_index ON public.test_templates USING btree (test_type, is_active);


--
-- Name: topic_clusters_service_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX topic_clusters_service_slug_index ON public.topic_clusters USING btree (service_slug);


--
-- Name: topic_clusters_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX topic_clusters_status_index ON public.topic_clusters USING btree (status);


--
-- Name: trending_topics_category_is_processed_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trending_topics_category_is_processed_index ON public.trending_topics USING btree (category, is_processed);


--
-- Name: trending_topics_discovered_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trending_topics_discovered_at_index ON public.trending_topics USING btree (discovered_at);


--
-- Name: trending_topics_trend_score_is_processed_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trending_topics_trend_score_is_processed_index ON public.trending_topics USING btree (trend_score, is_processed);


--
-- Name: ai_processing_logs ai_processing_logs_document_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_document_id_foreign FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: ai_processing_logs ai_processing_logs_initiated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_initiated_by_foreign FOREIGN KEY (initiated_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_processing_logs ai_processing_logs_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: ai_processing_logs ai_processing_logs_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.document_templates(id) ON DELETE CASCADE;


--
-- Name: ai_query_logs ai_query_logs_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: ai_setting_history ai_setting_history_changed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history
    ADD CONSTRAINT ai_setting_history_changed_by_foreign FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_setting_history ai_setting_history_setting_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history
    ADD CONSTRAINT ai_setting_history_setting_id_foreign FOREIGN KEY (setting_id) REFERENCES public.ai_settings(id) ON DELETE CASCADE;


--
-- Name: ai_settings ai_settings_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_settings ai_settings_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: application_documents application_documents_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: application_documents application_documents_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: application_documents application_documents_verified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_verified_by_foreign FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: application_legality_documents application_legality_documents_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_legality_documents
    ADD CONSTRAINT application_legality_documents_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: application_location_details application_location_details_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details
    ADD CONSTRAINT application_location_details_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: application_notes application_notes_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes
    ADD CONSTRAINT application_notes_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: application_notes application_notes_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes
    ADD CONSTRAINT application_notes_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: application_revisions application_revisions_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions
    ADD CONSTRAINT application_revisions_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: application_revisions application_revisions_revised_by_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions
    ADD CONSTRAINT application_revisions_revised_by_id_foreign FOREIGN KEY (revised_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: application_status_logs application_status_logs_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_status_logs
    ADD CONSTRAINT application_status_logs_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: article_topic_similarities article_topic_similarities_topic_a_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_topic_a_id_foreign FOREIGN KEY (topic_a_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- Name: article_topic_similarities article_topic_similarities_topic_b_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_topic_b_id_foreign FOREIGN KEY (topic_b_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- Name: article_topics article_topics_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- Name: article_topics article_topics_topic_cluster_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_topic_cluster_id_foreign FOREIGN KEY (topic_cluster_id) REFERENCES public.topic_clusters(id) ON DELETE SET NULL;


--
-- Name: article_view_logs article_view_logs_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs
    ADD CONSTRAINT article_view_logs_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: articles articles_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: articles articles_topic_cluster_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_topic_cluster_id_foreign FOREIGN KEY (topic_cluster_id) REFERENCES public.topic_clusters(id) ON DELETE SET NULL;


--
-- Name: auto_post_logs auto_post_logs_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- Name: auto_post_logs auto_post_logs_schedule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_schedule_id_foreign FOREIGN KEY (schedule_id) REFERENCES public.auto_post_schedules(id) ON DELETE SET NULL;


--
-- Name: auto_post_logs auto_post_logs_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_topic_id_foreign FOREIGN KEY (topic_id) REFERENCES public.article_topics(id) ON DELETE SET NULL;


--
-- Name: auto_post_schedules auto_post_schedules_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules
    ADD CONSTRAINT auto_post_schedules_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- Name: auto_post_schedules auto_post_schedules_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules
    ADD CONSTRAINT auto_post_schedules_topic_id_foreign FOREIGN KEY (topic_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- Name: bank_reconciliations bank_reconciliations_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_reconciliations bank_reconciliations_cash_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_cash_account_id_foreign FOREIGN KEY (cash_account_id) REFERENCES public.cash_accounts(id) ON DELETE CASCADE;


--
-- Name: bank_reconciliations bank_reconciliations_reconciled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_reconciled_by_foreign FOREIGN KEY (reconciled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_reconciliations bank_reconciliations_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_statement_entries bank_statement_entries_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_entries
    ADD CONSTRAINT bank_statement_entries_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE CASCADE;


--
-- Name: business_contexts business_contexts_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts
    ADD CONSTRAINT business_contexts_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: business_contexts business_contexts_kbli_code_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts
    ADD CONSTRAINT business_contexts_kbli_code_foreign FOREIGN KEY (kbli_code) REFERENCES public.kbli(code) ON DELETE CASCADE;


--
-- Name: cash_account_balance_history cash_account_balance_history_cash_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history
    ADD CONSTRAINT cash_account_balance_history_cash_account_id_foreign FOREIGN KEY (cash_account_id) REFERENCES public.cash_accounts(id) ON DELETE CASCADE;


--
-- Name: cash_account_balance_history cash_account_balance_history_changed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history
    ADD CONSTRAINT cash_account_balance_history_changed_by_foreign FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compliance_checks compliance_checks_draft_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_draft_id_foreign FOREIGN KEY (draft_id) REFERENCES public.document_drafts(id) ON DELETE CASCADE;


--
-- Name: consult_requests consult_requests_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: consult_requests consult_requests_kbli_code_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_kbli_code_foreign FOREIGN KEY (kbli_code) REFERENCES public.kbli(code) ON DELETE RESTRICT;


--
-- Name: consult_requests consult_requests_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: content_gaps content_gaps_article_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps
    ADD CONSTRAINT content_gaps_article_topic_id_foreign FOREIGN KEY (article_topic_id) REFERENCES public.article_topics(id) ON DELETE SET NULL;


--
-- Name: content_gaps content_gaps_topic_cluster_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps
    ADD CONSTRAINT content_gaps_topic_cluster_id_foreign FOREIGN KEY (topic_cluster_id) REFERENCES public.topic_clusters(id) ON DELETE SET NULL;


--
-- Name: content_refresh_logs content_refresh_logs_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_refresh_logs
    ADD CONSTRAINT content_refresh_logs_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: content_syndications content_syndications_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_syndications
    ADD CONSTRAINT content_syndications_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: document_drafts document_drafts_ai_log_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_ai_log_id_foreign FOREIGN KEY (ai_log_id) REFERENCES public.ai_processing_logs(id) ON DELETE CASCADE;


--
-- Name: document_drafts document_drafts_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_drafts document_drafts_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: document_drafts document_drafts_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: document_drafts document_drafts_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.document_templates(id) ON DELETE CASCADE;


--
-- Name: document_templates document_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: documents documents_parent_document_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_parent_document_id_foreign FOREIGN KEY (parent_document_id) REFERENCES public.documents(id);


--
-- Name: documents documents_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: documents documents_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: documents documents_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: email_assignments email_assignments_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: email_assignments email_assignments_email_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_email_account_id_foreign FOREIGN KEY (email_account_id) REFERENCES public.email_accounts(id) ON DELETE CASCADE;


--
-- Name: email_assignments email_assignments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_campaigns email_campaigns_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_campaigns email_campaigns_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.email_templates(id) ON DELETE SET NULL;


--
-- Name: email_inbox email_inbox_assigned_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_assigned_to_foreign FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: email_inbox email_inbox_email_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_email_account_id_foreign FOREIGN KEY (email_account_id) REFERENCES public.email_accounts(id) ON DELETE SET NULL;


--
-- Name: email_inbox email_inbox_handled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_handled_by_foreign FOREIGN KEY (handled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: email_inbox email_inbox_replied_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_replied_to_foreign FOREIGN KEY (replied_to) REFERENCES public.email_inbox(id) ON DELETE SET NULL;


--
-- Name: email_logs email_logs_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_campaign_id_foreign FOREIGN KEY (campaign_id) REFERENCES public.email_campaigns(id) ON DELETE CASCADE;


--
-- Name: email_logs email_logs_subscriber_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_subscriber_id_foreign FOREIGN KEY (subscriber_id) REFERENCES public.email_subscribers(id) ON DELETE CASCADE;


--
-- Name: interview_feedback interview_feedback_interview_schedule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT interview_feedback_interview_schedule_id_foreign FOREIGN KEY (interview_schedule_id) REFERENCES public.interview_schedules(id) ON DELETE CASCADE;


--
-- Name: interview_feedback interview_feedback_interviewer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT interview_feedback_interviewer_id_foreign FOREIGN KEY (interviewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: interview_schedules interview_schedules_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: interview_schedules interview_schedules_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- Name: interview_schedules interview_schedules_recruitment_stage_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_recruitment_stage_id_foreign FOREIGN KEY (recruitment_stage_id) REFERENCES public.recruitment_stages(id) ON DELETE SET NULL;


--
-- Name: invoice_items invoice_items_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_job_vacancy_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_job_vacancy_id_foreign FOREIGN KEY (job_vacancy_id) REFERENCES public.job_vacancies(id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: kbli_permit_recommendations kbli_permit_recommendations_kbli_code_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli_permit_recommendations
    ADD CONSTRAINT kbli_permit_recommendations_kbli_code_foreign FOREIGN KEY (kbli_code) REFERENCES public.kbli(code) ON DELETE CASCADE;


--
-- Name: meta_ab_tests meta_ab_tests_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_ab_tests
    ADD CONSTRAINT meta_ab_tests_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: payment_schedules payment_schedules_cash_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_cash_account_id_foreign FOREIGN KEY (cash_account_id) REFERENCES public.cash_accounts(id) ON DELETE SET NULL;


--
-- Name: payment_schedules payment_schedules_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: payment_schedules payment_schedules_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: payment_schedules payment_schedules_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE SET NULL;


--
-- Name: payments payments_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: payments payments_quotation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_quotation_id_foreign FOREIGN KEY (quotation_id) REFERENCES public.quotations(id) ON DELETE SET NULL;


--
-- Name: payments payments_verified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_verified_by_foreign FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: permission_role permission_role_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: permission_role permission_role_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: permit_applications permit_applications_ai_recommendation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_ai_recommendation_id_foreign FOREIGN KEY (ai_recommendation_id) REFERENCES public.kbli_permit_recommendations(id) ON DELETE SET NULL;


--
-- Name: permit_applications permit_applications_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: permit_applications permit_applications_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE RESTRICT;


--
-- Name: permit_applications permit_applications_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: permit_applications permit_applications_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: permit_documents permit_documents_project_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents
    ADD CONSTRAINT permit_documents_project_permit_id_foreign FOREIGN KEY (project_permit_id) REFERENCES public.project_permits(id) ON DELETE CASCADE;


--
-- Name: permit_documents permit_documents_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents
    ADD CONSTRAINT permit_documents_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: permit_template_dependencies permit_template_dependencies_depends_on_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_depends_on_item_id_foreign FOREIGN KEY (depends_on_item_id) REFERENCES public.permit_template_items(id) ON DELETE CASCADE;


--
-- Name: permit_template_dependencies permit_template_dependencies_permit_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_permit_item_id_foreign FOREIGN KEY (permit_item_id) REFERENCES public.permit_template_items(id) ON DELETE CASCADE;


--
-- Name: permit_template_dependencies permit_template_dependencies_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.permit_templates(id) ON DELETE CASCADE;


--
-- Name: permit_template_items permit_template_items_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items
    ADD CONSTRAINT permit_template_items_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE SET NULL;


--
-- Name: permit_template_items permit_template_items_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items
    ADD CONSTRAINT permit_template_items_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.permit_templates(id) ON DELETE CASCADE;


--
-- Name: permit_templates permit_templates_created_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_templates
    ADD CONSTRAINT permit_templates_created_by_user_id_foreign FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: permit_types permit_types_institution_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types
    ADD CONSTRAINT permit_types_institution_id_foreign FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: project_expenses project_expenses_bank_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_bank_account_id_foreign FOREIGN KEY (bank_account_id) REFERENCES public.cash_accounts(id) ON DELETE SET NULL;


--
-- Name: project_expenses project_expenses_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_expenses project_expenses_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_expenses project_expenses_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE SET NULL;


--
-- Name: project_logs project_logs_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs
    ADD CONSTRAINT project_logs_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_logs project_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs
    ADD CONSTRAINT project_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: project_payments project_payments_bank_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_bank_account_id_foreign FOREIGN KEY (bank_account_id) REFERENCES public.cash_accounts(id) ON DELETE SET NULL;


--
-- Name: project_payments project_payments_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_payments project_payments_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: project_payments project_payments_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: project_payments project_payments_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE SET NULL;


--
-- Name: project_permit_dependencies project_permit_dependencies_created_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_created_by_user_id_foreign FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_permit_dependencies project_permit_dependencies_depends_on_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_depends_on_permit_id_foreign FOREIGN KEY (depends_on_permit_id) REFERENCES public.project_permits(id) ON DELETE CASCADE;


--
-- Name: project_permit_dependencies project_permit_dependencies_overridden_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_overridden_by_user_id_foreign FOREIGN KEY (overridden_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_permit_dependencies project_permit_dependencies_project_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_project_permit_id_foreign FOREIGN KEY (project_permit_id) REFERENCES public.project_permits(id) ON DELETE CASCADE;


--
-- Name: project_permits project_permits_assigned_to_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_assigned_to_user_id_foreign FOREIGN KEY (assigned_to_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_permits project_permits_existing_document_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_existing_document_id_foreign FOREIGN KEY (existing_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: project_permits project_permits_override_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_override_by_user_id_foreign FOREIGN KEY (override_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_permits project_permits_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE SET NULL;


--
-- Name: project_permits project_permits_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: projects projects_institution_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_institution_id_foreign FOREIGN KEY (institution_id) REFERENCES public.institutions(id);


--
-- Name: projects projects_permit_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_permit_application_id_foreign FOREIGN KEY (permit_application_id) REFERENCES public.permit_applications(id) ON DELETE SET NULL;


--
-- Name: projects projects_status_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_status_id_foreign FOREIGN KEY (status_id) REFERENCES public.project_statuses(id);


--
-- Name: quotation_items quotation_items_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: quotation_items quotation_items_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE SET NULL;


--
-- Name: quotation_items quotation_items_revision_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_revision_id_foreign FOREIGN KEY (revision_id) REFERENCES public.application_revisions(id) ON DELETE CASCADE;


--
-- Name: quotations quotations_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- Name: quotations quotations_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: quotations quotations_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ranking_alerts ranking_alerts_position_history_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranking_alerts
    ADD CONSTRAINT ranking_alerts_position_history_id_foreign FOREIGN KEY (position_history_id) REFERENCES public.keyword_position_history(id) ON DELETE CASCADE;


--
-- Name: recruitment_stages recruitment_stages_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages
    ADD CONSTRAINT recruitment_stages_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- Name: seo_scores seo_scores_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores
    ADD CONSTRAINT seo_scores_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: service_inquiries service_inquiries_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: service_inquiries service_inquiries_contacted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_contacted_by_foreign FOREIGN KEY (contacted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: service_inquiries service_inquiries_converted_to_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_converted_to_application_id_foreign FOREIGN KEY (converted_to_application_id) REFERENCES public.permit_applications(id) ON DELETE SET NULL;


--
-- Name: shapefile_projects shapefile_projects_service_inquiry_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects
    ADD CONSTRAINT shapefile_projects_service_inquiry_id_foreign FOREIGN KEY (service_inquiry_id) REFERENCES public.service_inquiries(id) ON DELETE SET NULL;


--
-- Name: shapefile_projects shapefile_projects_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects
    ADD CONSTRAINT shapefile_projects_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: social_posts social_posts_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_posts
    ADD CONSTRAINT social_posts_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_assigned_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_user_id_foreign FOREIGN KEY (assigned_user_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_depends_on_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_depends_on_task_id_foreign FOREIGN KEY (depends_on_task_id) REFERENCES public.tasks(id);


--
-- Name: tasks tasks_institution_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_institution_id_foreign FOREIGN KEY (institution_id) REFERENCES public.institutions(id);


--
-- Name: tasks tasks_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_project_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_permit_id_foreign FOREIGN KEY (project_permit_id) REFERENCES public.project_permits(id) ON DELETE SET NULL;


--
-- Name: technical_test_submissions technical_test_submissions_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions
    ADD CONSTRAINT technical_test_submissions_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- Name: technical_test_submissions technical_test_submissions_reviewer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions
    ADD CONSTRAINT technical_test_submissions_reviewer_id_foreign FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: test_answers test_answers_test_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_answers
    ADD CONSTRAINT test_answers_test_session_id_foreign FOREIGN KEY (test_session_id) REFERENCES public.test_sessions(id) ON DELETE CASCADE;


--
-- Name: test_sessions test_sessions_evaluator_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_evaluator_id_foreign FOREIGN KEY (evaluator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: test_sessions test_sessions_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- Name: test_sessions test_sessions_recruitment_stage_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_recruitment_stage_id_foreign FOREIGN KEY (recruitment_stage_id) REFERENCES public.recruitment_stages(id) ON DELETE SET NULL;


--
-- Name: test_sessions test_sessions_test_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_test_template_id_foreign FOREIGN KEY (test_template_id) REFERENCES public.test_templates(id) ON DELETE CASCADE;


--
-- Name: test_templates test_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_templates
    ADD CONSTRAINT test_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: trending_topics trending_topics_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trending_topics
    ADD CONSTRAINT trending_topics_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- Name: users users_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict vRruG6uxunnRbxkiAbbBLAb6SzsvpdTIPKfdAB6Bk6aO8KaflsdMYFqVmhVEMzN

