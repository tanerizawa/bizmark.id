--
-- PostgreSQL database dump
--

\restrict ZGpW4VBCicKwRCdhOEFSI7OEERA1wuoaLndHihDFhmsZjLD5f42iXvhcdwjIKXZ

-- Dumped from database version 17.9 (Debian 17.9-0+deb13u1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-0+deb13u1)

-- Started on 2026-04-15 05:10:12 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 297 (class 1259 OID 157760)
-- Name: ai_processing_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_processing_logs (
    id bigint NOT NULL,
    document_id bigint,
    template_id bigint NOT NULL,
    project_id bigint NOT NULL,
    operation_type character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    input_tokens integer,
    output_tokens integer,
    cost numeric(10,6),
    error_message text,
    metadata json,
    initiated_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT ai_processing_logs_operation_type_check CHECK (((operation_type)::text = ANY ((ARRAY['paraphrase'::character varying, 'summarize'::character varying, 'extract'::character varying, 'analyze'::character varying])::text[]))),
    CONSTRAINT ai_processing_logs_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


--
-- TOC entry 296 (class 1259 OID 157759)
-- Name: ai_processing_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_processing_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5944 (class 0 OID 0)
-- Dependencies: 296
-- Name: ai_processing_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_processing_logs_id_seq OWNED BY public.ai_processing_logs.id;


--
-- TOC entry 339 (class 1259 OID 158352)
-- Name: ai_query_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_query_logs (
    id bigint NOT NULL,
    client_id bigint,
    kbli_code character varying(10),
    business_context jsonb,
    prompt_text text,
    response_text text,
    tokens_used integer,
    response_time_ms integer,
    status character varying(20) DEFAULT 'success'::character varying NOT NULL,
    error_message text,
    ai_model character varying(100),
    api_cost numeric(10,6),
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 5945 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN ai_query_logs.business_context; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.business_context IS 'Additional context provided by user';


--
-- TOC entry 5946 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN ai_query_logs.response_time_ms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.response_time_ms IS 'Response time in milliseconds';


--
-- TOC entry 5947 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN ai_query_logs.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.status IS 'success, error, timeout';


--
-- TOC entry 5948 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN ai_query_logs.api_cost; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_query_logs.api_cost IS 'Cost in USD';


--
-- TOC entry 338 (class 1259 OID 158351)
-- Name: ai_query_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_query_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5949 (class 0 OID 0)
-- Dependencies: 338
-- Name: ai_query_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_query_logs_id_seq OWNED BY public.ai_query_logs.id;


--
-- TOC entry 377 (class 1259 OID 158896)
-- Name: ai_setting_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_setting_history (
    id bigint NOT NULL,
    setting_id bigint NOT NULL,
    key character varying(255) NOT NULL,
    old_value text,
    new_value text NOT NULL,
    changed_by_name character varying(255) NOT NULL,
    changed_by bigint NOT NULL,
    reason text,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 376 (class 1259 OID 158895)
-- Name: ai_setting_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_setting_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5950 (class 0 OID 0)
-- Dependencies: 376
-- Name: ai_setting_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_setting_history_id_seq OWNED BY public.ai_setting_history.id;


--
-- TOC entry 375 (class 1259 OID 158868)
-- Name: ai_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_settings (
    id bigint NOT NULL,
    category character varying(50) NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    data_type character varying(20) DEFAULT 'string'::character varying NOT NULL,
    description text,
    is_public boolean DEFAULT false NOT NULL,
    is_encrypted boolean DEFAULT false NOT NULL,
    validation_rules json,
    default_value text,
    display_order integer DEFAULT 0 NOT NULL,
    group_name character varying(100),
    requires_restart boolean DEFAULT false NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- TOC entry 5951 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.category IS 'global, pricing, rag, prompts, etc';


--
-- TOC entry 5952 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.key IS 'Unique setting key';


--
-- TOC entry 5953 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.value IS 'Setting value (JSON for complex types)';


--
-- TOC entry 5954 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.data_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.data_type IS 'string, number, boolean, json, array';


--
-- TOC entry 5955 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.description IS 'Human-readable description';


--
-- TOC entry 5956 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.is_public; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.is_public IS 'Can be exposed to frontend';


--
-- TOC entry 5957 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.is_encrypted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.is_encrypted IS 'Encrypt sensitive data like API keys';


--
-- TOC entry 5958 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.validation_rules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.validation_rules IS 'Laravel validation rules';


--
-- TOC entry 5959 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.default_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.default_value IS 'Default value if not set';


--
-- TOC entry 5960 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.display_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.display_order IS 'Order in UI';


--
-- TOC entry 5961 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.group_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.group_name IS 'UI grouping';


--
-- TOC entry 5962 (class 0 OID 0)
-- Dependencies: 375
-- Name: COLUMN ai_settings.requires_restart; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_settings.requires_restart IS 'Requires system restart';


--
-- TOC entry 374 (class 1259 OID 158867)
-- Name: ai_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5963 (class 0 OID 0)
-- Dependencies: 374
-- Name: ai_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_settings_id_seq OWNED BY public.ai_settings.id;


--
-- TOC entry 323 (class 1259 OID 158166)
-- Name: application_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_documents (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size bigint,
    mime_type character varying(100),
    is_verified boolean DEFAULT false NOT NULL,
    verified_by bigint,
    verified_at timestamp(0) without time zone,
    verification_notes text,
    uploaded_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    review_notes text,
    CONSTRAINT application_documents_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- TOC entry 322 (class 1259 OID 158165)
-- Name: application_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5964 (class 0 OID 0)
-- Dependencies: 322
-- Name: application_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_documents_id_seq OWNED BY public.application_documents.id;


--
-- TOC entry 347 (class 1259 OID 158446)
-- Name: application_legality_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_legality_documents (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    document_category character varying(255) NOT NULL,
    document_name character varying(200) NOT NULL,
    is_available boolean DEFAULT false NOT NULL,
    document_number character varying(100),
    issued_date date,
    expiry_date date,
    file_path character varying(500),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT application_legality_documents_document_category_check CHECK (((document_category)::text = ANY ((ARRAY['land_ownership'::character varying, 'company_legal'::character varying, 'existing_permits'::character varying, 'power_of_attorney'::character varying, 'technical'::character varying, 'other'::character varying])::text[])))
);


--
-- TOC entry 346 (class 1259 OID 158445)
-- Name: application_legality_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_legality_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5965 (class 0 OID 0)
-- Dependencies: 346
-- Name: application_legality_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_legality_documents_id_seq OWNED BY public.application_legality_documents.id;


--
-- TOC entry 345 (class 1259 OID 158425)
-- Name: application_location_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_location_details (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    province character varying(100),
    city_regency character varying(100),
    district character varying(100),
    sub_district character varying(100),
    full_address text,
    postal_code character varying(10),
    latitude numeric(10,8),
    longitude numeric(11,8),
    zone_type character varying(255),
    land_status character varying(255),
    land_certificate_number character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT application_location_details_land_status_check CHECK (((land_status)::text = ANY ((ARRAY['HGB'::character varying, 'HGU'::character varying, 'Hak_Milik'::character varying, 'Girik'::character varying, 'Sewa'::character varying, 'Other'::character varying])::text[]))),
    CONSTRAINT application_location_details_zone_type_check CHECK (((zone_type)::text = ANY ((ARRAY['industrial'::character varying, 'commercial'::character varying, 'residential'::character varying, 'mixed'::character varying, 'special_economic_zone'::character varying])::text[])))
);


--
-- TOC entry 344 (class 1259 OID 158424)
-- Name: application_location_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_location_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5966 (class 0 OID 0)
-- Dependencies: 344
-- Name: application_location_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_location_details_id_seq OWNED BY public.application_location_details.id;


--
-- TOC entry 333 (class 1259 OID 158297)
-- Name: application_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_notes (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    author_type character varying(255) NOT NULL,
    author_id bigint,
    note text NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 332 (class 1259 OID 158296)
-- Name: application_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5967 (class 0 OID 0)
-- Dependencies: 332
-- Name: application_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_notes_id_seq OWNED BY public.application_notes.id;


--
-- TOC entry 343 (class 1259 OID 158399)
-- Name: application_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_revisions (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    revision_number integer DEFAULT 1 NOT NULL,
    revision_type character varying(255) NOT NULL,
    revision_reason text,
    revised_by_id bigint,
    permits_data jsonb,
    project_data jsonb,
    total_cost numeric(15,2),
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    client_approved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT application_revisions_revision_type_check CHECK (((revision_type)::text = ANY ((ARRAY['technical_adjustment'::character varying, 'client_request'::character varying, 'document_incomplete'::character varying, 'cost_update'::character varying])::text[]))),
    CONSTRAINT application_revisions_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending_client_approval'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- TOC entry 342 (class 1259 OID 158398)
-- Name: application_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_revisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5968 (class 0 OID 0)
-- Dependencies: 342
-- Name: application_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_revisions_id_seq OWNED BY public.application_revisions.id;


--
-- TOC entry 327 (class 1259 OID 158222)
-- Name: application_status_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_status_logs (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    from_status character varying(50),
    to_status character varying(50) NOT NULL,
    notes text,
    changed_by_type character varying(50),
    changed_by_id bigint,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 326 (class 1259 OID 158221)
-- Name: application_status_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.application_status_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5969 (class 0 OID 0)
-- Dependencies: 326
-- Name: application_status_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.application_status_logs_id_seq OWNED BY public.application_status_logs.id;


--
-- TOC entry 387 (class 1259 OID 159019)
-- Name: article_topic_similarities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_topic_similarities (
    id bigint NOT NULL,
    topic_a_id bigint NOT NULL,
    topic_b_id bigint NOT NULL,
    similarity_score double precision NOT NULL,
    calculated_at timestamp(0) without time zone NOT NULL
);


--
-- TOC entry 386 (class 1259 OID 159018)
-- Name: article_topic_similarities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_topic_similarities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5970 (class 0 OID 0)
-- Dependencies: 386
-- Name: article_topic_similarities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_topic_similarities_id_seq OWNED BY public.article_topic_similarities.id;


--
-- TOC entry 379 (class 1259 OID 158919)
-- Name: article_topics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_topics (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    category character varying(255) NOT NULL,
    keywords json,
    tags json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    article_id bigint,
    published_at timestamp(0) without time zone,
    scheduled_for timestamp(0) without time zone,
    generation_notes text,
    views_count integer DEFAULT 0 NOT NULL,
    similarity_score double precision,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    language character varying(255) DEFAULT 'id'::character varying NOT NULL,
    target_market character varying(255) DEFAULT 'local'::character varying NOT NULL,
    topic_cluster_id bigint,
    CONSTRAINT article_topics_language_check CHECK (((language)::text = ANY ((ARRAY['id'::character varying, 'en'::character varying])::text[]))),
    CONSTRAINT article_topics_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'published'::character varying, 'failed'::character varying, 'archived'::character varying])::text[])))
);


--
-- TOC entry 378 (class 1259 OID 158918)
-- Name: article_topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5971 (class 0 OID 0)
-- Dependencies: 378
-- Name: article_topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_topics_id_seq OWNED BY public.article_topics.id;


--
-- TOC entry 397 (class 1259 OID 159125)
-- Name: article_view_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.article_view_logs (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    date date NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    unique_views integer DEFAULT 0 NOT NULL,
    top_referrer character varying(255),
    top_country character varying(5),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 396 (class 1259 OID 159124)
-- Name: article_view_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.article_view_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5972 (class 0 OID 0)
-- Dependencies: 396
-- Name: article_view_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.article_view_logs_id_seq OWNED BY public.article_view_logs.id;


--
-- TOC entry 283 (class 1259 OID 157643)
-- Name: articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.articles (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    excerpt text,
    content text NOT NULL,
    featured_image character varying(255),
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    tags json,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    views_count integer DEFAULT 0 NOT NULL,
    author_id bigint NOT NULL,
    meta_title character varying(255),
    meta_description text,
    meta_keywords character varying(255),
    is_featured boolean DEFAULT false NOT NULL,
    reading_time integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    source_type character varying(255) DEFAULT 'manual'::character varying NOT NULL,
    language character varying(2) DEFAULT 'id'::character varying NOT NULL,
    topic_cluster_id bigint,
    CONSTRAINT articles_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


--
-- TOC entry 282 (class 1259 OID 157642)
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5973 (class 0 OID 0)
-- Dependencies: 282
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- TOC entry 381 (class 1259 OID 158944)
-- Name: auto_post_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_post_configs (
    id bigint NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    posts_per_day integer DEFAULT 3 NOT NULL,
    post_times json NOT NULL,
    timezone character varying(255) DEFAULT 'Asia/Jakarta'::character varying NOT NULL,
    ai_model character varying(255) DEFAULT 'anthropic/claude-3.5-sonnet'::character varying NOT NULL,
    min_word_count integer DEFAULT 800 NOT NULL,
    max_word_count integer DEFAULT 1500 NOT NULL,
    min_reading_time integer DEFAULT 4 NOT NULL,
    max_reading_time integer DEFAULT 8 NOT NULL,
    min_headings integer DEFAULT 3 NOT NULL,
    max_headings integer DEFAULT 6 NOT NULL,
    min_paragraphs integer DEFAULT 5 NOT NULL,
    internal_links_count integer DEFAULT 3 NOT NULL,
    include_featured_image boolean DEFAULT true NOT NULL,
    auto_publish boolean DEFAULT false NOT NULL,
    duplicate_threshold double precision DEFAULT '0.75'::double precision NOT NULL,
    cooldown_days integer DEFAULT 30 NOT NULL,
    excluded_keywords json,
    category_weights json NOT NULL,
    daily_limit integer DEFAULT 5 NOT NULL,
    retry_attempts integer DEFAULT 3 NOT NULL,
    timeout_seconds integer DEFAULT 120 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    language_distribution json,
    market_focus json
);


--
-- TOC entry 380 (class 1259 OID 158943)
-- Name: auto_post_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_post_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5974 (class 0 OID 0)
-- Dependencies: 380
-- Name: auto_post_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_post_configs_id_seq OWNED BY public.auto_post_configs.id;


--
-- TOC entry 385 (class 1259 OID 158991)
-- Name: auto_post_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_post_logs (
    id bigint NOT NULL,
    schedule_id bigint,
    article_id bigint,
    topic_id bigint,
    level character varying(255) DEFAULT 'info'::character varying NOT NULL,
    event character varying(255) NOT NULL,
    message text NOT NULL,
    context json,
    word_count integer,
    reading_time integer,
    internal_links integer,
    ai_cost double precision,
    created_at timestamp(0) without time zone NOT NULL,
    CONSTRAINT auto_post_logs_level_check CHECK (((level)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'error'::character varying, 'success'::character varying])::text[])))
);


--
-- TOC entry 384 (class 1259 OID 158990)
-- Name: auto_post_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_post_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5975 (class 0 OID 0)
-- Dependencies: 384
-- Name: auto_post_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_post_logs_id_seq OWNED BY public.auto_post_logs.id;


--
-- TOC entry 383 (class 1259 OID 158972)
-- Name: auto_post_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_post_schedules (
    id bigint NOT NULL,
    topic_id bigint NOT NULL,
    scheduled_at timestamp(0) without time zone NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    error_message text,
    attempts integer DEFAULT 0 NOT NULL,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    generation_time_seconds integer,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    article_id bigint,
    CONSTRAINT auto_post_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- TOC entry 382 (class 1259 OID 158971)
-- Name: auto_post_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_post_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5976 (class 0 OID 0)
-- Dependencies: 382
-- Name: auto_post_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_post_schedules_id_seq OWNED BY public.auto_post_schedules.id;


--
-- TOC entry 279 (class 1259 OID 157563)
-- Name: bank_reconciliations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_reconciliations (
    id bigint NOT NULL,
    cash_account_id bigint NOT NULL,
    reconciliation_date date NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    opening_balance_book numeric(15,2) NOT NULL,
    opening_balance_bank numeric(15,2) NOT NULL,
    closing_balance_book numeric(15,2) NOT NULL,
    closing_balance_bank numeric(15,2) NOT NULL,
    total_deposits_in_transit numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_outstanding_checks numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_bank_charges numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_bank_credits numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    adjusted_bank_balance numeric(15,2) NOT NULL,
    adjusted_book_balance numeric(15,2) NOT NULL,
    difference numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    status character varying(255) DEFAULT 'in_progress'::character varying NOT NULL,
    bank_statement_file character varying(255),
    bank_statement_format character varying(50),
    notes text,
    reconciled_by bigint,
    reviewed_by bigint,
    approved_by bigint,
    completed_at timestamp(0) without time zone,
    reviewed_at timestamp(0) without time zone,
    approved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT bank_reconciliations_status_check CHECK (((status)::text = ANY ((ARRAY['in_progress'::character varying, 'completed'::character varying, 'reviewed'::character varying, 'approved'::character varying])::text[])))
);


--
-- TOC entry 278 (class 1259 OID 157562)
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_reconciliations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5977 (class 0 OID 0)
-- Dependencies: 278
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_reconciliations_id_seq OWNED BY public.bank_reconciliations.id;


--
-- TOC entry 281 (class 1259 OID 157602)
-- Name: bank_statement_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_statement_entries (
    id bigint NOT NULL,
    reconciliation_id bigint NOT NULL,
    transaction_date date NOT NULL,
    description text NOT NULL,
    debit_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    credit_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    running_balance numeric(15,2) NOT NULL,
    reference_number character varying(100),
    is_matched boolean DEFAULT false NOT NULL,
    matched_transaction_type character varying(255),
    matched_transaction_id bigint,
    match_confidence character varying(255),
    match_notes text,
    unmatch_reason character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT bank_statement_entries_match_confidence_check CHECK (((match_confidence)::text = ANY ((ARRAY['exact'::character varying, 'fuzzy'::character varying, 'manual'::character varying])::text[]))),
    CONSTRAINT bank_statement_entries_matched_transaction_type_check CHECK (((matched_transaction_type)::text = ANY ((ARRAY['payment'::character varying, 'expense'::character varying, 'invoice_payment'::character varying])::text[]))),
    CONSTRAINT bank_statement_entries_unmatch_reason_check CHECK (((unmatch_reason)::text = ANY ((ARRAY['missing_in_system'::character varying, 'bank_error'::character varying, 'timing_difference'::character varying, 'needs_investigation'::character varying])::text[])))
);


--
-- TOC entry 280 (class 1259 OID 157601)
-- Name: bank_statement_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_statement_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5978 (class 0 OID 0)
-- Dependencies: 280
-- Name: bank_statement_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_statement_entries_id_seq OWNED BY public.bank_statement_entries.id;


--
-- TOC entry 351 (class 1259 OID 158500)
-- Name: business_contexts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_contexts (
    id bigint NOT NULL,
    client_id bigint,
    kbli_code character varying(10) NOT NULL,
    land_area numeric(12,2),
    building_area numeric(12,2),
    number_of_floors integer,
    investment_value numeric(20,2),
    province character varying(100),
    city character varying(100),
    district character varying(100),
    zone_type character varying(255),
    coordinates character varying(100),
    location_category character varying(255),
    number_of_employees integer,
    production_capacity character varying(100),
    annual_revenue_target numeric(20,2),
    business_scale character varying(255),
    environmental_impact character varying(255) DEFAULT 'low'::character varying NOT NULL,
    waste_management character varying(255),
    near_protected_area boolean DEFAULT false NOT NULL,
    environmental_notes text,
    ownership_status character varying(255),
    existing_permits json,
    urgency_level character varying(255) DEFAULT 'standard'::character varying NOT NULL,
    additional_notes text,
    custom_fields json,
    ip_address character varying(45),
    user_agent character varying(255),
    submitted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT business_contexts_business_scale_check CHECK (((business_scale)::text = ANY ((ARRAY['mikro'::character varying, 'kecil'::character varying, 'menengah'::character varying, 'besar'::character varying])::text[]))),
    CONSTRAINT business_contexts_environmental_impact_check CHECK (((environmental_impact)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[]))),
    CONSTRAINT business_contexts_location_category_check CHECK (((location_category)::text = ANY ((ARRAY['perkotaan'::character varying, 'pedesaan'::character varying, 'kawasan_industri'::character varying])::text[]))),
    CONSTRAINT business_contexts_ownership_status_check CHECK (((ownership_status)::text = ANY ((ARRAY['owned'::character varying, 'leased'::character varying, 'partnership'::character varying])::text[]))),
    CONSTRAINT business_contexts_urgency_level_check CHECK (((urgency_level)::text = ANY ((ARRAY['standard'::character varying, 'rush'::character varying])::text[]))),
    CONSTRAINT business_contexts_waste_management_check CHECK (((waste_management)::text = ANY ((ARRAY['minimal'::character varying, 'standard'::character varying, 'complex'::character varying])::text[]))),
    CONSTRAINT business_contexts_zone_type_check CHECK (((zone_type)::text = ANY ((ARRAY['residential'::character varying, 'commercial'::character varying, 'industrial'::character varying, 'mixed'::character varying, 'special'::character varying])::text[])))
);


--
-- TOC entry 5979 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN business_contexts.land_area; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.land_area IS 'Land area in m²';


--
-- TOC entry 5980 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN business_contexts.building_area; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.building_area IS 'Building area in m²';


--
-- TOC entry 5981 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN business_contexts.investment_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.investment_value IS 'Investment value in Rupiah';


--
-- TOC entry 5982 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN business_contexts.coordinates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.coordinates IS 'Lat,Long';


--
-- TOC entry 5983 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN business_contexts.annual_revenue_target; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.annual_revenue_target IS 'Annual revenue in Rupiah';


--
-- TOC entry 5984 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN business_contexts.existing_permits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.existing_permits IS 'List of permits already owned';


--
-- TOC entry 5985 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN business_contexts.custom_fields; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.business_contexts.custom_fields IS 'Flexible storage for KBLI-specific data';


--
-- TOC entry 350 (class 1259 OID 158499)
-- Name: business_contexts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.business_contexts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5986 (class 0 OID 0)
-- Dependencies: 350
-- Name: business_contexts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.business_contexts_id_seq OWNED BY public.business_contexts.id;


--
-- TOC entry 223 (class 1259 OID 156917)
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 156924)
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


--
-- TOC entry 355 (class 1259 OID 158582)
-- Name: cash_account_balance_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_account_balance_history (
    id bigint NOT NULL,
    cash_account_id bigint NOT NULL,
    old_balance numeric(15,2) NOT NULL,
    new_balance numeric(15,2) NOT NULL,
    change_amount numeric(15,2) NOT NULL,
    change_type character varying(50) NOT NULL,
    reference_id bigint,
    reference_type character varying(100),
    description text,
    changed_by bigint,
    changed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 5987 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.old_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.old_balance IS 'Saldo sebelum perubahan';


--
-- TOC entry 5988 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.new_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.new_balance IS 'Saldo setelah perubahan';


--
-- TOC entry 5989 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.change_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.change_amount IS 'Selisih perubahan (+ untuk income, - untuk expense)';


--
-- TOC entry 5990 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.change_type IS 'Tipe perubahan: income, expense, adjustment, reconciliation, recalculation';


--
-- TOC entry 5991 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.reference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.reference_id IS 'ID transaksi terkait';


--
-- TOC entry 5992 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.reference_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.reference_type IS 'Model class: ProjectPayment, ProjectExpense, etc';


--
-- TOC entry 5993 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.description IS 'Deskripsi perubahan';


--
-- TOC entry 5994 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN cash_account_balance_history.changed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_account_balance_history.changed_at IS 'Waktu perubahan terjadi';


--
-- TOC entry 354 (class 1259 OID 158581)
-- Name: cash_account_balance_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cash_account_balance_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5995 (class 0 OID 0)
-- Dependencies: 354
-- Name: cash_account_balance_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cash_account_balance_history_id_seq OWNED BY public.cash_account_balance_history.id;


--
-- TOC entry 243 (class 1259 OID 157142)
-- Name: cash_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_accounts (
    id bigint NOT NULL,
    account_name character varying(100) NOT NULL,
    account_type character varying(255) DEFAULT 'bank'::character varying NOT NULL,
    account_number character varying(50),
    bank_name character varying(100),
    account_holder character varying(255),
    current_balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    initial_balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT cash_accounts_account_type_check CHECK (((account_type)::text = ANY ((ARRAY['bank'::character varying, 'cash'::character varying, 'receivable'::character varying, 'payable'::character varying])::text[])))
);


--
-- TOC entry 5996 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN cash_accounts.account_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.account_name IS 'Nama akun (Bank BTN, Cash, dll)';


--
-- TOC entry 5997 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN cash_accounts.account_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.account_number IS 'Nomor rekening';


--
-- TOC entry 5998 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN cash_accounts.bank_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.bank_name IS 'Nama bank';


--
-- TOC entry 5999 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN cash_accounts.account_holder; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.account_holder IS 'Nama pemilik rekening';


--
-- TOC entry 6000 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN cash_accounts.current_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.current_balance IS 'Saldo saat ini';


--
-- TOC entry 6001 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN cash_accounts.initial_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_accounts.initial_balance IS 'Saldo awal';


--
-- TOC entry 242 (class 1259 OID 157141)
-- Name: cash_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cash_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6002 (class 0 OID 0)
-- Dependencies: 242
-- Name: cash_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cash_accounts_id_seq OWNED BY public.cash_accounts.id;


--
-- TOC entry 269 (class 1259 OID 157476)
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    company_name character varying(255),
    industry character varying(255),
    contact_person character varying(255),
    email character varying(255),
    phone character varying(255),
    mobile character varying(255),
    address text,
    city character varying(255),
    province character varying(255),
    postal_code character varying(255),
    npwp character varying(255),
    tax_name character varying(255),
    tax_address text,
    client_type character varying(255) DEFAULT 'company'::character varying NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    password character varying(255),
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100),
    profile_picture character varying(255),
    CONSTRAINT clients_client_type_check CHECK (((client_type)::text = ANY ((ARRAY['individual'::character varying, 'company'::character varying, 'government'::character varying])::text[]))),
    CONSTRAINT clients_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'potential'::character varying])::text[])))
);


--
-- TOC entry 268 (class 1259 OID 157475)
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6003 (class 0 OID 0)
-- Dependencies: 268
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- TOC entry 405 (class 1259 OID 159188)
-- Name: competitor_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitor_analyses (
    id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    our_url character varying(255),
    our_position integer,
    top_competitors json,
    content_gaps json,
    recommendations json,
    search_volume integer,
    difficulty character varying(255),
    analyzed_at date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    data_source character varying(20) DEFAULT 'ai_estimated'::character varying NOT NULL
);


--
-- TOC entry 404 (class 1259 OID 159187)
-- Name: competitor_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.competitor_analyses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6004 (class 0 OID 0)
-- Dependencies: 404
-- Name: competitor_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.competitor_analyses_id_seq OWNED BY public.competitor_analyses.id;


--
-- TOC entry 301 (class 1259 OID 157834)
-- Name: compliance_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_checks (
    id bigint NOT NULL,
    draft_id bigint NOT NULL,
    document_type character varying(255) DEFAULT 'UKL-UPL'::character varying NOT NULL,
    overall_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    structure_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    compliance_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    formatting_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    completeness_score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    issues jsonb,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    error_message text,
    total_issues integer DEFAULT 0 NOT NULL,
    critical_issues integer DEFAULT 0 NOT NULL,
    warning_issues integer DEFAULT 0 NOT NULL,
    info_issues integer DEFAULT 0 NOT NULL,
    checked_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 300 (class 1259 OID 157833)
-- Name: compliance_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_checks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6005 (class 0 OID 0)
-- Dependencies: 300
-- Name: compliance_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_checks_id_seq OWNED BY public.compliance_checks.id;


--
-- TOC entry 373 (class 1259 OID 158824)
-- Name: consult_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consult_requests (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(20) NOT NULL,
    company_name character varying(255),
    kbli_code character varying(10) NOT NULL,
    business_size character varying(255) DEFAULT 'small'::character varying NOT NULL,
    location character varying(255),
    location_type character varying(255) DEFAULT 'commercial'::character varying NOT NULL,
    investment_level character varying(255) DEFAULT 'under_100m'::character varying NOT NULL,
    employee_count integer DEFAULT 0 NOT NULL,
    project_description text NOT NULL,
    deliverables_requested jsonb,
    estimate_status character varying(255) DEFAULT 'auto_estimated'::character varying NOT NULL,
    auto_estimate jsonb,
    final_quote jsonb,
    confidence_score numeric(3,2),
    admin_notes text,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    contacted boolean DEFAULT false NOT NULL,
    contacted_at timestamp(0) without time zone,
    converted_to_client boolean DEFAULT false NOT NULL,
    client_id bigint,
    ip_address character varying(45),
    user_agent character varying(255),
    referrer_url character varying(255),
    utm_params jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    rag_insights jsonb,
    rag_confidence numeric(3,2),
    rag_processed_at timestamp(0) without time zone,
    CONSTRAINT consult_requests_business_size_check CHECK (((business_size)::text = ANY ((ARRAY['micro'::character varying, 'small'::character varying, 'medium'::character varying, 'large'::character varying])::text[]))),
    CONSTRAINT consult_requests_estimate_status_check CHECK (((estimate_status)::text = ANY ((ARRAY['pending'::character varying, 'auto_estimated'::character varying, 'reviewed'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT consult_requests_investment_level_check CHECK (((investment_level)::text = ANY ((ARRAY['under_100m'::character varying, '100m_500m'::character varying, '500m_2b'::character varying, 'over_2b'::character varying])::text[]))),
    CONSTRAINT consult_requests_location_type_check CHECK (((location_type)::text = ANY ((ARRAY['industrial'::character varying, 'commercial'::character varying, 'residential'::character varying, 'rural'::character varying])::text[])))
);


--
-- TOC entry 372 (class 1259 OID 158823)
-- Name: consult_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.consult_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6006 (class 0 OID 0)
-- Dependencies: 372
-- Name: consult_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.consult_requests_id_seq OWNED BY public.consult_requests.id;


--
-- TOC entry 395 (class 1259 OID 159100)
-- Name: content_gaps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_gaps (
    id bigint NOT NULL,
    suggested_title character varying(255) NOT NULL,
    suggested_slug character varying(255) NOT NULL,
    description text NOT NULL,
    target_keyword character varying(255) NOT NULL,
    search_intent character varying(255) DEFAULT 'informational'::character varying NOT NULL,
    category character varying(255),
    service_slug character varying(255),
    language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    article_topic_id bigint,
    topic_cluster_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 394 (class 1259 OID 159099)
-- Name: content_gaps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_gaps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6007 (class 0 OID 0)
-- Dependencies: 394
-- Name: content_gaps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_gaps_id_seq OWNED BY public.content_gaps.id;


--
-- TOC entry 403 (class 1259 OID 159170)
-- Name: content_refresh_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_refresh_logs (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    status character varying(255) NOT NULL,
    changes json,
    before_snapshot json,
    after_snapshot json,
    error_message text,
    triggered_by character varying(255) DEFAULT 'cron'::character varying NOT NULL,
    ai_tokens_used integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 402 (class 1259 OID 159169)
-- Name: content_refresh_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_refresh_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6008 (class 0 OID 0)
-- Dependencies: 402
-- Name: content_refresh_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_refresh_logs_id_seq OWNED BY public.content_refresh_logs.id;


--
-- TOC entry 389 (class 1259 OID 159041)
-- Name: content_syndications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_syndications (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    platform character varying(255) NOT NULL,
    platform_url character varying(255),
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    metrics json,
    error_message text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 388 (class 1259 OID 159040)
-- Name: content_syndications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_syndications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6009 (class 0 OID 0)
-- Dependencies: 388
-- Name: content_syndications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_syndications_id_seq OWNED BY public.content_syndications.id;


--
-- TOC entry 299 (class 1259 OID 157795)
-- Name: document_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_drafts (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    template_id bigint NOT NULL,
    ai_log_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    sections json,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    created_by bigint NOT NULL,
    approved_at timestamp(0) without time zone,
    approved_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT document_drafts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'reviewed'::character varying, 'approved'::character varying, 'rejected'::character varying, 'exported'::character varying])::text[])))
);


--
-- TOC entry 298 (class 1259 OID 157794)
-- Name: document_drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_drafts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6010 (class 0 OID 0)
-- Dependencies: 298
-- Name: document_drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_drafts_id_seq OWNED BY public.document_drafts.id;


--
-- TOC entry 295 (class 1259 OID 157742)
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    permit_type character varying(255) NOT NULL,
    description text,
    file_name character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(50) NOT NULL,
    page_count smallint,
    required_fields json,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT document_templates_permit_type_check CHECK (((permit_type)::text = ANY ((ARRAY['pertek_bpn'::character varying, 'ukl_upl'::character varying, 'amdal'::character varying, 'imb'::character varying, 'pbg'::character varying, 'slf'::character varying, 'siup'::character varying, 'tdp'::character varying, 'npwp'::character varying, 'other'::character varying])::text[])))
);


--
-- TOC entry 294 (class 1259 OID 157741)
-- Name: document_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6011 (class 0 OID 0)
-- Dependencies: 294
-- Name: document_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_templates_id_seq OWNED BY public.document_templates.id;


--
-- TOC entry 239 (class 1259 OID 157054)
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    task_id bigint,
    title character varying(255) NOT NULL,
    description text,
    category character varying(255) NOT NULL,
    document_type character varying(255),
    file_name character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    file_size character varying(255),
    mime_type character varying(255),
    version character varying(10) DEFAULT '1.0'::character varying NOT NULL,
    parent_document_id bigint,
    is_latest_version boolean DEFAULT true NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    document_date date,
    submission_date date,
    approval_date date,
    uploaded_by bigint NOT NULL,
    is_confidential boolean DEFAULT false NOT NULL,
    access_permissions json,
    notes text,
    download_count integer DEFAULT 0 NOT NULL,
    last_accessed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT documents_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'review'::character varying, 'approved'::character varying, 'submitted'::character varying, 'final'::character varying])::text[])))
);


--
-- TOC entry 6012 (class 0 OID 0)
-- Dependencies: 239
-- Name: COLUMN documents.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.documents.category IS 'proposal, kontrak, kajian, surat, sk, dll';


--
-- TOC entry 6013 (class 0 OID 0)
-- Dependencies: 239
-- Name: COLUMN documents.document_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.documents.document_type IS 'PDF, DOC, XLS, etc';


--
-- TOC entry 238 (class 1259 OID 157053)
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6014 (class 0 OID 0)
-- Dependencies: 238
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- TOC entry 317 (class 1259 OID 158032)
-- Name: email_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_accounts (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) DEFAULT 'shared'::character varying NOT NULL,
    department character varying(255) DEFAULT 'general'::character varying NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    auto_reply_enabled boolean DEFAULT false NOT NULL,
    auto_reply_message text,
    signature text,
    assigned_users json,
    total_received integer DEFAULT 0 NOT NULL,
    total_sent integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT email_accounts_department_check CHECK (((department)::text = ANY ((ARRAY['general'::character varying, 'cs'::character varying, 'sales'::character varying, 'support'::character varying, 'finance'::character varying, 'technical'::character varying])::text[]))),
    CONSTRAINT email_accounts_type_check CHECK (((type)::text = ANY ((ARRAY['shared'::character varying, 'personal'::character varying])::text[])))
);


--
-- TOC entry 316 (class 1259 OID 158031)
-- Name: email_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6015 (class 0 OID 0)
-- Dependencies: 316
-- Name: email_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_accounts_id_seq OWNED BY public.email_accounts.id;


--
-- TOC entry 319 (class 1259 OID 158053)
-- Name: email_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_assignments (
    id bigint NOT NULL,
    email_account_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(255) DEFAULT 'primary'::character varying NOT NULL,
    can_send boolean DEFAULT true NOT NULL,
    can_receive boolean DEFAULT true NOT NULL,
    can_delete boolean DEFAULT false NOT NULL,
    can_assign_others boolean DEFAULT false NOT NULL,
    notify_on_receive boolean DEFAULT true NOT NULL,
    notify_on_reply boolean DEFAULT false NOT NULL,
    notify_on_mention boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    assigned_by bigint,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_assignments_role_check CHECK (((role)::text = ANY ((ARRAY['primary'::character varying, 'backup'::character varying, 'viewer'::character varying])::text[])))
);


--
-- TOC entry 318 (class 1259 OID 158052)
-- Name: email_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6016 (class 0 OID 0)
-- Dependencies: 318
-- Name: email_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_assignments_id_seq OWNED BY public.email_assignments.id;


--
-- TOC entry 311 (class 1259 OID 157940)
-- Name: email_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_campaigns (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    template_id bigint,
    content text NOT NULL,
    plain_content text,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    recipient_type character varying(255) DEFAULT 'all'::character varying NOT NULL,
    recipient_tags json,
    scheduled_at timestamp(0) without time zone,
    sent_at timestamp(0) without time zone,
    total_recipients integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    opened_count integer DEFAULT 0 NOT NULL,
    clicked_count integer DEFAULT 0 NOT NULL,
    bounced_count integer DEFAULT 0 NOT NULL,
    unsubscribed_count integer DEFAULT 0 NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_campaigns_recipient_type_check CHECK (((recipient_type)::text = ANY ((ARRAY['all'::character varying, 'active'::character varying, 'tags'::character varying])::text[]))),
    CONSTRAINT email_campaigns_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'sending'::character varying, 'sent'::character varying, 'paused'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- TOC entry 310 (class 1259 OID 157939)
-- Name: email_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6017 (class 0 OID 0)
-- Dependencies: 310
-- Name: email_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_campaigns_id_seq OWNED BY public.email_campaigns.id;


--
-- TOC entry 315 (class 1259 OID 157999)
-- Name: email_inbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_inbox (
    id bigint NOT NULL,
    message_id character varying(255) NOT NULL,
    from_email character varying(255) NOT NULL,
    from_name character varying(255),
    to_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    body_html text,
    body_text text,
    attachments json,
    is_read boolean DEFAULT false NOT NULL,
    is_starred boolean DEFAULT false NOT NULL,
    category character varying(255) DEFAULT 'inbox'::character varying NOT NULL,
    labels json,
    replied_to bigint,
    assigned_to bigint,
    received_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    email_account_id bigint,
    department character varying(255),
    priority character varying(255) DEFAULT 'normal'::character varying NOT NULL,
    status character varying(255) DEFAULT 'new'::character varying NOT NULL,
    first_responded_at timestamp(0) without time zone,
    resolved_at timestamp(0) without time zone,
    response_time_minutes integer,
    resolution_time_minutes integer,
    handled_by bigint,
    tags json,
    internal_notes text,
    sentiment character varying(255),
    CONSTRAINT email_inbox_category_check CHECK (((category)::text = ANY ((ARRAY['inbox'::character varying, 'sent'::character varying, 'trash'::character varying, 'spam'::character varying])::text[]))),
    CONSTRAINT email_inbox_department_check CHECK (((department)::text = ANY ((ARRAY['general'::character varying, 'cs'::character varying, 'sales'::character varying, 'support'::character varying, 'finance'::character varying, 'technical'::character varying])::text[]))),
    CONSTRAINT email_inbox_priority_check CHECK (((priority)::text = ANY ((ARRAY['urgent'::character varying, 'high'::character varying, 'normal'::character varying, 'low'::character varying])::text[]))),
    CONSTRAINT email_inbox_sentiment_check CHECK (((sentiment)::text = ANY ((ARRAY['positive'::character varying, 'neutral'::character varying, 'negative'::character varying])::text[]))),
    CONSTRAINT email_inbox_status_check CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'open'::character varying, 'pending'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- TOC entry 314 (class 1259 OID 157998)
-- Name: email_inbox_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_inbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6018 (class 0 OID 0)
-- Dependencies: 314
-- Name: email_inbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_inbox_id_seq OWNED BY public.email_inbox.id;


--
-- TOC entry 313 (class 1259 OID 157971)
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id bigint NOT NULL,
    campaign_id bigint,
    subscriber_id bigint,
    recipient_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'sent'::character varying NOT NULL,
    sent_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    opened_at timestamp(0) without time zone,
    clicked_at timestamp(0) without time zone,
    bounced_at timestamp(0) without time zone,
    tracking_id character varying(255),
    error_message character varying(255),
    ip_address character varying(255),
    user_agent character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_logs_status_check CHECK (((status)::text = ANY ((ARRAY['sent'::character varying, 'delivered'::character varying, 'opened'::character varying, 'clicked'::character varying, 'bounced'::character varying, 'failed'::character varying])::text[])))
);


--
-- TOC entry 312 (class 1259 OID 157970)
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6019 (class 0 OID 0)
-- Dependencies: 312
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;


--
-- TOC entry 307 (class 1259 OID 157910)
-- Name: email_subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_subscribers (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    phone character varying(255),
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    source character varying(255),
    tags json,
    custom_fields json,
    subscribed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    unsubscribed_at timestamp(0) without time zone,
    unsubscribe_reason character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_subscribers_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'unsubscribed'::character varying, 'bounced'::character varying])::text[])))
);


--
-- TOC entry 306 (class 1259 OID 157909)
-- Name: email_subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_subscribers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6020 (class 0 OID 0)
-- Dependencies: 306
-- Name: email_subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_subscribers_id_seq OWNED BY public.email_subscribers.id;


--
-- TOC entry 309 (class 1259 OID 157926)
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_templates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    content text NOT NULL,
    plain_content text,
    thumbnail character varying(255),
    category character varying(255) DEFAULT 'newsletter'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    variables json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT email_templates_category_check CHECK (((category)::text = ANY ((ARRAY['newsletter'::character varying, 'promotional'::character varying, 'transactional'::character varying, 'announcement'::character varying])::text[])))
);


--
-- TOC entry 308 (class 1259 OID 157925)
-- Name: email_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6021 (class 0 OID 0)
-- Dependencies: 308
-- Name: email_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_templates_id_seq OWNED BY public.email_templates.id;


--
-- TOC entry 287 (class 1259 OID 157684)
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expense_categories (
    id bigint NOT NULL,
    slug character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "group" character varying(255),
    icon character varying(255),
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 286 (class 1259 OID 157683)
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expense_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6022 (class 0 OID 0)
-- Dependencies: 286
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- TOC entry 229 (class 1259 OID 156949)
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 156948)
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6023 (class 0 OID 0)
-- Dependencies: 228
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- TOC entry 231 (class 1259 OID 156961)
-- Name: institutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institutions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    address text,
    phone character varying(255),
    email character varying(255),
    contact_person character varying(255),
    contact_position character varying(255),
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 6024 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN institutions.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.institutions.type IS 'DLH, BPN, OSS, Notaris, dll';


--
-- TOC entry 230 (class 1259 OID 156960)
-- Name: institutions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.institutions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6025 (class 0 OID 0)
-- Dependencies: 230
-- Name: institutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.institutions_id_seq OWNED BY public.institutions.id;


--
-- TOC entry 359 (class 1259 OID 158642)
-- Name: interview_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interview_feedback (
    id bigint NOT NULL,
    interview_schedule_id bigint NOT NULL,
    interviewer_id bigint NOT NULL,
    technical_skills smallint,
    communication smallint,
    problem_solving smallint,
    cultural_fit smallint,
    motivation smallint,
    overall_rating numeric(3,1),
    strengths text,
    weaknesses text,
    detailed_notes text,
    recommendation character varying(255) NOT NULL,
    submitted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT interview_feedback_recommendation_check CHECK (((recommendation)::text = ANY ((ARRAY['strong-hire'::character varying, 'hire'::character varying, 'maybe'::character varying, 'no-hire'::character varying])::text[])))
);


--
-- TOC entry 6026 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN interview_feedback.technical_skills; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.technical_skills IS '1-10 rating';


--
-- TOC entry 6027 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN interview_feedback.communication; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.communication IS '1-10 rating';


--
-- TOC entry 6028 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN interview_feedback.problem_solving; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.problem_solving IS '1-10 rating';


--
-- TOC entry 6029 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN interview_feedback.cultural_fit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.cultural_fit IS '1-10 rating';


--
-- TOC entry 6030 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN interview_feedback.motivation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.motivation IS '1-10 rating';


--
-- TOC entry 6031 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN interview_feedback.overall_rating; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_feedback.overall_rating IS 'Average score';


--
-- TOC entry 358 (class 1259 OID 158641)
-- Name: interview_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interview_feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6032 (class 0 OID 0)
-- Dependencies: 358
-- Name: interview_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interview_feedback_id_seq OWNED BY public.interview_feedback.id;


--
-- TOC entry 357 (class 1259 OID 158612)
-- Name: interview_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interview_schedules (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    interview_type character varying(255) DEFAULT 'preliminary'::character varying NOT NULL,
    interview_stage smallint DEFAULT '1'::smallint NOT NULL,
    scheduled_at timestamp(0) without time zone NOT NULL,
    duration_minutes integer DEFAULT 60 NOT NULL,
    location character varying(255),
    meeting_type character varying(255) DEFAULT 'video-call'::character varying NOT NULL,
    meeting_link text,
    meeting_password character varying(255),
    interviewer_ids json,
    status character varying(255) DEFAULT 'scheduled'::character varying NOT NULL,
    notes text,
    reminder_sent_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    recruitment_stage_id bigint,
    CONSTRAINT interview_schedules_interview_type_check CHECK (((interview_type)::text = ANY ((ARRAY['preliminary'::character varying, 'technical'::character varying, 'hr'::character varying, 'final'::character varying])::text[]))),
    CONSTRAINT interview_schedules_meeting_type_check CHECK (((meeting_type)::text = ANY ((ARRAY['in-person'::character varying, 'video-call'::character varying, 'phone'::character varying])::text[]))),
    CONSTRAINT interview_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['scheduled'::character varying, 'confirmed'::character varying, 'rescheduled'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'no-show'::character varying])::text[])))
);


--
-- TOC entry 6033 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN interview_schedules.interview_stage; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.interview_stage IS 'Stage number in sequence';


--
-- TOC entry 6034 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN interview_schedules.location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.location IS 'online, office, or specific address';


--
-- TOC entry 6035 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN interview_schedules.meeting_link; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.meeting_link IS 'Zoom/Jitsi meeting URL';


--
-- TOC entry 6036 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN interview_schedules.interviewer_ids; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.interview_schedules.interviewer_ids IS 'Array of user IDs';


--
-- TOC entry 356 (class 1259 OID 158611)
-- Name: interview_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interview_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6037 (class 0 OID 0)
-- Dependencies: 356
-- Name: interview_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interview_schedules_id_seq OWNED BY public.interview_schedules.id;


--
-- TOC entry 263 (class 1259 OID 157408)
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_items (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    description character varying(255) NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 262 (class 1259 OID 157407)
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6038 (class 0 OID 0)
-- Dependencies: 262
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- TOC entry 261 (class 1259 OID 157380)
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    invoice_number character varying(255) NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    subtotal numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    paid_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    remaining_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    notes text,
    client_name character varying(255),
    client_address text,
    client_tax_id character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'sent'::character varying, 'partial'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- TOC entry 260 (class 1259 OID 157379)
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6039 (class 0 OID 0)
-- Dependencies: 260
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- TOC entry 305 (class 1259 OID 157883)
-- Name: job_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_applications (
    id bigint NOT NULL,
    job_vacancy_id bigint NOT NULL,
    full_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    birth_date date,
    gender character varying(255),
    address text,
    education_level character varying(255) NOT NULL,
    major character varying(255) NOT NULL,
    institution character varying(255) NOT NULL,
    graduation_year integer,
    gpa numeric(3,2),
    work_experience text,
    has_experience_ukl_upl boolean DEFAULT false NOT NULL,
    skills text,
    cv_path character varying(255),
    portfolio_path character varying(255),
    cover_letter text,
    expected_salary integer,
    available_from date,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    notes text,
    reviewed_at timestamp(0) without time zone,
    reviewed_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT job_applications_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'reviewed'::character varying, 'interview'::character varying, 'accepted'::character varying, 'rejected'::character varying])::text[])))
);


--
-- TOC entry 304 (class 1259 OID 157882)
-- Name: job_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6040 (class 0 OID 0)
-- Dependencies: 304
-- Name: job_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_applications_id_seq OWNED BY public.job_applications.id;


--
-- TOC entry 227 (class 1259 OID 156941)
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- TOC entry 303 (class 1259 OID 157864)
-- Name: job_vacancies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_vacancies (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    "position" character varying(255) NOT NULL,
    description text NOT NULL,
    responsibilities text NOT NULL,
    qualifications text NOT NULL,
    benefits text,
    employment_type character varying(255) DEFAULT 'full-time'::character varying NOT NULL,
    location character varying(255) DEFAULT 'Jakarta'::character varying NOT NULL,
    salary_min integer,
    salary_max integer,
    salary_negotiable boolean DEFAULT true NOT NULL,
    deadline date,
    status character varying(255) DEFAULT 'open'::character varying NOT NULL,
    google_form_url character varying(255),
    applications_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT job_vacancies_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'closed'::character varying, 'draft'::character varying])::text[])))
);


--
-- TOC entry 302 (class 1259 OID 157863)
-- Name: job_vacancies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_vacancies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6041 (class 0 OID 0)
-- Dependencies: 302
-- Name: job_vacancies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_vacancies_id_seq OWNED BY public.job_vacancies.id;


--
-- TOC entry 226 (class 1259 OID 156932)
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 156931)
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6042 (class 0 OID 0)
-- Dependencies: 225
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- TOC entry 335 (class 1259 OID 158319)
-- Name: kbli; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kbli (
    id bigint NOT NULL,
    code character varying(10) NOT NULL,
    description text NOT NULL,
    sector character varying(1) NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    category character varying(255),
    activities text,
    examples text,
    complexity_level character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    default_direct_costs jsonb,
    default_hours_estimate jsonb,
    default_hourly_rates jsonb,
    regulatory_flags jsonb,
    recommended_services jsonb,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT kbli_complexity_level_check CHECK (((complexity_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])))
);


--
-- TOC entry 6043 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.code IS 'KBLI code (e.g., 62010)';


--
-- TOC entry 6044 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.description IS 'Business activity description';


--
-- TOC entry 6045 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.sector; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.sector IS 'Business sector (A-U)';


--
-- TOC entry 6046 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.notes IS 'Additional notes or clarifications';


--
-- TOC entry 6047 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.default_direct_costs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.default_direct_costs IS 'Direct costs: {"printing": 200000, "lab_tests": 0, "permits": 500000}';


--
-- TOC entry 6048 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.default_hours_estimate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.default_hours_estimate IS 'Hours by role: {"admin": 2, "technical": 16, "review": 4, "field": 8}';


--
-- TOC entry 6049 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.default_hourly_rates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.default_hourly_rates IS 'Rates by role: {"admin": 100000, "technical": 200000, "review": 150000, "field": 175000}';


--
-- TOC entry 6050 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.regulatory_flags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.regulatory_flags IS 'Flags: ["requires_permit", "environmental_assessment", "amdal_required"]';


--
-- TOC entry 6051 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN kbli.recommended_services; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli.recommended_services IS 'Services: [{"name": "UKL/UPL", "priority": "required"}, ...]';


--
-- TOC entry 334 (class 1259 OID 158318)
-- Name: kbli_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kbli_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6052 (class 0 OID 0)
-- Dependencies: 334
-- Name: kbli_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kbli_id_seq OWNED BY public.kbli.id;


--
-- TOC entry 337 (class 1259 OID 158334)
-- Name: kbli_permit_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kbli_permit_recommendations (
    id bigint NOT NULL,
    kbli_code character varying(10) NOT NULL,
    business_scale character varying(50),
    location_type character varying(50),
    recommended_permits jsonb NOT NULL,
    required_documents jsonb NOT NULL,
    risk_assessment jsonb,
    estimated_timeline jsonb,
    additional_notes text,
    ai_model character varying(100),
    ai_prompt_hash character varying(64),
    confidence_score numeric(3,2),
    cache_hits integer DEFAULT 0 NOT NULL,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 6053 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN kbli_permit_recommendations.business_scale; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.business_scale IS 'micro, small, medium, large';


--
-- TOC entry 6054 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN kbli_permit_recommendations.location_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.location_type IS 'urban, rural, industrial_zone';


--
-- TOC entry 6055 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN kbli_permit_recommendations.recommended_permits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.recommended_permits IS 'Array of permit objects with details';


--
-- TOC entry 6056 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN kbli_permit_recommendations.required_documents; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.required_documents IS 'Documents needed per permit';


--
-- TOC entry 6057 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN kbli_permit_recommendations.risk_assessment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.risk_assessment IS 'Risk level and considerations';


--
-- TOC entry 6058 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN kbli_permit_recommendations.estimated_timeline; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.estimated_timeline IS 'Processing time per permit';


--
-- TOC entry 6059 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN kbli_permit_recommendations.ai_prompt_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.kbli_permit_recommendations.ai_prompt_hash IS 'Track if prompt changed';


--
-- TOC entry 336 (class 1259 OID 158333)
-- Name: kbli_permit_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kbli_permit_recommendations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6060 (class 0 OID 0)
-- Dependencies: 336
-- Name: kbli_permit_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kbli_permit_recommendations_id_seq OWNED BY public.kbli_permit_recommendations.id;


--
-- TOC entry 371 (class 1259 OID 158797)
-- Name: kblis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kblis (
    id bigint NOT NULL,
    code character varying(10) NOT NULL,
    title character varying(255) NOT NULL,
    category character varying(255) NOT NULL,
    description text,
    activities text,
    complexity_level character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    default_direct_costs json,
    default_hours_estimate json,
    default_hourly_rates json,
    regulatory_flags json,
    recommended_services json,
    examples text,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT kblis_complexity_level_check CHECK (((complexity_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])))
);


--
-- TOC entry 370 (class 1259 OID 158796)
-- Name: kblis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kblis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6061 (class 0 OID 0)
-- Dependencies: 370
-- Name: kblis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kblis_id_seq OWNED BY public.kblis.id;


--
-- TOC entry 391 (class 1259 OID 159064)
-- Name: keyword_clusters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keyword_clusters (
    id bigint NOT NULL,
    seed_keyword character varying(255) NOT NULL,
    cluster_name character varying(255) NOT NULL,
    search_intent character varying(255) DEFAULT 'informational'::character varying NOT NULL,
    keywords json NOT NULL,
    long_tail_keywords json,
    language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    category character varying(255),
    service_slug character varying(255),
    estimated_volume integer DEFAULT 0 NOT NULL,
    difficulty_score integer DEFAULT 0 NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    articles_count integer DEFAULT 0 NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    last_researched_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    gsc_clicks integer,
    gsc_impressions integer,
    gsc_avg_position numeric(5,1),
    gsc_ctr numeric(5,2),
    gsc_synced_at timestamp(0) without time zone
);


--
-- TOC entry 6062 (class 0 OID 0)
-- Dependencies: 391
-- Name: COLUMN keyword_clusters.gsc_clicks; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_clicks IS 'Real total clicks from GSC in last sync window';


--
-- TOC entry 6063 (class 0 OID 0)
-- Dependencies: 391
-- Name: COLUMN keyword_clusters.gsc_impressions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_impressions IS 'Real total impressions from GSC in last sync window';


--
-- TOC entry 6064 (class 0 OID 0)
-- Dependencies: 391
-- Name: COLUMN keyword_clusters.gsc_avg_position; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_avg_position IS 'Real average SERP position from GSC';


--
-- TOC entry 6065 (class 0 OID 0)
-- Dependencies: 391
-- Name: COLUMN keyword_clusters.gsc_ctr; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_ctr IS 'Real average CTR (%) from GSC';


--
-- TOC entry 6066 (class 0 OID 0)
-- Dependencies: 391
-- Name: COLUMN keyword_clusters.gsc_synced_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.keyword_clusters.gsc_synced_at IS 'When GSC data was last synced for this cluster';


--
-- TOC entry 390 (class 1259 OID 159063)
-- Name: keyword_clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.keyword_clusters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6067 (class 0 OID 0)
-- Dependencies: 390
-- Name: keyword_clusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.keyword_clusters_id_seq OWNED BY public.keyword_clusters.id;


--
-- TOC entry 415 (class 1259 OID 159294)
-- Name: keyword_position_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keyword_position_history (
    id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    our_url character varying(255),
    "position" smallint,
    previous_position smallint,
    position_change smallint DEFAULT '0'::smallint NOT NULL,
    data_source character varying(255) DEFAULT 'searxng'::character varying NOT NULL,
    top_competitors json,
    search_volume integer,
    search_intent character varying(255),
    tracked_at date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 414 (class 1259 OID 159293)
-- Name: keyword_position_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.keyword_position_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6068 (class 0 OID 0)
-- Dependencies: 414
-- Name: keyword_position_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.keyword_position_history_id_seq OWNED BY public.keyword_position_history.id;


--
-- TOC entry 407 (class 1259 OID 159199)
-- Name: meta_ab_tests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meta_ab_tests (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    test_type character varying(255) NOT NULL,
    variant_a_title character varying(255),
    variant_a_description character varying(255),
    variant_b_title character varying(255),
    variant_b_description character varying(255),
    variant_a_impressions integer DEFAULT 0 NOT NULL,
    variant_a_clicks integer DEFAULT 0 NOT NULL,
    variant_b_impressions integer DEFAULT 0 NOT NULL,
    variant_b_clicks integer DEFAULT 0 NOT NULL,
    winner character varying(255),
    confidence numeric(5,2),
    status character varying(255) DEFAULT 'running'::character varying NOT NULL,
    started_at timestamp(0) without time zone NOT NULL,
    ended_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 406 (class 1259 OID 159198)
-- Name: meta_ab_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meta_ab_tests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6069 (class 0 OID 0)
-- Dependencies: 406
-- Name: meta_ab_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meta_ab_tests_id_seq OWNED BY public.meta_ab_tests.id;


--
-- TOC entry 218 (class 1259 OID 156884)
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- TOC entry 217 (class 1259 OID 156883)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6070 (class 0 OID 0)
-- Dependencies: 217
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- TOC entry 277 (class 1259 OID 157556)
-- Name: milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.milestones (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 276 (class 1259 OID 157555)
-- Name: milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6071 (class 0 OID 0)
-- Dependencies: 276
-- Name: milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.milestones_id_seq OWNED BY public.milestones.id;


--
-- TOC entry 329 (class 1259 OID 158239)
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    notifiable_type character varying(50) NOT NULL,
    notifiable_id bigint NOT NULL,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    icon character varying(50),
    related_type character varying(50),
    related_id bigint,
    action_url character varying(500),
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    data text
);


--
-- TOC entry 328 (class 1259 OID 158238)
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6072 (class 0 OID 0)
-- Dependencies: 328
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- TOC entry 221 (class 1259 OID 156901)
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- TOC entry 289 (class 1259 OID 157698)
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    requires_cash_account boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 288 (class 1259 OID 157697)
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6073 (class 0 OID 0)
-- Dependencies: 288
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- TOC entry 265 (class 1259 OID 157425)
-- Name: payment_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_schedules (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    invoice_id bigint,
    description character varying(255) NOT NULL,
    amount numeric(15,2) NOT NULL,
    due_date date NOT NULL,
    paid_date date,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    payment_method character varying(255),
    reference_number character varying(255),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_reconciled boolean DEFAULT false NOT NULL,
    reconciled_at timestamp(0) without time zone,
    reconciliation_id bigint,
    cash_account_id bigint,
    CONSTRAINT payment_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- TOC entry 264 (class 1259 OID 157424)
-- Name: payment_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6074 (class 0 OID 0)
-- Dependencies: 264
-- Name: payment_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_schedules_id_seq OWNED BY public.payment_schedules.id;


--
-- TOC entry 331 (class 1259 OID 158251)
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    payment_number character varying(50) NOT NULL,
    payable_type character varying(50) NOT NULL,
    payable_id bigint NOT NULL,
    client_id bigint NOT NULL,
    quotation_id bigint,
    amount numeric(15,2) NOT NULL,
    payment_type character varying(255),
    payment_method character varying(255),
    gateway_provider character varying(50),
    gateway_transaction_id character varying(255),
    gateway_response json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    bank_name character varying(100),
    account_number character varying(50),
    account_holder character varying(255),
    transfer_proof_path character varying(500),
    verified_by bigint,
    verified_at timestamp(0) without time zone,
    verification_notes text,
    paid_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT payments_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['bank_transfer'::character varying, 'ewallet'::character varying, 'credit_card'::character varying, 'virtual_account'::character varying, 'manual'::character varying])::text[]))),
    CONSTRAINT payments_payment_type_check CHECK (((payment_type)::text = ANY ((ARRAY['down_payment'::character varying, 'installment'::character varying, 'final_payment'::character varying])::text[]))),
    CONSTRAINT payments_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'success'::character varying, 'failed'::character varying, 'refunded'::character varying])::text[])))
);


--
-- TOC entry 330 (class 1259 OID 158250)
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6075 (class 0 OID 0)
-- Dependencies: 330
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- TOC entry 275 (class 1259 OID 157537)
-- Name: permission_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_role (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    permission_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 274 (class 1259 OID 157536)
-- Name: permission_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permission_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6076 (class 0 OID 0)
-- Dependencies: 274
-- Name: permission_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permission_role_id_seq OWNED BY public.permission_role.id;


--
-- TOC entry 273 (class 1259 OID 157526)
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    "group" character varying(255) NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 272 (class 1259 OID 157525)
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6077 (class 0 OID 0)
-- Dependencies: 272
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- TOC entry 321 (class 1259 OID 158128)
-- Name: permit_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_applications (
    id bigint NOT NULL,
    application_number character varying(50) NOT NULL,
    client_id bigint,
    permit_type_id bigint,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    form_data json,
    notes text,
    admin_notes text,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    quoted_price numeric(15,2),
    quoted_at timestamp(0) without time zone,
    quotation_expires_at timestamp(0) without time zone,
    quotation_notes text,
    down_payment_amount numeric(15,2),
    down_payment_percentage integer DEFAULT 30 NOT NULL,
    payment_status character varying(255),
    project_id bigint,
    converted_at timestamp(0) without time zone,
    submitted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    kbli_code character varying(10),
    kbli_description text,
    ai_recommendation_id bigint,
    business_context jsonb,
    terms_accepted_at timestamp(0) without time zone,
    terms_version character varying(20),
    terms_accepted_language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    terms_ip_address inet,
    terms_user_agent text,
    CONSTRAINT permit_applications_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['pending'::character varying, 'down_paid'::character varying, 'partially_paid'::character varying, 'fully_paid'::character varying])::text[]))),
    CONSTRAINT permit_applications_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'submitted'::character varying, 'under_review'::character varying, 'document_incomplete'::character varying, 'quoted'::character varying, 'quotation_accepted'::character varying, 'quotation_rejected'::character varying, 'payment_pending'::character varying, 'payment_verified'::character varying, 'converted_to_project'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- TOC entry 6078 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN permit_applications.business_context; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permit_applications.business_context IS 'Business scale, location type, and other context';


--
-- TOC entry 320 (class 1259 OID 158127)
-- Name: permit_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6079 (class 0 OID 0)
-- Dependencies: 320
-- Name: permit_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_applications_id_seq OWNED BY public.permit_applications.id;


--
-- TOC entry 267 (class 1259 OID 157450)
-- Name: permit_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_documents (
    id bigint NOT NULL,
    project_permit_id bigint NOT NULL,
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    file_type character varying(50) NOT NULL,
    file_size integer NOT NULL,
    description text,
    uploaded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 266 (class 1259 OID 157449)
-- Name: permit_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6080 (class 0 OID 0)
-- Dependencies: 266
-- Name: permit_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_documents_id_seq OWNED BY public.permit_documents.id;


--
-- TOC entry 255 (class 1259 OID 157282)
-- Name: permit_template_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_template_dependencies (
    id bigint NOT NULL,
    template_id bigint NOT NULL,
    permit_item_id bigint NOT NULL,
    depends_on_item_id bigint NOT NULL,
    dependency_type character varying(255) DEFAULT 'MANDATORY'::character varying NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT permit_template_dependencies_dependency_type_check CHECK (((dependency_type)::text = ANY ((ARRAY['MANDATORY'::character varying, 'OPTIONAL'::character varying, 'RECOMMENDED'::character varying])::text[])))
);


--
-- TOC entry 254 (class 1259 OID 157281)
-- Name: permit_template_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_template_dependencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6081 (class 0 OID 0)
-- Dependencies: 254
-- Name: permit_template_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_template_dependencies_id_seq OWNED BY public.permit_template_dependencies.id;


--
-- TOC entry 253 (class 1259 OID 157260)
-- Name: permit_template_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_template_items (
    id bigint NOT NULL,
    template_id bigint NOT NULL,
    permit_type_id bigint,
    custom_permit_name character varying(100),
    sequence_order integer DEFAULT 0 NOT NULL,
    is_goal_permit boolean DEFAULT false NOT NULL,
    estimated_days integer,
    estimated_cost numeric(15,2),
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 252 (class 1259 OID 157259)
-- Name: permit_template_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_template_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6082 (class 0 OID 0)
-- Dependencies: 252
-- Name: permit_template_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_template_items_id_seq OWNED BY public.permit_template_items.id;


--
-- TOC entry 251 (class 1259 OID 157242)
-- Name: permit_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_templates (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    description text,
    use_case text,
    category character varying(50),
    created_by_user_id bigint,
    is_public boolean DEFAULT false NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 250 (class 1259 OID 157241)
-- Name: permit_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6083 (class 0 OID 0)
-- Dependencies: 250
-- Name: permit_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_templates_id_seq OWNED BY public.permit_templates.id;


--
-- TOC entry 249 (class 1259 OID 157222)
-- Name: permit_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permit_types (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(50) NOT NULL,
    category character varying(255) NOT NULL,
    institution_id bigint,
    avg_processing_days integer,
    description text,
    required_documents json,
    estimated_cost_min numeric(15,2),
    estimated_cost_max numeric(15,2),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT permit_types_category_check CHECK (((category)::text = ANY ((ARRAY['environmental'::character varying, 'land'::character varying, 'building'::character varying, 'transportation'::character varying, 'business'::character varying, 'other'::character varying])::text[])))
);


--
-- TOC entry 248 (class 1259 OID 157221)
-- Name: permit_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permit_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6084 (class 0 OID 0)
-- Dependencies: 248
-- Name: permit_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permit_types_id_seq OWNED BY public.permit_types.id;


--
-- TOC entry 247 (class 1259 OID 157187)
-- Name: project_expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_expenses (
    id bigint NOT NULL,
    project_id bigint,
    expense_date date NOT NULL,
    vendor_name character varying(255),
    amount numeric(15,2) NOT NULL,
    bank_account_id bigint,
    description text,
    receipt_file character varying(255),
    is_billable boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_receivable boolean DEFAULT false NOT NULL,
    receivable_from character varying(255),
    receivable_status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    receivable_paid_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    receivable_notes text,
    category character varying(50) NOT NULL,
    payment_method character varying(50) DEFAULT 'transfer'::character varying NOT NULL,
    is_reconciled boolean DEFAULT false NOT NULL,
    reconciled_at timestamp(0) without time zone,
    reconciliation_id bigint,
    CONSTRAINT project_expenses_receivable_status_check CHECK (((receivable_status)::text = ANY ((ARRAY['pending'::character varying, 'partial'::character varying, 'paid'::character varying])::text[])))
);


--
-- TOC entry 6085 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.expense_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.expense_date IS 'Tanggal pengeluaran';


--
-- TOC entry 6086 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.vendor_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.vendor_name IS 'Nama rekanan/penerima pembayaran';


--
-- TOC entry 6087 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.amount IS 'Nominal pengeluaran';


--
-- TOC entry 6088 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.description IS 'Keterangan pengeluaran';


--
-- TOC entry 6089 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.receipt_file; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receipt_file IS 'Path file bukti pembayaran';


--
-- TOC entry 6090 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.is_billable; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.is_billable IS 'Apakah bisa ditagihkan ke klien?';


--
-- TOC entry 6091 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.is_receivable; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.is_receivable IS 'Apakah pengeluaran ini merupakan kasbon/piutang yang perlu dikembalikan oleh karyawan/pihak internal';


--
-- TOC entry 6092 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.receivable_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_from IS 'Nama karyawan/pihak yang berhutang';


--
-- TOC entry 6093 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.receivable_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_status IS 'Status pembayaran kasbon: pending, partial, paid';


--
-- TOC entry 6094 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.receivable_paid_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_paid_amount IS 'Jumlah yang sudah dibayar/dikembalikan';


--
-- TOC entry 6095 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN project_expenses.receivable_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_expenses.receivable_notes IS 'Catatan pembayaran kasbon';


--
-- TOC entry 246 (class 1259 OID 157186)
-- Name: project_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6096 (class 0 OID 0)
-- Dependencies: 246
-- Name: project_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_expenses_id_seq OWNED BY public.project_expenses.id;


--
-- TOC entry 241 (class 1259 OID 157092)
-- Name: project_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_logs (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    entity_type character varying(255),
    entity_id bigint,
    description text NOT NULL,
    old_values json,
    new_values json,
    notes text,
    ip_address character varying(45),
    user_agent character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 6097 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN project_logs.action; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_logs.action IS 'created, updated, status_changed, document_uploaded, dll';


--
-- TOC entry 6098 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN project_logs.entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_logs.entity_type IS 'project, task, document, dll';


--
-- TOC entry 240 (class 1259 OID 157091)
-- Name: project_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6099 (class 0 OID 0)
-- Dependencies: 240
-- Name: project_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_logs_id_seq OWNED BY public.project_logs.id;


--
-- TOC entry 245 (class 1259 OID 157157)
-- Name: project_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_payments (
    id bigint NOT NULL,
    project_id bigint,
    payment_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    payment_type character varying(255) DEFAULT 'other'::character varying NOT NULL,
    bank_account_id bigint,
    reference_number character varying(100),
    description text,
    receipt_file character varying(255),
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    payment_method character varying(255) DEFAULT 'bank_transfer'::character varying NOT NULL,
    invoice_id bigint,
    is_reconciled boolean DEFAULT false NOT NULL,
    reconciled_at timestamp(0) without time zone,
    reconciliation_id bigint,
    CONSTRAINT project_payments_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['cash'::character varying, 'bank_transfer'::character varying, 'check'::character varying, 'giro'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT project_payments_payment_type_check CHECK (((payment_type)::text = ANY ((ARRAY['dp'::character varying, 'progress'::character varying, 'final'::character varying, 'other'::character varying])::text[])))
);


--
-- TOC entry 6100 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN project_payments.payment_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.payment_date IS 'Tanggal terima pembayaran';


--
-- TOC entry 6101 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN project_payments.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.amount IS 'Nominal pembayaran';


--
-- TOC entry 6102 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN project_payments.reference_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.reference_number IS 'Nomor referensi/bukti transfer';


--
-- TOC entry 6103 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN project_payments.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.description IS 'Keterangan tambahan';


--
-- TOC entry 6104 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN project_payments.receipt_file; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_payments.receipt_file IS 'Path file bukti pembayaran';


--
-- TOC entry 244 (class 1259 OID 157156)
-- Name: project_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6105 (class 0 OID 0)
-- Dependencies: 244
-- Name: project_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_payments_id_seq OWNED BY public.project_payments.id;


--
-- TOC entry 259 (class 1259 OID 157345)
-- Name: project_permit_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_permit_dependencies (
    id bigint NOT NULL,
    project_permit_id bigint NOT NULL,
    depends_on_permit_id bigint NOT NULL,
    dependency_type character varying(255) DEFAULT 'MANDATORY'::character varying NOT NULL,
    can_proceed_without boolean DEFAULT false NOT NULL,
    override_reason text,
    override_document_path character varying(255),
    overridden_by_user_id bigint,
    overridden_at timestamp(0) without time zone,
    created_by_user_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT project_permit_dependencies_dependency_type_check CHECK (((dependency_type)::text = ANY ((ARRAY['MANDATORY'::character varying, 'OPTIONAL'::character varying])::text[])))
);


--
-- TOC entry 258 (class 1259 OID 157344)
-- Name: project_permit_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_permit_dependencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6106 (class 0 OID 0)
-- Dependencies: 258
-- Name: project_permit_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_permit_dependencies_id_seq OWNED BY public.project_permit_dependencies.id;


--
-- TOC entry 257 (class 1259 OID 157309)
-- Name: project_permits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_permits (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    permit_type_id bigint,
    custom_permit_name character varying(100),
    custom_institution_name character varying(100),
    sequence_order integer DEFAULT 0 NOT NULL,
    is_goal_permit boolean DEFAULT false NOT NULL,
    status character varying(255) DEFAULT 'NOT_STARTED'::character varying NOT NULL,
    has_existing_document boolean DEFAULT false NOT NULL,
    existing_document_id bigint,
    assigned_to_user_id bigint,
    started_at timestamp(0) without time zone,
    submitted_at timestamp(0) without time zone,
    approved_at timestamp(0) without time zone,
    rejected_at timestamp(0) without time zone,
    target_date date,
    estimated_cost numeric(15,2),
    actual_cost numeric(15,2),
    permit_number character varying(100),
    valid_until date,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    override_dependencies boolean DEFAULT false NOT NULL,
    override_reason text,
    override_by_user_id bigint,
    override_at timestamp(0) without time zone,
    CONSTRAINT project_permits_status_check CHECK (((status)::text = ANY ((ARRAY['NOT_STARTED'::character varying, 'IN_PROGRESS'::character varying, 'WAITING_DOC'::character varying, 'SUBMITTED'::character varying, 'UNDER_REVIEW'::character varying, 'APPROVED'::character varying, 'REJECTED'::character varying, 'EXISTING'::character varying, 'CANCELLED'::character varying])::text[])))
);


--
-- TOC entry 256 (class 1259 OID 157308)
-- Name: project_permits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_permits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6107 (class 0 OID 0)
-- Dependencies: 256
-- Name: project_permits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_permits_id_seq OWNED BY public.project_permits.id;


--
-- TOC entry 233 (class 1259 OID 156971)
-- Name: project_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_statuses (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#6B7280'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_final boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 6108 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN project_statuses.is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.project_statuses.is_final IS 'Status akhir/selesai';


--
-- TOC entry 232 (class 1259 OID 156970)
-- Name: project_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6109 (class 0 OID 0)
-- Dependencies: 232
-- Name: project_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_statuses_id_seq OWNED BY public.project_statuses.id;


--
-- TOC entry 235 (class 1259 OID 156986)
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    client_name character varying(255) NOT NULL,
    client_address text,
    status_id bigint NOT NULL,
    institution_id bigint,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    client_contact character varying(255),
    start_date date,
    deadline date,
    progress_percentage integer DEFAULT 0 NOT NULL,
    budget numeric(15,2),
    actual_cost numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    contract_value numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    down_payment numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    payment_received numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    total_expenses numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    profit_margin numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    payment_terms text,
    payment_status character varying(255) DEFAULT 'unpaid'::character varying NOT NULL,
    client_id bigint,
    permit_application_id bigint,
    completed_at timestamp(0) without time zone,
    completion_notes text,
    actual_completion_date date,
    CONSTRAINT projects_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['unpaid'::character varying, 'partial'::character varying, 'paid'::character varying])::text[])))
);


--
-- TOC entry 6110 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.contract_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.contract_value IS 'Nilai kontrak total';


--
-- TOC entry 6111 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.down_payment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.down_payment IS 'Uang muka (DP)';


--
-- TOC entry 6112 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.payment_received; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.payment_received IS 'Total pembayaran diterima';


--
-- TOC entry 6113 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.total_expenses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.total_expenses IS 'Total pengeluaran';


--
-- TOC entry 6114 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.profit_margin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.profit_margin IS 'Profit margin (%)';


--
-- TOC entry 6115 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.payment_terms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.payment_terms IS 'Termin pembayaran';


--
-- TOC entry 6116 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.completed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.completed_at IS 'Tanggal aktual proyek selesai (untuk tracking on-time/late)';


--
-- TOC entry 6117 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN projects.completion_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.completion_notes IS 'Catatan saat proyek selesai';


--
-- TOC entry 234 (class 1259 OID 156985)
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6118 (class 0 OID 0)
-- Dependencies: 234
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- TOC entry 341 (class 1259 OID 158382)
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id bigint NOT NULL,
    subscribable_type character varying(255) NOT NULL,
    subscribable_id bigint NOT NULL,
    endpoint character varying(500) NOT NULL,
    public_key character varying(255),
    auth_token character varying(255),
    content_encoding character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 340 (class 1259 OID 158381)
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6119 (class 0 OID 0)
-- Dependencies: 340
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- TOC entry 349 (class 1259 OID 158465)
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotation_items (
    id bigint NOT NULL,
    application_id bigint NOT NULL,
    revision_id bigint,
    item_type character varying(255) DEFAULT 'permit'::character varying NOT NULL,
    permit_type_id bigint,
    item_name character varying(200) NOT NULL,
    description text,
    unit_price numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    subtotal numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    service_type character varying(255) DEFAULT 'bizmark'::character varying NOT NULL,
    estimated_days integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT quotation_items_item_type_check CHECK (((item_type)::text = ANY ((ARRAY['permit'::character varying, 'consultation'::character varying, 'survey'::character varying, 'processing'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT quotation_items_service_type_check CHECK (((service_type)::text = ANY ((ARRAY['bizmark'::character varying, 'owned'::character varying, 'self'::character varying])::text[])))
);


--
-- TOC entry 348 (class 1259 OID 158464)
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotation_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6120 (class 0 OID 0)
-- Dependencies: 348
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- TOC entry 325 (class 1259 OID 158189)
-- Name: quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotations (
    id bigint NOT NULL,
    quotation_number character varying(50) NOT NULL,
    application_id bigint NOT NULL,
    client_id bigint NOT NULL,
    base_price numeric(15,2) NOT NULL,
    additional_fees json,
    discount_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    tax_percentage numeric(5,2) DEFAULT '11'::numeric NOT NULL,
    tax_amount numeric(15,2),
    total_amount numeric(15,2) NOT NULL,
    down_payment_percentage integer DEFAULT 30 NOT NULL,
    down_payment_amount numeric(15,2),
    payment_terms text,
    valid_until timestamp(0) without time zone NOT NULL,
    terms_and_conditions text,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    accepted_at timestamp(0) without time zone,
    rejected_at timestamp(0) without time zone,
    rejection_reason text,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT quotations_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'sent'::character varying, 'accepted'::character varying, 'rejected'::character varying, 'expired'::character varying])::text[])))
);


--
-- TOC entry 324 (class 1259 OID 158188)
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6121 (class 0 OID 0)
-- Dependencies: 324
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- TOC entry 417 (class 1259 OID 159310)
-- Name: ranking_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ranking_alerts (
    id bigint NOT NULL,
    position_history_id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    alert_type character varying(255) NOT NULL,
    severity smallint NOT NULL,
    old_position smallint,
    new_position smallint,
    message character varying(255) NOT NULL,
    details json,
    is_read boolean DEFAULT false NOT NULL,
    is_actioned boolean DEFAULT false NOT NULL,
    actioned_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 416 (class 1259 OID 159309)
-- Name: ranking_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ranking_alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6122 (class 0 OID 0)
-- Dependencies: 416
-- Name: ranking_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ranking_alerts_id_seq OWNED BY public.ranking_alerts.id;


--
-- TOC entry 363 (class 1259 OID 158681)
-- Name: recruitment_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recruitment_stages (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    stage_name character varying(100) NOT NULL,
    stage_order integer NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    score numeric(5,2),
    notes text,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT recruitment_stages_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in-progress'::character varying, 'passed'::character varying, 'failed'::character varying, 'skipped'::character varying])::text[])))
);


--
-- TOC entry 6123 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN recruitment_stages.stage_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.recruitment_stages.stage_name IS 'screening, psych-test, technical-test, interview-1, etc';


--
-- TOC entry 6124 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN recruitment_stages.stage_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.recruitment_stages.stage_order IS 'Sequential order';


--
-- TOC entry 6125 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN recruitment_stages.score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.recruitment_stages.score IS 'Stage score if applicable';


--
-- TOC entry 362 (class 1259 OID 158680)
-- Name: recruitment_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recruitment_stages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6126 (class 0 OID 0)
-- Dependencies: 362
-- Name: recruitment_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recruitment_stages_id_seq OWNED BY public.recruitment_stages.id;


--
-- TOC entry 271 (class 1259 OID 157514)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 270 (class 1259 OID 157513)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6127 (class 0 OID 0)
-- Dependencies: 270
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 409 (class 1259 OID 159219)
-- Name: search_console_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_console_data (
    id bigint NOT NULL,
    page_url character varying(255) NOT NULL,
    query character varying(255) NOT NULL,
    date date NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    ctr numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    "position" numeric(5,1) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 408 (class 1259 OID 159218)
-- Name: search_console_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.search_console_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6128 (class 0 OID 0)
-- Dependencies: 408
-- Name: search_console_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.search_console_data_id_seq OWNED BY public.search_console_data.id;


--
-- TOC entry 293 (class 1259 OID 157725)
-- Name: security_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_settings (
    id bigint NOT NULL,
    min_password_length smallint DEFAULT '8'::smallint NOT NULL,
    require_special_char boolean DEFAULT true NOT NULL,
    require_number boolean DEFAULT true NOT NULL,
    require_mixed_case boolean DEFAULT true NOT NULL,
    enforce_password_expiration boolean DEFAULT false NOT NULL,
    password_expiration_days smallint DEFAULT '90'::smallint NOT NULL,
    session_timeout_minutes smallint DEFAULT '30'::smallint NOT NULL,
    allow_concurrent_sessions boolean DEFAULT true NOT NULL,
    two_factor_enabled boolean DEFAULT false NOT NULL,
    activity_log_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 292 (class 1259 OID 157724)
-- Name: security_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.security_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6129 (class 0 OID 0)
-- Dependencies: 292
-- Name: security_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.security_settings_id_seq OWNED BY public.security_settings.id;


--
-- TOC entry 401 (class 1259 OID 159159)
-- Name: seo_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_reports (
    id bigint NOT NULL,
    period character varying(255) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    metrics json NOT NULL,
    top_articles json,
    alerts json,
    emailed boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 400 (class 1259 OID 159158)
-- Name: seo_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6130 (class 0 OID 0)
-- Dependencies: 400
-- Name: seo_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_reports_id_seq OWNED BY public.seo_reports.id;


--
-- TOC entry 399 (class 1259 OID 159142)
-- Name: seo_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_scores (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    total_score smallint DEFAULT '0'::smallint NOT NULL,
    factors json NOT NULL,
    recommendations json,
    scored_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 398 (class 1259 OID 159141)
-- Name: seo_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_scores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6131 (class 0 OID 0)
-- Dependencies: 398
-- Name: seo_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_scores_id_seq OWNED BY public.seo_scores.id;


--
-- TOC entry 353 (class 1259 OID 158539)
-- Name: service_inquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_inquiries (
    id bigint NOT NULL,
    inquiry_number character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    company_name character varying(255) NOT NULL,
    company_type character varying(100),
    phone character varying(50) NOT NULL,
    contact_person character varying(255) NOT NULL,
    "position" character varying(100),
    kbli_code character varying(10),
    kbli_description text,
    business_activity text NOT NULL,
    form_data json NOT NULL,
    ai_analysis json,
    ai_model_used character varying(50) DEFAULT 'gpt-3.5-turbo'::character varying,
    ai_processing_time integer,
    ai_tokens_used integer,
    analyzed_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'new'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    source character varying(50) DEFAULT 'landing_page'::character varying NOT NULL,
    utm_source character varying(100),
    utm_medium character varying(100),
    utm_campaign character varying(100),
    client_id bigint,
    converted_to_application_id bigint,
    converted_at timestamp(0) without time zone,
    ip_address inet,
    user_agent text,
    session_id character varying(255),
    last_contacted_at timestamp(0) without time zone,
    contacted_by bigint,
    admin_notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT service_inquiries_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[]))),
    CONSTRAINT service_inquiries_status_check CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'processing'::character varying, 'analyzed'::character varying, 'contacted'::character varying, 'qualified'::character varying, 'converted'::character varying, 'registered'::character varying, 'lost'::character varying])::text[])))
);


--
-- TOC entry 6132 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN service_inquiries.inquiry_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.inquiry_number IS 'Format: INQ-2025-XXXX';


--
-- TOC entry 6133 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN service_inquiries.company_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.company_type IS 'PT, CV, Individual, etc';


--
-- TOC entry 6134 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN service_inquiries.business_activity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.business_activity IS 'User description of business';


--
-- TOC entry 6135 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN service_inquiries.form_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.form_data IS 'All form fields in JSON format';


--
-- TOC entry 6136 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN service_inquiries.ai_analysis; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.ai_analysis IS 'AI recommendations and analysis';


--
-- TOC entry 6137 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN service_inquiries.ai_processing_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_inquiries.ai_processing_time IS 'Processing time in milliseconds';


--
-- TOC entry 352 (class 1259 OID 158538)
-- Name: service_inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_inquiries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6138 (class 0 OID 0)
-- Dependencies: 352
-- Name: service_inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_inquiries_id_seq OWNED BY public.service_inquiries.id;


--
-- TOC entry 222 (class 1259 OID 156908)
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


--
-- TOC entry 411 (class 1259 OID 159237)
-- Name: shapefile_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shapefile_projects (
    id bigint NOT NULL,
    user_id bigint,
    name character varying(255) NOT NULL,
    geojson json NOT NULL,
    area_m2 numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    area_ha numeric(12,6) DEFAULT '0'::numeric NOT NULL,
    perimeter_m numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    metadata json,
    file_path character varying(255),
    session_token character varying(64),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    company_name character varying(150),
    contact_person character varying(100),
    email character varying(150),
    phone character varying(30),
    agreed_terms_at timestamp(0) without time zone,
    service_inquiry_id bigint,
    ip_address inet,
    user_agent text,
    rtrw_zona character varying(200),
    rtrw_perda character varying(100),
    rtrw_remark text,
    rtrw_raw json
);


--
-- TOC entry 410 (class 1259 OID 159236)
-- Name: shapefile_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shapefile_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6139 (class 0 OID 0)
-- Dependencies: 410
-- Name: shapefile_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shapefile_projects_id_seq OWNED BY public.shapefile_projects.id;


--
-- TOC entry 413 (class 1259 OID 159276)
-- Name: social_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_posts (
    id bigint NOT NULL,
    article_id bigint NOT NULL,
    platform character varying(255) NOT NULL,
    caption text,
    platform_post_id character varying(255),
    platform_url character varying(255),
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    posted_at timestamp(0) without time zone,
    scheduled_for timestamp(0) without time zone,
    metrics json,
    error_message text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 412 (class 1259 OID 159275)
-- Name: social_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6140 (class 0 OID 0)
-- Dependencies: 412
-- Name: social_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_posts_id_seq OWNED BY public.social_posts.id;


--
-- TOC entry 285 (class 1259 OID 157673)
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id bigint NOT NULL,
    company_name character varying(255),
    company_email character varying(255),
    company_phone character varying(255),
    company_website character varying(255),
    company_address text,
    maintenance_mode boolean DEFAULT false NOT NULL,
    email_notifications boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 284 (class 1259 OID 157672)
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6141 (class 0 OID 0)
-- Dependencies: 284
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- TOC entry 237 (class 1259 OID 157017)
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    sop_notes text,
    assigned_user_id bigint,
    due_date date,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'todo'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'normal'::character varying NOT NULL,
    institution_id bigint,
    depends_on_task_id bigint,
    completion_notes text,
    estimated_hours integer,
    actual_hours integer,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    project_permit_id bigint,
    CONSTRAINT tasks_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'normal'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT tasks_status_check CHECK (((status)::text = ANY ((ARRAY['todo'::character varying, 'in_progress'::character varying, 'done'::character varying, 'blocked'::character varying])::text[])))
);


--
-- TOC entry 6142 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN tasks.sop_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.sop_notes IS 'SOP atau checklist tugas';


--
-- TOC entry 236 (class 1259 OID 157016)
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6143 (class 0 OID 0)
-- Dependencies: 236
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- TOC entry 291 (class 1259 OID 157713)
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    rate numeric(5,2) NOT NULL,
    description character varying(255),
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 290 (class 1259 OID 157712)
-- Name: tax_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tax_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6144 (class 0 OID 0)
-- Dependencies: 290
-- Name: tax_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tax_rates_id_seq OWNED BY public.tax_rates.id;


--
-- TOC entry 365 (class 1259 OID 158701)
-- Name: technical_test_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technical_test_submissions (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    test_title character varying(255) NOT NULL,
    test_description text,
    original_file_path character varying(500),
    submission_file_path character varying(500) NOT NULL,
    file_type character varying(50),
    format_score numeric(5,2),
    format_issues json,
    reviewer_id bigint,
    review_score numeric(5,2),
    review_notes text,
    reviewed_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'submitted'::character varying NOT NULL,
    submitted_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT technical_test_submissions_status_check CHECK (((status)::text = ANY ((ARRAY['submitted'::character varying, 'under-review'::character varying, 'reviewed'::character varying])::text[])))
);


--
-- TOC entry 6145 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN technical_test_submissions.original_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.original_file_path IS 'Template file provided';


--
-- TOC entry 6146 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN technical_test_submissions.submission_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.submission_file_path IS 'Candidate submission';


--
-- TOC entry 6147 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN technical_test_submissions.file_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.file_type IS 'docx, xlsx, pdf, etc';


--
-- TOC entry 6148 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN technical_test_submissions.format_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.format_score IS 'Auto-scoring format compliance';


--
-- TOC entry 6149 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN technical_test_submissions.format_issues; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.format_issues IS 'Array of detected issues';


--
-- TOC entry 6150 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN technical_test_submissions.review_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.technical_test_submissions.review_score IS 'Manual score 0-100';


--
-- TOC entry 364 (class 1259 OID 158700)
-- Name: technical_test_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.technical_test_submissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6151 (class 0 OID 0)
-- Dependencies: 364
-- Name: technical_test_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.technical_test_submissions_id_seq OWNED BY public.technical_test_submissions.id;


--
-- TOC entry 369 (class 1259 OID 158753)
-- Name: test_answers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_answers (
    id bigint NOT NULL,
    test_session_id bigint NOT NULL,
    question_id character varying(100) NOT NULL,
    answer_data json NOT NULL,
    is_correct boolean,
    points_earned numeric(5,2),
    time_spent_seconds integer,
    answered_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 6152 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN test_answers.question_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_answers.question_id IS 'References question in test_template';


--
-- TOC entry 6153 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN test_answers.answer_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_answers.answer_data IS 'Flexible: multiple choice, text, etc.';


--
-- TOC entry 368 (class 1259 OID 158752)
-- Name: test_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.test_answers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6154 (class 0 OID 0)
-- Dependencies: 368
-- Name: test_answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.test_answers_id_seq OWNED BY public.test_answers.id;


--
-- TOC entry 367 (class 1259 OID 158725)
-- Name: test_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_sessions (
    id bigint NOT NULL,
    job_application_id bigint NOT NULL,
    test_template_id bigint NOT NULL,
    session_token character varying(64) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    starts_at timestamp(0) without time zone NOT NULL,
    expires_at timestamp(0) without time zone NOT NULL,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    score numeric(5,2),
    passed boolean DEFAULT false NOT NULL,
    time_taken_minutes integer,
    ip_address character varying(45),
    user_agent text,
    tab_switches integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    submitted_file_path character varying(500),
    submitted_at timestamp(0) without time zone,
    evaluation_scores json,
    evaluator_id bigint,
    evaluator_notes text,
    evaluated_at timestamp(0) without time zone,
    requires_manual_review boolean DEFAULT false NOT NULL,
    recruitment_stage_id bigint,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT test_sessions_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in-progress'::character varying, 'completed'::character varying, 'expired'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- TOC entry 6155 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.score IS '0-100 percentage';


--
-- TOC entry 6156 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.tab_switches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.tab_switches IS 'Anti-cheat: detect tab switching';


--
-- TOC entry 6157 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.submitted_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.submitted_file_path IS 'Path to submitted document';


--
-- TOC entry 6158 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.submitted_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.submitted_at IS 'When candidate uploaded the file';


--
-- TOC entry 6159 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.evaluation_scores; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.evaluation_scores IS 'Detailed scores per criteria';


--
-- TOC entry 6160 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.evaluator_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.evaluator_notes IS 'Notes from evaluator';


--
-- TOC entry 6161 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.evaluated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.evaluated_at IS 'When evaluation completed';


--
-- TOC entry 6162 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN test_sessions.requires_manual_review; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_sessions.requires_manual_review IS 'For document-editing type';


--
-- TOC entry 366 (class 1259 OID 158724)
-- Name: test_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.test_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6163 (class 0 OID 0)
-- Dependencies: 366
-- Name: test_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.test_sessions_id_seq OWNED BY public.test_sessions.id;


--
-- TOC entry 361 (class 1259 OID 158664)
-- Name: test_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_templates (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    test_type character varying(50) NOT NULL,
    description text,
    duration_minutes integer NOT NULL,
    passing_score integer NOT NULL,
    questions_data json,
    instructions text,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    template_file_path character varying(500),
    evaluation_criteria json
);


--
-- TOC entry 6164 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN test_templates.passing_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.passing_score IS 'Percentage (0-100)';


--
-- TOC entry 6165 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN test_templates.questions_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.questions_data IS 'Question bank with answers';


--
-- TOC entry 6166 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN test_templates.template_file_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.template_file_path IS 'Path to template document file';


--
-- TOC entry 6167 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN test_templates.evaluation_criteria; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.test_templates.evaluation_criteria IS 'Checklist/rubrik penilaian untuk document editing';


--
-- TOC entry 360 (class 1259 OID 158663)
-- Name: test_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.test_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6168 (class 0 OID 0)
-- Dependencies: 360
-- Name: test_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.test_templates_id_seq OWNED BY public.test_templates.id;


--
-- TOC entry 393 (class 1259 OID 159084)
-- Name: topic_clusters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.topic_clusters (
    id bigint NOT NULL,
    pillar_title character varying(255) NOT NULL,
    pillar_slug character varying(255) NOT NULL,
    pillar_description text NOT NULL,
    service_slug character varying(255),
    language character varying(5) DEFAULT 'id'::character varying NOT NULL,
    subtopics json NOT NULL,
    article_ids json,
    keyword_cluster_ids json,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    internal_links_built integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 392 (class 1259 OID 159083)
-- Name: topic_clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.topic_clusters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6169 (class 0 OID 0)
-- Dependencies: 392
-- Name: topic_clusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.topic_clusters_id_seq OWNED BY public.topic_clusters.id;


--
-- TOC entry 419 (class 1259 OID 159330)
-- Name: trending_topics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trending_topics (
    id bigint NOT NULL,
    topic character varying(255) NOT NULL,
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    language character varying(255) DEFAULT 'id'::character varying NOT NULL,
    data_source character varying(255) DEFAULT 'searxng'::character varying NOT NULL,
    trend_score integer DEFAULT 0 NOT NULL,
    search_volume integer,
    related_keywords json,
    top_sources json,
    sample_headline text,
    is_processed boolean DEFAULT false NOT NULL,
    article_id bigint,
    discovered_at timestamp(0) without time zone NOT NULL,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- TOC entry 418 (class 1259 OID 159329)
-- Name: trending_topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trending_topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6170 (class 0 OID 0)
-- Dependencies: 418
-- Name: trending_topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trending_topics_id_seq OWNED BY public.trending_topics.id;


--
-- TOC entry 220 (class 1259 OID 156891)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    full_name character varying(255),
    "position" character varying(255),
    phone character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(0) without time zone,
    notes text,
    avatar character varying(255),
    role_id bigint,
    company_email character varying(255),
    department character varying(255) NOT NULL,
    email_signature text,
    job_title character varying(255),
    notification_preferences json,
    working_hours json,
    username character varying(255),
    employee_id character varying(255),
    bio text,
    expertise character varying(500),
    linkedin_url character varying(255),
    twitter_url character varying(255),
    CONSTRAINT users_department_check CHECK (((department)::text = ANY (ARRAY[('general'::character varying)::text, ('cs'::character varying)::text, ('sales'::character varying)::text, ('support'::character varying)::text, ('finance'::character varying)::text, ('technical'::character varying)::text])))
);


--
-- TOC entry 219 (class 1259 OID 156890)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 6171 (class 0 OID 0)
-- Dependencies: 219
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 4580 (class 2604 OID 157763)
-- Name: ai_processing_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_processing_logs_id_seq'::regclass);


--
-- TOC entry 4675 (class 2604 OID 158355)
-- Name: ai_query_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_query_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_query_logs_id_seq'::regclass);


--
-- TOC entry 4741 (class 2604 OID 158899)
-- Name: ai_setting_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history ALTER COLUMN id SET DEFAULT nextval('public.ai_setting_history_id_seq'::regclass);


--
-- TOC entry 4735 (class 2604 OID 158871)
-- Name: ai_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings ALTER COLUMN id SET DEFAULT nextval('public.ai_settings_id_seq'::regclass);


--
-- TOC entry 4652 (class 2604 OID 158169)
-- Name: application_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents ALTER COLUMN id SET DEFAULT nextval('public.application_documents_id_seq'::regclass);


--
-- TOC entry 4683 (class 2604 OID 158449)
-- Name: application_legality_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_legality_documents ALTER COLUMN id SET DEFAULT nextval('public.application_legality_documents_id_seq'::regclass);


--
-- TOC entry 4682 (class 2604 OID 158428)
-- Name: application_location_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details ALTER COLUMN id SET DEFAULT nextval('public.application_location_details_id_seq'::regclass);


--
-- TOC entry 4666 (class 2604 OID 158300)
-- Name: application_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes ALTER COLUMN id SET DEFAULT nextval('public.application_notes_id_seq'::regclass);


--
-- TOC entry 4679 (class 2604 OID 158402)
-- Name: application_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions ALTER COLUMN id SET DEFAULT nextval('public.application_revisions_id_seq'::regclass);


--
-- TOC entry 4661 (class 2604 OID 158225)
-- Name: application_status_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_status_logs ALTER COLUMN id SET DEFAULT nextval('public.application_status_logs_id_seq'::regclass);


--
-- TOC entry 4773 (class 2604 OID 159022)
-- Name: article_topic_similarities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities ALTER COLUMN id SET DEFAULT nextval('public.article_topic_similarities_id_seq'::regclass);


--
-- TOC entry 4742 (class 2604 OID 158922)
-- Name: article_topics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics ALTER COLUMN id SET DEFAULT nextval('public.article_topics_id_seq'::regclass);


--
-- TOC entry 4793 (class 2604 OID 159128)
-- Name: article_view_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs ALTER COLUMN id SET DEFAULT nextval('public.article_view_logs_id_seq'::regclass);


--
-- TOC entry 4544 (class 2604 OID 157646)
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- TOC entry 4748 (class 2604 OID 158947)
-- Name: auto_post_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_configs ALTER COLUMN id SET DEFAULT nextval('public.auto_post_configs_id_seq'::regclass);


--
-- TOC entry 4771 (class 2604 OID 158994)
-- Name: auto_post_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs ALTER COLUMN id SET DEFAULT nextval('public.auto_post_logs_id_seq'::regclass);


--
-- TOC entry 4768 (class 2604 OID 158975)
-- Name: auto_post_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules ALTER COLUMN id SET DEFAULT nextval('public.auto_post_schedules_id_seq'::regclass);


--
-- TOC entry 4533 (class 2604 OID 157566)
-- Name: bank_reconciliations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations ALTER COLUMN id SET DEFAULT nextval('public.bank_reconciliations_id_seq'::regclass);


--
-- TOC entry 4540 (class 2604 OID 157605)
-- Name: bank_statement_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_entries ALTER COLUMN id SET DEFAULT nextval('public.bank_statement_entries_id_seq'::regclass);


--
-- TOC entry 4691 (class 2604 OID 158503)
-- Name: business_contexts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts ALTER COLUMN id SET DEFAULT nextval('public.business_contexts_id_seq'::regclass);


--
-- TOC entry 4700 (class 2604 OID 158585)
-- Name: cash_account_balance_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history ALTER COLUMN id SET DEFAULT nextval('public.cash_account_balance_history_id_seq'::regclass);


--
-- TOC entry 4473 (class 2604 OID 157145)
-- Name: cash_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_accounts ALTER COLUMN id SET DEFAULT nextval('public.cash_accounts_id_seq'::regclass);


--
-- TOC entry 4525 (class 2604 OID 157479)
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- TOC entry 4803 (class 2604 OID 159191)
-- Name: competitor_analyses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_analyses ALTER COLUMN id SET DEFAULT nextval('public.competitor_analyses_id_seq'::regclass);


--
-- TOC entry 4584 (class 2604 OID 157837)
-- Name: compliance_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checks ALTER COLUMN id SET DEFAULT nextval('public.compliance_checks_id_seq'::regclass);


--
-- TOC entry 4727 (class 2604 OID 158827)
-- Name: consult_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests ALTER COLUMN id SET DEFAULT nextval('public.consult_requests_id_seq'::regclass);


--
-- TOC entry 4788 (class 2604 OID 159103)
-- Name: content_gaps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps ALTER COLUMN id SET DEFAULT nextval('public.content_gaps_id_seq'::regclass);


--
-- TOC entry 4800 (class 2604 OID 159173)
-- Name: content_refresh_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_refresh_logs ALTER COLUMN id SET DEFAULT nextval('public.content_refresh_logs_id_seq'::regclass);


--
-- TOC entry 4774 (class 2604 OID 159044)
-- Name: content_syndications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_syndications ALTER COLUMN id SET DEFAULT nextval('public.content_syndications_id_seq'::regclass);


--
-- TOC entry 4582 (class 2604 OID 157798)
-- Name: document_drafts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts ALTER COLUMN id SET DEFAULT nextval('public.document_drafts_id_seq'::regclass);


--
-- TOC entry 4578 (class 2604 OID 157745)
-- Name: document_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates ALTER COLUMN id SET DEFAULT nextval('public.document_templates_id_seq'::regclass);


--
-- TOC entry 4466 (class 2604 OID 157057)
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- TOC entry 4630 (class 2604 OID 158035)
-- Name: email_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_accounts ALTER COLUMN id SET DEFAULT nextval('public.email_accounts_id_seq'::regclass);


--
-- TOC entry 4637 (class 2604 OID 158056)
-- Name: email_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments ALTER COLUMN id SET DEFAULT nextval('public.email_assignments_id_seq'::regclass);


--
-- TOC entry 4611 (class 2604 OID 157943)
-- Name: email_campaigns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns ALTER COLUMN id SET DEFAULT nextval('public.email_campaigns_id_seq'::regclass);


--
-- TOC entry 4623 (class 2604 OID 158002)
-- Name: email_inbox id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox ALTER COLUMN id SET DEFAULT nextval('public.email_inbox_id_seq'::regclass);


--
-- TOC entry 4620 (class 2604 OID 157974)
-- Name: email_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);


--
-- TOC entry 4605 (class 2604 OID 157913)
-- Name: email_subscribers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_subscribers ALTER COLUMN id SET DEFAULT nextval('public.email_subscribers_id_seq'::regclass);


--
-- TOC entry 4608 (class 2604 OID 157929)
-- Name: email_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates ALTER COLUMN id SET DEFAULT nextval('public.email_templates_id_seq'::regclass);


--
-- TOC entry 4554 (class 2604 OID 157687)
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- TOC entry 4444 (class 2604 OID 156952)
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- TOC entry 4446 (class 2604 OID 156964)
-- Name: institutions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions ALTER COLUMN id SET DEFAULT nextval('public.institutions_id_seq'::regclass);


--
-- TOC entry 4708 (class 2604 OID 158645)
-- Name: interview_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback ALTER COLUMN id SET DEFAULT nextval('public.interview_feedback_id_seq'::regclass);


--
-- TOC entry 4702 (class 2604 OID 158615)
-- Name: interview_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules ALTER COLUMN id SET DEFAULT nextval('public.interview_schedules_id_seq'::regclass);


--
-- TOC entry 4516 (class 2604 OID 157411)
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- TOC entry 4508 (class 2604 OID 157383)
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- TOC entry 4602 (class 2604 OID 157886)
-- Name: job_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications ALTER COLUMN id SET DEFAULT nextval('public.job_applications_id_seq'::regclass);


--
-- TOC entry 4596 (class 2604 OID 157867)
-- Name: job_vacancies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_vacancies ALTER COLUMN id SET DEFAULT nextval('public.job_vacancies_id_seq'::regclass);


--
-- TOC entry 4443 (class 2604 OID 156935)
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- TOC entry 4669 (class 2604 OID 158322)
-- Name: kbli id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli ALTER COLUMN id SET DEFAULT nextval('public.kbli_id_seq'::regclass);


--
-- TOC entry 4673 (class 2604 OID 158337)
-- Name: kbli_permit_recommendations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli_permit_recommendations ALTER COLUMN id SET DEFAULT nextval('public.kbli_permit_recommendations_id_seq'::regclass);


--
-- TOC entry 4723 (class 2604 OID 158800)
-- Name: kblis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kblis ALTER COLUMN id SET DEFAULT nextval('public.kblis_id_seq'::regclass);


--
-- TOC entry 4776 (class 2604 OID 159067)
-- Name: keyword_clusters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_clusters ALTER COLUMN id SET DEFAULT nextval('public.keyword_clusters_id_seq'::regclass);


--
-- TOC entry 4822 (class 2604 OID 159297)
-- Name: keyword_position_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_position_history ALTER COLUMN id SET DEFAULT nextval('public.keyword_position_history_id_seq'::regclass);


--
-- TOC entry 4805 (class 2604 OID 159202)
-- Name: meta_ab_tests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_ab_tests ALTER COLUMN id SET DEFAULT nextval('public.meta_ab_tests_id_seq'::regclass);


--
-- TOC entry 4440 (class 2604 OID 156887)
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- TOC entry 4532 (class 2604 OID 157559)
-- Name: milestones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones ALTER COLUMN id SET DEFAULT nextval('public.milestones_id_seq'::regclass);


--
-- TOC entry 4663 (class 2604 OID 158242)
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- TOC entry 4558 (class 2604 OID 157701)
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- TOC entry 4521 (class 2604 OID 157428)
-- Name: payment_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules ALTER COLUMN id SET DEFAULT nextval('public.payment_schedules_id_seq'::regclass);


--
-- TOC entry 4664 (class 2604 OID 158254)
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- TOC entry 4531 (class 2604 OID 157540)
-- Name: permission_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role ALTER COLUMN id SET DEFAULT nextval('public.permission_role_id_seq'::regclass);


--
-- TOC entry 4530 (class 2604 OID 157529)
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- TOC entry 4648 (class 2604 OID 158131)
-- Name: permit_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications ALTER COLUMN id SET DEFAULT nextval('public.permit_applications_id_seq'::regclass);


--
-- TOC entry 4524 (class 2604 OID 157453)
-- Name: permit_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents ALTER COLUMN id SET DEFAULT nextval('public.permit_documents_id_seq'::regclass);


--
-- TOC entry 4497 (class 2604 OID 157285)
-- Name: permit_template_dependencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies ALTER COLUMN id SET DEFAULT nextval('public.permit_template_dependencies_id_seq'::regclass);


--
-- TOC entry 4494 (class 2604 OID 157263)
-- Name: permit_template_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items ALTER COLUMN id SET DEFAULT nextval('public.permit_template_items_id_seq'::regclass);


--
-- TOC entry 4491 (class 2604 OID 157245)
-- Name: permit_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_templates ALTER COLUMN id SET DEFAULT nextval('public.permit_templates_id_seq'::regclass);


--
-- TOC entry 4489 (class 2604 OID 157225)
-- Name: permit_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types ALTER COLUMN id SET DEFAULT nextval('public.permit_types_id_seq'::regclass);


--
-- TOC entry 4482 (class 2604 OID 157190)
-- Name: project_expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses ALTER COLUMN id SET DEFAULT nextval('public.project_expenses_id_seq'::regclass);


--
-- TOC entry 4472 (class 2604 OID 157095)
-- Name: project_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs ALTER COLUMN id SET DEFAULT nextval('public.project_logs_id_seq'::regclass);


--
-- TOC entry 4478 (class 2604 OID 157160)
-- Name: project_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments ALTER COLUMN id SET DEFAULT nextval('public.project_payments_id_seq'::regclass);


--
-- TOC entry 4505 (class 2604 OID 157348)
-- Name: project_permit_dependencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies ALTER COLUMN id SET DEFAULT nextval('public.project_permit_dependencies_id_seq'::regclass);


--
-- TOC entry 4499 (class 2604 OID 157312)
-- Name: project_permits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits ALTER COLUMN id SET DEFAULT nextval('public.project_permits_id_seq'::regclass);


--
-- TOC entry 4448 (class 2604 OID 156974)
-- Name: project_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses ALTER COLUMN id SET DEFAULT nextval('public.project_statuses_id_seq'::regclass);


--
-- TOC entry 4453 (class 2604 OID 156989)
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- TOC entry 4678 (class 2604 OID 158385)
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- TOC entry 4685 (class 2604 OID 158468)
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- TOC entry 4656 (class 2604 OID 158192)
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- TOC entry 4825 (class 2604 OID 159313)
-- Name: ranking_alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranking_alerts ALTER COLUMN id SET DEFAULT nextval('public.ranking_alerts_id_seq'::regclass);


--
-- TOC entry 4711 (class 2604 OID 158684)
-- Name: recruitment_stages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages ALTER COLUMN id SET DEFAULT nextval('public.recruitment_stages_id_seq'::regclass);


--
-- TOC entry 4528 (class 2604 OID 157517)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 4811 (class 2604 OID 159222)
-- Name: search_console_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_console_data ALTER COLUMN id SET DEFAULT nextval('public.search_console_data_id_seq'::regclass);


--
-- TOC entry 4567 (class 2604 OID 157728)
-- Name: security_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_settings ALTER COLUMN id SET DEFAULT nextval('public.security_settings_id_seq'::regclass);


--
-- TOC entry 4798 (class 2604 OID 159162)
-- Name: seo_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_reports ALTER COLUMN id SET DEFAULT nextval('public.seo_reports_id_seq'::regclass);


--
-- TOC entry 4796 (class 2604 OID 159145)
-- Name: seo_scores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores ALTER COLUMN id SET DEFAULT nextval('public.seo_scores_id_seq'::regclass);


--
-- TOC entry 4695 (class 2604 OID 158542)
-- Name: service_inquiries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries ALTER COLUMN id SET DEFAULT nextval('public.service_inquiries_id_seq'::regclass);


--
-- TOC entry 4816 (class 2604 OID 159240)
-- Name: shapefile_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects ALTER COLUMN id SET DEFAULT nextval('public.shapefile_projects_id_seq'::regclass);


--
-- TOC entry 4820 (class 2604 OID 159279)
-- Name: social_posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_posts ALTER COLUMN id SET DEFAULT nextval('public.social_posts_id_seq'::regclass);


--
-- TOC entry 4551 (class 2604 OID 157676)
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- TOC entry 4462 (class 2604 OID 157020)
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- TOC entry 4563 (class 2604 OID 157716)
-- Name: tax_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates ALTER COLUMN id SET DEFAULT nextval('public.tax_rates_id_seq'::regclass);


--
-- TOC entry 4713 (class 2604 OID 158704)
-- Name: technical_test_submissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions ALTER COLUMN id SET DEFAULT nextval('public.technical_test_submissions_id_seq'::regclass);


--
-- TOC entry 4721 (class 2604 OID 158756)
-- Name: test_answers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_answers ALTER COLUMN id SET DEFAULT nextval('public.test_answers_id_seq'::regclass);


--
-- TOC entry 4716 (class 2604 OID 158728)
-- Name: test_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions ALTER COLUMN id SET DEFAULT nextval('public.test_sessions_id_seq'::regclass);


--
-- TOC entry 4709 (class 2604 OID 158667)
-- Name: test_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_templates ALTER COLUMN id SET DEFAULT nextval('public.test_templates_id_seq'::regclass);


--
-- TOC entry 4784 (class 2604 OID 159087)
-- Name: topic_clusters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topic_clusters ALTER COLUMN id SET DEFAULT nextval('public.topic_clusters_id_seq'::regclass);


--
-- TOC entry 4828 (class 2604 OID 159333)
-- Name: trending_topics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trending_topics ALTER COLUMN id SET DEFAULT nextval('public.trending_topics_id_seq'::regclass);


--
-- TOC entry 4441 (class 2604 OID 156894)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 5816 (class 0 OID 157760)
-- Dependencies: 297
-- Data for Name: ai_processing_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_processing_logs (id, document_id, template_id, project_id, operation_type, status, input_tokens, output_tokens, cost, error_message, metadata, initiated_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5858 (class 0 OID 158352)
-- Dependencies: 339
-- Data for Name: ai_query_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_query_logs (id, client_id, kbli_code, business_context, prompt_text, response_text, tokens_used, response_time_ms, status, error_message, ai_model, api_cost, created_at) FROM stdin;
\.


--
-- TOC entry 5896 (class 0 OID 158896)
-- Dependencies: 377
-- Data for Name: ai_setting_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_setting_history (id, setting_id, key, old_value, new_value, changed_by_name, changed_by, reason, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5894 (class 0 OID 158868)
-- Dependencies: 375
-- Data for Name: ai_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_settings (id, category, key, value, data_type, description, is_public, is_encrypted, validation_rules, default_value, display_order, group_name, requires_restart, created_by, updated_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 5842 (class 0 OID 158166)
-- Dependencies: 323
-- Data for Name: application_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, is_verified, verified_by, verified_at, verification_notes, uploaded_at, created_at, updated_at, status, reviewed_by, reviewed_at, review_notes) FROM stdin;
\.


--
-- TOC entry 5866 (class 0 OID 158446)
-- Dependencies: 347
-- Data for Name: application_legality_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_legality_documents (id, application_id, document_category, document_name, is_available, document_number, issued_date, expiry_date, file_path, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5864 (class 0 OID 158425)
-- Dependencies: 345
-- Data for Name: application_location_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_location_details (id, application_id, province, city_regency, district, sub_district, full_address, postal_code, latitude, longitude, zone_type, land_status, land_certificate_number, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5852 (class 0 OID 158297)
-- Dependencies: 333
-- Data for Name: application_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_notes (id, application_id, author_type, author_id, note, is_internal, is_read, read_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5862 (class 0 OID 158399)
-- Dependencies: 343
-- Data for Name: application_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_revisions (id, application_id, revision_number, revision_type, revision_reason, revised_by_id, permits_data, project_data, total_cost, status, client_approved_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5846 (class 0 OID 158222)
-- Dependencies: 327
-- Data for Name: application_status_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_status_logs (id, application_id, from_status, to_status, notes, changed_by_type, changed_by_id, created_at) FROM stdin;
\.


--
-- TOC entry 5906 (class 0 OID 159019)
-- Dependencies: 387
-- Data for Name: article_topic_similarities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_topic_similarities (id, topic_a_id, topic_b_id, similarity_score, calculated_at) FROM stdin;
\.


--
-- TOC entry 5898 (class 0 OID 158919)
-- Dependencies: 379
-- Data for Name: article_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_topics (id, title, slug, description, category, keywords, tags, status, priority, article_id, published_at, scheduled_for, generation_notes, views_count, similarity_score, created_at, updated_at, deleted_at, language, target_market, topic_cluster_id) FROM stdin;
\.


--
-- TOC entry 5916 (class 0 OID 159125)
-- Dependencies: 397
-- Data for Name: article_view_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.article_view_logs (id, article_id, date, views, unique_views, top_referrer, top_country, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5802 (class 0 OID 157643)
-- Dependencies: 283
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.articles (id, title, slug, excerpt, content, featured_image, category, tags, status, published_at, views_count, author_id, meta_title, meta_description, meta_keywords, is_featured, reading_time, created_at, updated_at, deleted_at, source_type, language, topic_cluster_id) FROM stdin;
1	Pentingnya Dokumen LB3 dalam Pengelolaan Limbah Bahan Berbahaya dan Beracun	pentingnya-dokumen-lb3-dalam-pengelolaan-limbah-bahan-berbahaya-dan-beracun	Dokumen LB3 (Limbah Bahan Berbahaya dan Beracun) merupakan dokumen penting yang wajib dimiliki oleh setiap perusahaan yang menghasilkan limbah B3.	<h2>Apa itu LB3?</h2>\n                <p>LB3 atau Limbah Bahan Berbahaya dan Beracun adalah sisa suatu usaha dan/atau kegiatan yang mengandung bahan berbahaya dan/atau beracun yang karena sifat dan/atau konsentrasinya dan/atau jumlahnya, baik secara langsung maupun tidak langsung, dapat mencemarkan dan/atau merusak lingkungan hidup, dan/atau dapat membahayakan lingkungan hidup, kesehatan, kelangsungan hidup manusia serta makhluk hidup lain.</p>\n                \n                <h2>Mengapa Dokumen LB3 Penting?</h2>\n                <p>Dokumen LB3 memiliki beberapa fungsi penting:</p>\n                <ul>\n                    <li>Sebagai bukti kepatuhan terhadap peraturan perundang-undangan lingkungan hidup</li>\n                    <li>Memastikan pengelolaan limbah B3 dilakukan dengan benar dan aman</li>\n                    <li>Melindungi lingkungan dari pencemaran limbah B3</li>\n                    <li>Mencegah sanksi hukum dan administratif dari pemerintah</li>\n                </ul>\n                \n                <h2>Peraturan yang Mengatur LB3</h2>\n                <p>Pengelolaan LB3 di Indonesia diatur dalam berbagai peraturan, antara lain:</p>\n                <ul>\n                    <li>PP No. 101 Tahun 2014 tentang Pengelolaan Limbah B3</li>\n                    <li>PP No. 22 Tahun 2021 tentang Penyelenggaraan Perlindungan dan Pengelolaan Lingkungan Hidup</li>\n                    <li>Permen LHK No. 6 Tahun 2021 tentang Tata Cara dan Persyaratan Pengelolaan Limbah B3</li>\n                </ul>\n                \n                <h2>Layanan PT CANGAH PAJARATAN MANDIRI</h2>\n                <p>PT CANGAH PAJARATAN MANDIRI siap membantu perusahaan Anda dalam pengurusan dokumen LB3, mulai dari konsultasi, penyusunan dokumen, hingga pendampingan proses perizinan.</p>	\N	tips	["lb3","limbah b3","perizinan","lingkungan"]	published	2026-04-05 12:04:44	0	2	Pentingnya Dokumen LB3 dalam Pengelolaan Limbah B3	Pelajari pentingnya dokumen LB3 dalam pengelolaan limbah bahan berbahaya dan beracun serta peraturan yang mengaturnya.	lb3, limbah b3, pengelolaan limbah, perizinan lingkungan	t	1	2026-04-15 12:04:44	2026-04-15 12:04:44	\N	manual	id	\N
2	Panduan Lengkap AMDAL: Analisis Mengenai Dampak Lingkungan	panduan-lengkap-amdal-analisis-mengenai-dampak-lingkungan	AMDAL adalah kajian mengenai dampak penting suatu usaha dan/atau kegiatan yang direncanakan pada lingkungan hidup yang diperlukan bagi proses pengambilan keputusan.	<h2>Apa itu AMDAL?</h2>\n                <p>AMDAL (Analisis Mengenai Dampak Lingkungan) adalah kajian mengenai dampak penting suatu usaha dan/atau kegiatan yang direncanakan pada lingkungan hidup yang diperlukan bagi proses pengambilan keputusan tentang penyelenggaraan usaha dan/atau kegiatan.</p>\n                \n                <h2>Siapa yang Wajib Membuat AMDAL?</h2>\n                <p>Setiap usaha dan/atau kegiatan yang berdampak penting terhadap lingkungan hidup wajib memiliki AMDAL. Jenis usaha yang wajib AMDAL diatur dalam Permen LHK No. 4 Tahun 2021 tentang Daftar Usaha dan/atau Kegiatan yang Wajib Memiliki AMDAL.</p>\n                \n                <h2>Dokumen dalam AMDAL</h2>\n                <p>AMDAL terdiri dari beberapa dokumen:</p>\n                <ol>\n                    <li><strong>Kerangka Acuan (KA)</strong> - Ruang lingkup kajian AMDAL</li>\n                    <li><strong>Analisis Dampak Lingkungan (ANDAL)</strong> - Telaahan mendalam dampak penting</li>\n                    <li><strong>Rencana Pengelolaan Lingkungan (RKL)</strong> - Upaya penanganan dampak</li>\n                    <li><strong>Rencana Pemantauan Lingkungan (RPL)</strong> - Upaya pemantauan dampak</li>\n                </ol>\n                \n                <h2>Proses Penyusunan AMDAL</h2>\n                <p>Proses penyusunan AMDAL meliputi beberapa tahap yang harus dilalui dengan cermat dan sesuai regulasi yang berlaku. Tim kami memiliki pengalaman dalam membantu perusahaan menyusun dokumen AMDAL yang berkualitas.</p>	\N	tips	["amdal","lingkungan","perizinan","dampak lingkungan"]	published	2026-04-08 12:04:44	0	2	Panduan Lengkap AMDAL - Analisis Mengenai Dampak Lingkungan	Panduan lengkap tentang AMDAL, siapa yang wajib membuat, dokumen yang diperlukan, dan proses penyusunannya.	amdal, analisis dampak lingkungan, perizinan, lingkungan hidup	t	1	2026-04-15 12:04:44	2026-04-15 12:04:44	\N	manual	id	\N
3	Peraturan Terbaru: Permen LHK No. 4 Tahun 2021 tentang Daftar Usaha Wajib AMDAL	peraturan-terbaru-permen-lhk-no-4-tahun-2021-tentang-daftar-usaha-wajib-amdal	Pemerintah menerbitkan peraturan terbaru mengenai daftar usaha dan/atau kegiatan yang wajib memiliki AMDAL.	<h2>Perubahan Signifikan</h2>\n                <p>Permen LHK No. 4 Tahun 2021 menggantikan Permen LHK No. P.38/Menlhk/Setjen/Kum.1/7/2019 tentang Jenis Rencana Usaha dan/atau Kegiatan yang Wajib Memiliki AMDAL.</p>\n                \n                <h2>Poin-Poin Penting</h2>\n                <ul>\n                    <li>Penyederhanaan daftar usaha wajib AMDAL</li>\n                    <li>Integrasi dengan sistem OSS (Online Single Submission)</li>\n                    <li>Percepatan proses perizinan lingkungan</li>\n                    <li>Penguatan peran konsultan lingkungan bersertifikat</li>\n                </ul>\n                \n                <h2>Dampak bagi Industri</h2>\n                <p>Peraturan ini membawa dampak positif bagi industri dalam hal efisiensi waktu dan biaya dalam pengurusan izin lingkungan. Namun, tetap memperhatikan aspek perlindungan lingkungan hidup.</p>	\N	regulation	["regulasi","amdal","permen lhk","perizinan"]	published	2026-04-10 12:04:44	0	2	Permen LHK No. 4 Tahun 2021 tentang Daftar Usaha Wajib AMDAL	Penjelasan lengkap tentang Permen LHK No. 4 Tahun 2021 yang mengatur daftar usaha wajib AMDAL.	permen lhk, amdal, regulasi lingkungan, perizinan	f	1	2026-04-15 12:04:44	2026-04-15 12:04:44	\N	manual	id	\N
4	Studi Kasus: Pengurusan Izin LB3 untuk Industri Manufaktur di Karawang	studi-kasus-pengurusan-izin-lb3-untuk-industri-manufaktur-di-karawang	Pengalaman kami dalam membantu perusahaan manufaktur di Karawang mendapatkan izin pengelolaan limbah B3.	<h2>Latar Belakang Proyek</h2>\n                <p>Sebuah perusahaan manufaktur elektronik di Karawang membutuhkan izin pengelolaan limbah B3 untuk operasional pabrik barunya. Perusahaan ini menghasilkan limbah B3 berupa solder waste, chemical waste, dan oil waste.</p>\n                \n                <h2>Tantangan yang Dihadapi</h2>\n                <ul>\n                    <li>Deadline ketat dari investor</li>\n                    <li>Kompleksitas jenis limbah B3 yang dihasilkan</li>\n                    <li>Koordinasi dengan berbagai instansi pemerintah</li>\n                    <li>Penyiapan fasilitas TPS limbah B3</li>\n                </ul>\n                \n                <h2>Solusi yang Kami Berikan</h2>\n                <p>Tim PT CANGAH PAJARATAN MANDIRI melakukan pendekatan komprehensif:</p>\n                <ol>\n                    <li>Survey lapangan dan analisis jenis limbah</li>\n                    <li>Penyusunan dokumen teknis dan administratif</li>\n                    <li>Konsultasi dengan DLHK Jawa Barat</li>\n                    <li>Pendampingan verifikasi lapangan</li>\n                    <li>Finalisasi dan penerbitan izin</li>\n                </ol>\n                \n                <h2>Hasil</h2>\n                <p>Izin berhasil terbit dalam waktu 45 hari kerja, lebih cepat dari estimasi awal 60 hari. Klien sangat puas dengan layanan kami dan operasional pabrik dapat dimulai sesuai jadwal.</p>	\N	case-study	["studi kasus","lb3","karawang","manufaktur"]	published	2026-04-12 12:04:44	0	2	Studi Kasus Pengurusan Izin LB3 Industri Manufaktur Karawang	Studi kasus sukses pengurusan izin LB3 untuk industri manufaktur di Karawang oleh PT CANGAH PAJARATAN MANDIRI.	studi kasus, lb3, karawang, industri manufaktur, perizinan	t	1	2026-04-15 12:04:44	2026-04-15 12:04:44	\N	manual	id	\N
5	PT CANGAH PAJARATAN MANDIRI Raih Penghargaan Best Environmental Consultant 2024	pt-cangah-pajaratan-mandiri-raih-penghargaan-best-environmental-consultant-2024	Kami dengan bangga mengumumkan bahwa PT CANGAH PAJARATAN MANDIRI telah meraih penghargaan sebagai Best Environmental Consultant 2024.	<h2>Penghargaan Bergengsi</h2>\n                <p>PT CANGAH PAJARATAN MANDIRI dengan bangga mengumumkan telah meraih penghargaan sebagai Best Environmental Consultant 2024 dari Asosiasi Konsultan Lingkungan Indonesia.</p>\n                \n                <h2>Kriteria Penilaian</h2>\n                <p>Penghargaan ini diberikan berdasarkan beberapa kriteria:</p>\n                <ul>\n                    <li>Jumlah proyek yang berhasil diselesaikan</li>\n                    <li>Tingkat kepuasan klien</li>\n                    <li>Inovasi dalam layanan konsultasi</li>\n                    <li>Kontribusi terhadap pelestarian lingkungan</li>\n                    <li>Profesionalisme dan integritas</li>\n                </ul>\n                \n                <h2>Komitmen Kami</h2>\n                <p>Penghargaan ini menjadi motivasi bagi kami untuk terus memberikan layanan terbaik kepada klien. Kami akan terus berinovasi dan meningkatkan kualitas layanan kami.</p>\n                \n                <h2>Terima Kasih</h2>\n                <p>Kami mengucapkan terima kasih kepada seluruh klien yang telah mempercayakan kebutuhan konsultasi lingkungan mereka kepada kami. Kepercayaan Anda adalah aset berharga bagi kami.</p>	\N	news	["berita","penghargaan","achievement"]	published	2026-04-14 12:04:44	1	2	PT CANGAH PAJARATAN MANDIRI Raih Best Environmental Consultant 2024	PT CANGAH PAJARATAN MANDIRI meraih penghargaan Best Environmental Consultant 2024 dari Asosiasi Konsultan Lingkungan Indonesia.	penghargaan, konsultan lingkungan, berita, achievement	f	1	2026-04-15 12:04:44	2026-04-15 12:05:37	\N	manual	id	\N
\.


--
-- TOC entry 5900 (class 0 OID 158944)
-- Dependencies: 381
-- Data for Name: auto_post_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_post_configs (id, is_enabled, posts_per_day, post_times, timezone, ai_model, min_word_count, max_word_count, min_reading_time, max_reading_time, min_headings, max_headings, min_paragraphs, internal_links_count, include_featured_image, auto_publish, duplicate_threshold, cooldown_days, excluded_keywords, category_weights, daily_limit, retry_attempts, timeout_seconds, created_at, updated_at, language_distribution, market_focus) FROM stdin;
1	f	3	["08:00","13:00","19:00"]	Asia/Jakarta	anthropic/claude-sonnet-4	800	1500	4	8	3	6	5	3	t	f	0.75	30	[]	{"general":20,"tips":40,"regulation":25,"case-study":10,"news":5}	5	3	120	2026-04-15 12:05:17	2026-04-15 12:05:17	\N	\N
\.


--
-- TOC entry 5904 (class 0 OID 158991)
-- Dependencies: 385
-- Data for Name: auto_post_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_post_logs (id, schedule_id, article_id, topic_id, level, event, message, context, word_count, reading_time, internal_links, ai_cost, created_at) FROM stdin;
\.


--
-- TOC entry 5902 (class 0 OID 158972)
-- Dependencies: 383
-- Data for Name: auto_post_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_post_schedules (id, topic_id, scheduled_at, status, error_message, attempts, started_at, completed_at, generation_time_seconds, metadata, created_at, updated_at, article_id) FROM stdin;
\.


--
-- TOC entry 5798 (class 0 OID 157563)
-- Dependencies: 279
-- Data for Name: bank_reconciliations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_reconciliations (id, cash_account_id, reconciliation_date, start_date, end_date, opening_balance_book, opening_balance_bank, closing_balance_book, closing_balance_bank, total_deposits_in_transit, total_outstanding_checks, total_bank_charges, total_bank_credits, adjusted_bank_balance, adjusted_book_balance, difference, status, bank_statement_file, bank_statement_format, notes, reconciled_by, reviewed_by, approved_by, completed_at, reviewed_at, approved_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5800 (class 0 OID 157602)
-- Dependencies: 281
-- Data for Name: bank_statement_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_statement_entries (id, reconciliation_id, transaction_date, description, debit_amount, credit_amount, running_balance, reference_number, is_matched, matched_transaction_type, matched_transaction_id, match_confidence, match_notes, unmatch_reason, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5870 (class 0 OID 158500)
-- Dependencies: 351
-- Data for Name: business_contexts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_contexts (id, client_id, kbli_code, land_area, building_area, number_of_floors, investment_value, province, city, district, zone_type, coordinates, location_category, number_of_employees, production_capacity, annual_revenue_target, business_scale, environmental_impact, waste_management, near_protected_area, environmental_notes, ownership_status, existing_permits, urgency_level, additional_notes, custom_fields, ip_address, user_agent, submitted_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5742 (class 0 OID 156917)
-- Dependencies: 223
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache (key, value, expiration) FROM stdin;
bizmark-administration-cache-pseo.articles.monitoring-digital.subang	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776315959
bizmark-administration-cache-pseo.articles.izin-k3.batam	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776306963
bizmark-administration-cache-neural_metrics:2026-04-15-09	a:26:{i:0;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.91;s:9:"timestamp";i:1776219865;}i:1;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:3.74;s:9:"timestamp";i:1776219998;}i:2;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:14.99;s:9:"timestamp";i:1776220006;}i:3;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:3.76;s:9:"timestamp";i:1776220038;}i:4;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.56;s:9:"timestamp";i:1776220088;}i:5;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:6.77;s:9:"timestamp";i:1776220111;}i:6;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:6.73;s:9:"timestamp";i:1776220124;}i:7;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:5.82;s:9:"timestamp";i:1776220130;}i:8;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.97;s:9:"timestamp";i:1776220140;}i:9;a:3:{s:5:"route";s:32:"programmatic.service-location.id";s:13:"response_time";d:18.42;s:9:"timestamp";i:1776220563;}i:10;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.97;s:9:"timestamp";i:1776220583;}i:11;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:4.77;s:9:"timestamp";i:1776220653;}i:12;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:13.31;s:9:"timestamp";i:1776220697;}i:13;a:3:{s:5:"route";s:16:"services.show.en";s:13:"response_time";d:10.6;s:9:"timestamp";i:1776220761;}i:14;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:6.86;s:9:"timestamp";i:1776220795;}i:15;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:5.86;s:9:"timestamp";i:1776220841;}i:16;a:3:{s:5:"route";s:20:"programmatic.city.id";s:13:"response_time";d:6.87;s:9:"timestamp";i:1776220913;}i:17;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:7.29;s:9:"timestamp";i:1776221292;}i:18;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.8;s:9:"timestamp";i:1776221297;}i:19;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.55;s:9:"timestamp";i:1776221394;}i:20;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:16.57;s:9:"timestamp";i:1776221444;}i:21;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:5.39;s:9:"timestamp";i:1776221445;}i:22;a:3:{s:5:"route";s:16:"blog.category.id";s:13:"response_time";d:9.47;s:9:"timestamp";i:1776221559;}i:23;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:4.57;s:9:"timestamp";i:1776221740;}i:24;a:3:{s:5:"route";s:20:"programmatic.city.id";s:13:"response_time";d:4.31;s:9:"timestamp";i:1776221755;}i:25;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:8.56;s:9:"timestamp";i:1776221903;}}	1776308303
bizmark-administration-cache-neural_metrics:2026-04-15-10	a:34:{i:0;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:5.5;s:9:"timestamp";i:1776222079;}i:1;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:4.33;s:9:"timestamp";i:1776222148;}i:2;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:3.59;s:9:"timestamp";i:1776222185;}i:3;a:3:{s:5:"route";s:32:"programmatic.service-location.id";s:13:"response_time";d:12.37;s:9:"timestamp";i:1776222260;}i:4;a:3:{s:5:"route";s:32:"programmatic.service-location.id";s:13:"response_time";d:4.68;s:9:"timestamp";i:1776222295;}i:5;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:6.21;s:9:"timestamp";i:1776222473;}i:6;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:5.29;s:9:"timestamp";i:1776222476;}i:7;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:14.48;s:9:"timestamp";i:1776222956;}i:8;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.83;s:9:"timestamp";i:1776222994;}i:9;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:5.07;s:9:"timestamp";i:1776223015;}i:10;a:3:{s:5:"route";s:13:"blog.index.id";s:13:"response_time";d:10.91;s:9:"timestamp";i:1776223029;}i:11;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:8.22;s:9:"timestamp";i:1776223089;}i:12;a:3:{s:5:"route";s:11:"blog.tag.en";s:13:"response_time";d:6.04;s:9:"timestamp";i:1776223121;}i:13;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:4.16;s:9:"timestamp";i:1776223257;}i:14;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:6.28;s:9:"timestamp";i:1776223682;}i:15;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.9;s:9:"timestamp";i:1776223720;}i:16;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:10.62;s:9:"timestamp";i:1776223759;}i:17;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.34;s:9:"timestamp";i:1776223770;}i:18;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:5.41;s:9:"timestamp";i:1776223882;}i:19;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.37;s:9:"timestamp";i:1776223985;}i:20;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.44;s:9:"timestamp";i:1776224150;}i:21;a:3:{s:5:"route";s:20:"programmatic.city.id";s:13:"response_time";d:4.89;s:9:"timestamp";i:1776224154;}i:22;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:10.24;s:9:"timestamp";i:1776224222;}i:23;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.46;s:9:"timestamp";i:1776224231;}i:24;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:5.91;s:9:"timestamp";i:1776224242;}i:25;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.79;s:9:"timestamp";i:1776224257;}i:26;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:7.08;s:9:"timestamp";i:1776224478;}i:27;a:3:{s:5:"route";s:20:"programmatic.city.id";s:13:"response_time";d:5.49;s:9:"timestamp";i:1776224480;}i:28;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:17.22;s:9:"timestamp";i:1776225019;}i:29;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:5.03;s:9:"timestamp";i:1776225019;}i:30;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.57;s:9:"timestamp";i:1776225236;}i:31;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:5.29;s:9:"timestamp";i:1776225325;}i:32;a:3:{s:5:"route";s:11:"blog.tag.en";s:13:"response_time";d:7.21;s:9:"timestamp";i:1776225359;}i:33;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:6.59;s:9:"timestamp";i:1776225553;}}	1776311953
bizmark-administration-cache-pseo.articles.izin-k3.balikpapan	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776312356
bizmark-administration-cache-pseo.articles.pbg-slf.bekasi	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776308660
bizmark-administration-cache-landing.latest_articles.id	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjE4OiJBcHBcTW9kZWxzXEFydGljbGUiOjM1OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjg6ImFydGljbGVzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MjM6e3M6MjoiaWQiO2k6NTtzOjU6InRpdGxlIjtzOjc5OiJQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkgUmFpaCBQZW5naGFyZ2FhbiBCZXN0IEVudmlyb25tZW50YWwgQ29uc3VsdGFudCAyMDI0IjtzOjQ6InNsdWciO3M6Nzk6InB0LWNhbmdhaC1wYWphcmF0YW4tbWFuZGlyaS1yYWloLXBlbmdoYXJnYWFuLWJlc3QtZW52aXJvbm1lbnRhbC1jb25zdWx0YW50LTIwMjQiO3M6NzoiZXhjZXJwdCI7czoxMzM6IkthbWkgZGVuZ2FuIGJhbmdnYSBtZW5ndW11bWthbiBiYWh3YSBQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkgdGVsYWggbWVyYWloIHBlbmdoYXJnYWFuIHNlYmFnYWkgQmVzdCBFbnZpcm9ubWVudGFsIENvbnN1bHRhbnQgMjAyNC4iO3M6NzoiY29udGVudCI7czoxMjE4OiI8aDI+UGVuZ2hhcmdhYW4gQmVyZ2VuZ3NpPC9oMj4KICAgICAgICAgICAgICAgIDxwPlBUIENBTkdBSCBQQUpBUkFUQU4gTUFORElSSSBkZW5nYW4gYmFuZ2dhIG1lbmd1bXVta2FuIHRlbGFoIG1lcmFpaCBwZW5naGFyZ2FhbiBzZWJhZ2FpIEJlc3QgRW52aXJvbm1lbnRhbCBDb25zdWx0YW50IDIwMjQgZGFyaSBBc29zaWFzaSBLb25zdWx0YW4gTGluZ2t1bmdhbiBJbmRvbmVzaWEuPC9wPgogICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8aDI+S3JpdGVyaWEgUGVuaWxhaWFuPC9oMj4KICAgICAgICAgICAgICAgIDxwPlBlbmdoYXJnYWFuIGluaSBkaWJlcmlrYW4gYmVyZGFzYXJrYW4gYmViZXJhcGEga3JpdGVyaWE6PC9wPgogICAgICAgICAgICAgICAgPHVsPgogICAgICAgICAgICAgICAgICAgIDxsaT5KdW1sYWggcHJveWVrIHlhbmcgYmVyaGFzaWwgZGlzZWxlc2Fpa2FuPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+VGluZ2thdCBrZXB1YXNhbiBrbGllbjwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPklub3Zhc2kgZGFsYW0gbGF5YW5hbiBrb25zdWx0YXNpPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+S29udHJpYnVzaSB0ZXJoYWRhcCBwZWxlc3RhcmlhbiBsaW5na3VuZ2FuPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+UHJvZmVzaW9uYWxpc21lIGRhbiBpbnRlZ3JpdGFzPC9saT4KICAgICAgICAgICAgICAgIDwvdWw+CiAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgIDxoMj5Lb21pdG1lbiBLYW1pPC9oMj4KICAgICAgICAgICAgICAgIDxwPlBlbmdoYXJnYWFuIGluaSBtZW5qYWRpIG1vdGl2YXNpIGJhZ2kga2FtaSB1bnR1ayB0ZXJ1cyBtZW1iZXJpa2FuIGxheWFuYW4gdGVyYmFpayBrZXBhZGEga2xpZW4uIEthbWkgYWthbiB0ZXJ1cyBiZXJpbm92YXNpIGRhbiBtZW5pbmdrYXRrYW4ga3VhbGl0YXMgbGF5YW5hbiBrYW1pLjwvcD4KICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgPGgyPlRlcmltYSBLYXNpaDwvaDI+CiAgICAgICAgICAgICAgICA8cD5LYW1pIG1lbmd1Y2Fwa2FuIHRlcmltYSBrYXNpaCBrZXBhZGEgc2VsdXJ1aCBrbGllbiB5YW5nIHRlbGFoIG1lbXBlcmNheWFrYW4ga2VidXR1aGFuIGtvbnN1bHRhc2kgbGluZ2t1bmdhbiBtZXJla2Ega2VwYWRhIGthbWkuIEtlcGVyY2F5YWFuIEFuZGEgYWRhbGFoIGFzZXQgYmVyaGFyZ2EgYmFnaSBrYW1pLjwvcD4iO3M6MTQ6ImZlYXR1cmVkX2ltYWdlIjtOO3M6ODoiY2F0ZWdvcnkiO3M6NDoibmV3cyI7czo0OiJ0YWdzIjtzOjM4OiJbImJlcml0YSIsInBlbmdoYXJnYWFuIiwiYWNoaWV2ZW1lbnQiXSI7czo2OiJzdGF0dXMiO3M6OToicHVibGlzaGVkIjtzOjEyOiJwdWJsaXNoZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTQgMTI6MDQ6NDQiO3M6MTE6InZpZXdzX2NvdW50IjtpOjA7czo5OiJhdXRob3JfaWQiO2k6MjtzOjEwOiJtZXRhX3RpdGxlIjtzOjY3OiJQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkgUmFpaCBCZXN0IEVudmlyb25tZW50YWwgQ29uc3VsdGFudCAyMDI0IjtzOjE2OiJtZXRhX2Rlc2NyaXB0aW9uIjtzOjEyNzoiUFQgQ0FOR0FIIFBBSkFSQVRBTiBNQU5ESVJJIG1lcmFpaCBwZW5naGFyZ2FhbiBCZXN0IEVudmlyb25tZW50YWwgQ29uc3VsdGFudCAyMDI0IGRhcmkgQXNvc2lhc2kgS29uc3VsdGFuIExpbmdrdW5nYW4gSW5kb25lc2lhLiI7czoxMzoibWV0YV9rZXl3b3JkcyI7czo1NDoicGVuZ2hhcmdhYW4sIGtvbnN1bHRhbiBsaW5na3VuZ2FuLCBiZXJpdGEsIGFjaGlldmVtZW50IjtzOjExOiJpc19mZWF0dXJlZCI7YjowO3M6MTI6InJlYWRpbmdfdGltZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6ImRlbGV0ZWRfYXQiO047czoxMToic291cmNlX3R5cGUiO3M6NjoibWFudWFsIjtzOjg6Imxhbmd1YWdlIjtzOjI6ImlkIjtzOjE2OiJ0b3BpY19jbHVzdGVyX2lkIjtOO31zOjExOiIAKgBvcmlnaW5hbCI7YToyMzp7czoyOiJpZCI7aTo1O3M6NToidGl0bGUiO3M6Nzk6IlBUIENBTkdBSCBQQUpBUkFUQU4gTUFORElSSSBSYWloIFBlbmdoYXJnYWFuIEJlc3QgRW52aXJvbm1lbnRhbCBDb25zdWx0YW50IDIwMjQiO3M6NDoic2x1ZyI7czo3OToicHQtY2FuZ2FoLXBhamFyYXRhbi1tYW5kaXJpLXJhaWgtcGVuZ2hhcmdhYW4tYmVzdC1lbnZpcm9ubWVudGFsLWNvbnN1bHRhbnQtMjAyNCI7czo3OiJleGNlcnB0IjtzOjEzMzoiS2FtaSBkZW5nYW4gYmFuZ2dhIG1lbmd1bXVta2FuIGJhaHdhIFBUIENBTkdBSCBQQUpBUkFUQU4gTUFORElSSSB0ZWxhaCBtZXJhaWggcGVuZ2hhcmdhYW4gc2ViYWdhaSBCZXN0IEVudmlyb25tZW50YWwgQ29uc3VsdGFudCAyMDI0LiI7czo3OiJjb250ZW50IjtzOjEyMTg6IjxoMj5QZW5naGFyZ2FhbiBCZXJnZW5nc2k8L2gyPgogICAgICAgICAgICAgICAgPHA+UFQgQ0FOR0FIIFBBSkFSQVRBTiBNQU5ESVJJIGRlbmdhbiBiYW5nZ2EgbWVuZ3VtdW1rYW4gdGVsYWggbWVyYWloIHBlbmdoYXJnYWFuIHNlYmFnYWkgQmVzdCBFbnZpcm9ubWVudGFsIENvbnN1bHRhbnQgMjAyNCBkYXJpIEFzb3NpYXNpIEtvbnN1bHRhbiBMaW5na3VuZ2FuIEluZG9uZXNpYS48L3A+CiAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgIDxoMj5Lcml0ZXJpYSBQZW5pbGFpYW48L2gyPgogICAgICAgICAgICAgICAgPHA+UGVuZ2hhcmdhYW4gaW5pIGRpYmVyaWthbiBiZXJkYXNhcmthbiBiZWJlcmFwYSBrcml0ZXJpYTo8L3A+CiAgICAgICAgICAgICAgICA8dWw+CiAgICAgICAgICAgICAgICAgICAgPGxpPkp1bWxhaCBwcm95ZWsgeWFuZyBiZXJoYXNpbCBkaXNlbGVzYWlrYW48L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5UaW5na2F0IGtlcHVhc2FuIGtsaWVuPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+SW5vdmFzaSBkYWxhbSBsYXlhbmFuIGtvbnN1bHRhc2k8L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5Lb250cmlidXNpIHRlcmhhZGFwIHBlbGVzdGFyaWFuIGxpbmdrdW5nYW48L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5Qcm9mZXNpb25hbGlzbWUgZGFuIGludGVncml0YXM8L2xpPgogICAgICAgICAgICAgICAgPC91bD4KICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgPGgyPktvbWl0bWVuIEthbWk8L2gyPgogICAgICAgICAgICAgICAgPHA+UGVuZ2hhcmdhYW4gaW5pIG1lbmphZGkgbW90aXZhc2kgYmFnaSBrYW1pIHVudHVrIHRlcnVzIG1lbWJlcmlrYW4gbGF5YW5hbiB0ZXJiYWlrIGtlcGFkYSBrbGllbi4gS2FtaSBha2FuIHRlcnVzIGJlcmlub3Zhc2kgZGFuIG1lbmluZ2thdGthbiBrdWFsaXRhcyBsYXlhbmFuIGthbWkuPC9wPgogICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8aDI+VGVyaW1hIEthc2loPC9oMj4KICAgICAgICAgICAgICAgIDxwPkthbWkgbWVuZ3VjYXBrYW4gdGVyaW1hIGthc2loIGtlcGFkYSBzZWx1cnVoIGtsaWVuIHlhbmcgdGVsYWggbWVtcGVyY2F5YWthbiBrZWJ1dHVoYW4ga29uc3VsdGFzaSBsaW5na3VuZ2FuIG1lcmVrYSBrZXBhZGEga2FtaS4gS2VwZXJjYXlhYW4gQW5kYSBhZGFsYWggYXNldCBiZXJoYXJnYSBiYWdpIGthbWkuPC9wPiI7czoxNDoiZmVhdHVyZWRfaW1hZ2UiO047czo4OiJjYXRlZ29yeSI7czo0OiJuZXdzIjtzOjQ6InRhZ3MiO3M6Mzg6IlsiYmVyaXRhIiwicGVuZ2hhcmdhYW4iLCJhY2hpZXZlbWVudCJdIjtzOjY6InN0YXR1cyI7czo5OiJwdWJsaXNoZWQiO3M6MTI6InB1Ymxpc2hlZF9hdCI7czoxOToiMjAyNi0wNC0xNCAxMjowNDo0NCI7czoxMToidmlld3NfY291bnQiO2k6MDtzOjk6ImF1dGhvcl9pZCI7aToyO3M6MTA6Im1ldGFfdGl0bGUiO3M6Njc6IlBUIENBTkdBSCBQQUpBUkFUQU4gTUFORElSSSBSYWloIEJlc3QgRW52aXJvbm1lbnRhbCBDb25zdWx0YW50IDIwMjQiO3M6MTY6Im1ldGFfZGVzY3JpcHRpb24iO3M6MTI3OiJQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkgbWVyYWloIHBlbmdoYXJnYWFuIEJlc3QgRW52aXJvbm1lbnRhbCBDb25zdWx0YW50IDIwMjQgZGFyaSBBc29zaWFzaSBLb25zdWx0YW4gTGluZ2t1bmdhbiBJbmRvbmVzaWEuIjtzOjEzOiJtZXRhX2tleXdvcmRzIjtzOjU0OiJwZW5naGFyZ2Fhbiwga29uc3VsdGFuIGxpbmdrdW5nYW4sIGJlcml0YSwgYWNoaWV2ZW1lbnQiO3M6MTE6ImlzX2ZlYXR1cmVkIjtiOjA7czoxMjoicmVhZGluZ190aW1lIjtpOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNC0xNSAxMjowNDo0NCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNC0xNSAxMjowNDo0NCI7czoxMDoiZGVsZXRlZF9hdCI7TjtzOjExOiJzb3VyY2VfdHlwZSI7czo2OiJtYW51YWwiO3M6ODoibGFuZ3VhZ2UiO3M6MjoiaWQiO3M6MTY6InRvcGljX2NsdXN0ZXJfaWQiO047fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjQ6e3M6NDoidGFncyI7czo1OiJhcnJheSI7czoxMjoicHVibGlzaGVkX2F0IjtzOjg6ImRhdGV0aW1lIjtzOjExOiJpc19mZWF0dXJlZCI7czo3OiJib29sZWFuIjtzOjEwOiJkZWxldGVkX2F0IjtzOjg6ImRhdGV0aW1lIjt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MTk6e2k6MDtzOjU6InRpdGxlIjtpOjE7czo0OiJzbHVnIjtpOjI7czo3OiJleGNlcnB0IjtpOjM7czo3OiJjb250ZW50IjtpOjQ7czoxNDoiZmVhdHVyZWRfaW1hZ2UiO2k6NTtzOjg6ImNhdGVnb3J5IjtpOjY7czo4OiJsYW5ndWFnZSI7aTo3O3M6NDoidGFncyI7aTo4O3M6Njoic3RhdHVzIjtpOjk7czoxMjoicHVibGlzaGVkX2F0IjtpOjEwO3M6MTE6InZpZXdzX2NvdW50IjtpOjExO3M6OToiYXV0aG9yX2lkIjtpOjEyO3M6MTE6InNvdXJjZV90eXBlIjtpOjEzO3M6MTY6InRvcGljX2NsdXN0ZXJfaWQiO2k6MTQ7czoxMDoibWV0YV90aXRsZSI7aToxNTtzOjE2OiJtZXRhX2Rlc2NyaXB0aW9uIjtpOjE2O3M6MTM6Im1ldGFfa2V5d29yZHMiO2k6MTc7czoxMToiaXNfZmVhdHVyZWQiO2k6MTg7czoxMjoicmVhZGluZ190aW1lIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9czo4OiIAKgBkYXRlcyI7YToyOntpOjA7czoxMjoicHVibGlzaGVkX2F0IjtpOjE7czoxMDoiZGVsZXRlZF9hdCI7fXM6MTY6IgAqAGZvcmNlRGVsZXRpbmciO2I6MDt9aToxO086MTg6IkFwcFxNb2RlbHNcQXJ0aWNsZSI6MzU6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6ODoiYXJ0aWNsZXMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToyMzp7czoyOiJpZCI7aTo0O3M6NToidGl0bGUiO3M6NzA6IlN0dWRpIEthc3VzOiBQZW5ndXJ1c2FuIEl6aW4gTEIzIHVudHVrIEluZHVzdHJpIE1hbnVmYWt0dXIgZGkgS2FyYXdhbmciO3M6NDoic2x1ZyI7czo2OToic3R1ZGkta2FzdXMtcGVuZ3VydXNhbi1pemluLWxiMy11bnR1ay1pbmR1c3RyaS1tYW51ZmFrdHVyLWRpLWthcmF3YW5nIjtzOjc6ImV4Y2VycHQiO3M6MTA0OiJQZW5nYWxhbWFuIGthbWkgZGFsYW0gbWVtYmFudHUgcGVydXNhaGFhbiBtYW51ZmFrdHVyIGRpIEthcmF3YW5nIG1lbmRhcGF0a2FuIGl6aW4gcGVuZ2Vsb2xhYW4gbGltYmFoIEIzLiI7czo3OiJjb250ZW50IjtzOjE0MjY6IjxoMj5MYXRhciBCZWxha2FuZyBQcm95ZWs8L2gyPgogICAgICAgICAgICAgICAgPHA+U2VidWFoIHBlcnVzYWhhYW4gbWFudWZha3R1ciBlbGVrdHJvbmlrIGRpIEthcmF3YW5nIG1lbWJ1dHVoa2FuIGl6aW4gcGVuZ2Vsb2xhYW4gbGltYmFoIEIzIHVudHVrIG9wZXJhc2lvbmFsIHBhYnJpayBiYXJ1bnlhLiBQZXJ1c2FoYWFuIGluaSBtZW5naGFzaWxrYW4gbGltYmFoIEIzIGJlcnVwYSBzb2xkZXIgd2FzdGUsIGNoZW1pY2FsIHdhc3RlLCBkYW4gb2lsIHdhc3RlLjwvcD4KICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgPGgyPlRhbnRhbmdhbiB5YW5nIERpaGFkYXBpPC9oMj4KICAgICAgICAgICAgICAgIDx1bD4KICAgICAgICAgICAgICAgICAgICA8bGk+RGVhZGxpbmUga2V0YXQgZGFyaSBpbnZlc3RvcjwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPktvbXBsZWtzaXRhcyBqZW5pcyBsaW1iYWggQjMgeWFuZyBkaWhhc2lsa2FuPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+S29vcmRpbmFzaSBkZW5nYW4gYmVyYmFnYWkgaW5zdGFuc2kgcGVtZXJpbnRhaDwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPlBlbnlpYXBhbiBmYXNpbGl0YXMgVFBTIGxpbWJhaCBCMzwvbGk+CiAgICAgICAgICAgICAgICA8L3VsPgogICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8aDI+U29sdXNpIHlhbmcgS2FtaSBCZXJpa2FuPC9oMj4KICAgICAgICAgICAgICAgIDxwPlRpbSBQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkgbWVsYWt1a2FuIHBlbmRla2F0YW4ga29tcHJlaGVuc2lmOjwvcD4KICAgICAgICAgICAgICAgIDxvbD4KICAgICAgICAgICAgICAgICAgICA8bGk+U3VydmV5IGxhcGFuZ2FuIGRhbiBhbmFsaXNpcyBqZW5pcyBsaW1iYWg8L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5QZW55dXN1bmFuIGRva3VtZW4gdGVrbmlzIGRhbiBhZG1pbmlzdHJhdGlmPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+S29uc3VsdGFzaSBkZW5nYW4gRExISyBKYXdhIEJhcmF0PC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+UGVuZGFtcGluZ2FuIHZlcmlmaWthc2kgbGFwYW5nYW48L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5GaW5hbGlzYXNpIGRhbiBwZW5lcmJpdGFuIGl6aW48L2xpPgogICAgICAgICAgICAgICAgPC9vbD4KICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgPGgyPkhhc2lsPC9oMj4KICAgICAgICAgICAgICAgIDxwPkl6aW4gYmVyaGFzaWwgdGVyYml0IGRhbGFtIHdha3R1IDQ1IGhhcmkga2VyamEsIGxlYmloIGNlcGF0IGRhcmkgZXN0aW1hc2kgYXdhbCA2MCBoYXJpLiBLbGllbiBzYW5nYXQgcHVhcyBkZW5nYW4gbGF5YW5hbiBrYW1pIGRhbiBvcGVyYXNpb25hbCBwYWJyaWsgZGFwYXQgZGltdWxhaSBzZXN1YWkgamFkd2FsLjwvcD4iO3M6MTQ6ImZlYXR1cmVkX2ltYWdlIjtOO3M6ODoiY2F0ZWdvcnkiO3M6MTA6ImNhc2Utc3R1ZHkiO3M6NDoidGFncyI7czo0NToiWyJzdHVkaSBrYXN1cyIsImxiMyIsImthcmF3YW5nIiwibWFudWZha3R1ciJdIjtzOjY6InN0YXR1cyI7czo5OiJwdWJsaXNoZWQiO3M6MTI6InB1Ymxpc2hlZF9hdCI7czoxOToiMjAyNi0wNC0xMiAxMjowNDo0NCI7czoxMToidmlld3NfY291bnQiO2k6MDtzOjk6ImF1dGhvcl9pZCI7aToyO3M6MTA6Im1ldGFfdGl0bGUiO3M6NjA6IlN0dWRpIEthc3VzIFBlbmd1cnVzYW4gSXppbiBMQjMgSW5kdXN0cmkgTWFudWZha3R1ciBLYXJhd2FuZyI7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7czoxMTA6IlN0dWRpIGthc3VzIHN1a3NlcyBwZW5ndXJ1c2FuIGl6aW4gTEIzIHVudHVrIGluZHVzdHJpIG1hbnVmYWt0dXIgZGkgS2FyYXdhbmcgb2xlaCBQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkuIjtzOjEzOiJtZXRhX2tleXdvcmRzIjtzOjU4OiJzdHVkaSBrYXN1cywgbGIzLCBrYXJhd2FuZywgaW5kdXN0cmkgbWFudWZha3R1ciwgcGVyaXppbmFuIjtzOjExOiJpc19mZWF0dXJlZCI7YjoxO3M6MTI6InJlYWRpbmdfdGltZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6ImRlbGV0ZWRfYXQiO047czoxMToic291cmNlX3R5cGUiO3M6NjoibWFudWFsIjtzOjg6Imxhbmd1YWdlIjtzOjI6ImlkIjtzOjE2OiJ0b3BpY19jbHVzdGVyX2lkIjtOO31zOjExOiIAKgBvcmlnaW5hbCI7YToyMzp7czoyOiJpZCI7aTo0O3M6NToidGl0bGUiO3M6NzA6IlN0dWRpIEthc3VzOiBQZW5ndXJ1c2FuIEl6aW4gTEIzIHVudHVrIEluZHVzdHJpIE1hbnVmYWt0dXIgZGkgS2FyYXdhbmciO3M6NDoic2x1ZyI7czo2OToic3R1ZGkta2FzdXMtcGVuZ3VydXNhbi1pemluLWxiMy11bnR1ay1pbmR1c3RyaS1tYW51ZmFrdHVyLWRpLWthcmF3YW5nIjtzOjc6ImV4Y2VycHQiO3M6MTA0OiJQZW5nYWxhbWFuIGthbWkgZGFsYW0gbWVtYmFudHUgcGVydXNhaGFhbiBtYW51ZmFrdHVyIGRpIEthcmF3YW5nIG1lbmRhcGF0a2FuIGl6aW4gcGVuZ2Vsb2xhYW4gbGltYmFoIEIzLiI7czo3OiJjb250ZW50IjtzOjE0MjY6IjxoMj5MYXRhciBCZWxha2FuZyBQcm95ZWs8L2gyPgogICAgICAgICAgICAgICAgPHA+U2VidWFoIHBlcnVzYWhhYW4gbWFudWZha3R1ciBlbGVrdHJvbmlrIGRpIEthcmF3YW5nIG1lbWJ1dHVoa2FuIGl6aW4gcGVuZ2Vsb2xhYW4gbGltYmFoIEIzIHVudHVrIG9wZXJhc2lvbmFsIHBhYnJpayBiYXJ1bnlhLiBQZXJ1c2FoYWFuIGluaSBtZW5naGFzaWxrYW4gbGltYmFoIEIzIGJlcnVwYSBzb2xkZXIgd2FzdGUsIGNoZW1pY2FsIHdhc3RlLCBkYW4gb2lsIHdhc3RlLjwvcD4KICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgPGgyPlRhbnRhbmdhbiB5YW5nIERpaGFkYXBpPC9oMj4KICAgICAgICAgICAgICAgIDx1bD4KICAgICAgICAgICAgICAgICAgICA8bGk+RGVhZGxpbmUga2V0YXQgZGFyaSBpbnZlc3RvcjwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPktvbXBsZWtzaXRhcyBqZW5pcyBsaW1iYWggQjMgeWFuZyBkaWhhc2lsa2FuPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+S29vcmRpbmFzaSBkZW5nYW4gYmVyYmFnYWkgaW5zdGFuc2kgcGVtZXJpbnRhaDwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPlBlbnlpYXBhbiBmYXNpbGl0YXMgVFBTIGxpbWJhaCBCMzwvbGk+CiAgICAgICAgICAgICAgICA8L3VsPgogICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8aDI+U29sdXNpIHlhbmcgS2FtaSBCZXJpa2FuPC9oMj4KICAgICAgICAgICAgICAgIDxwPlRpbSBQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkgbWVsYWt1a2FuIHBlbmRla2F0YW4ga29tcHJlaGVuc2lmOjwvcD4KICAgICAgICAgICAgICAgIDxvbD4KICAgICAgICAgICAgICAgICAgICA8bGk+U3VydmV5IGxhcGFuZ2FuIGRhbiBhbmFsaXNpcyBqZW5pcyBsaW1iYWg8L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5QZW55dXN1bmFuIGRva3VtZW4gdGVrbmlzIGRhbiBhZG1pbmlzdHJhdGlmPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+S29uc3VsdGFzaSBkZW5nYW4gRExISyBKYXdhIEJhcmF0PC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+UGVuZGFtcGluZ2FuIHZlcmlmaWthc2kgbGFwYW5nYW48L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5GaW5hbGlzYXNpIGRhbiBwZW5lcmJpdGFuIGl6aW48L2xpPgogICAgICAgICAgICAgICAgPC9vbD4KICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgPGgyPkhhc2lsPC9oMj4KICAgICAgICAgICAgICAgIDxwPkl6aW4gYmVyaGFzaWwgdGVyYml0IGRhbGFtIHdha3R1IDQ1IGhhcmkga2VyamEsIGxlYmloIGNlcGF0IGRhcmkgZXN0aW1hc2kgYXdhbCA2MCBoYXJpLiBLbGllbiBzYW5nYXQgcHVhcyBkZW5nYW4gbGF5YW5hbiBrYW1pIGRhbiBvcGVyYXNpb25hbCBwYWJyaWsgZGFwYXQgZGltdWxhaSBzZXN1YWkgamFkd2FsLjwvcD4iO3M6MTQ6ImZlYXR1cmVkX2ltYWdlIjtOO3M6ODoiY2F0ZWdvcnkiO3M6MTA6ImNhc2Utc3R1ZHkiO3M6NDoidGFncyI7czo0NToiWyJzdHVkaSBrYXN1cyIsImxiMyIsImthcmF3YW5nIiwibWFudWZha3R1ciJdIjtzOjY6InN0YXR1cyI7czo5OiJwdWJsaXNoZWQiO3M6MTI6InB1Ymxpc2hlZF9hdCI7czoxOToiMjAyNi0wNC0xMiAxMjowNDo0NCI7czoxMToidmlld3NfY291bnQiO2k6MDtzOjk6ImF1dGhvcl9pZCI7aToyO3M6MTA6Im1ldGFfdGl0bGUiO3M6NjA6IlN0dWRpIEthc3VzIFBlbmd1cnVzYW4gSXppbiBMQjMgSW5kdXN0cmkgTWFudWZha3R1ciBLYXJhd2FuZyI7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7czoxMTA6IlN0dWRpIGthc3VzIHN1a3NlcyBwZW5ndXJ1c2FuIGl6aW4gTEIzIHVudHVrIGluZHVzdHJpIG1hbnVmYWt0dXIgZGkgS2FyYXdhbmcgb2xlaCBQVCBDQU5HQUggUEFKQVJBVEFOIE1BTkRJUkkuIjtzOjEzOiJtZXRhX2tleXdvcmRzIjtzOjU4OiJzdHVkaSBrYXN1cywgbGIzLCBrYXJhd2FuZywgaW5kdXN0cmkgbWFudWZha3R1ciwgcGVyaXppbmFuIjtzOjExOiJpc19mZWF0dXJlZCI7YjoxO3M6MTI6InJlYWRpbmdfdGltZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6ImRlbGV0ZWRfYXQiO047czoxMToic291cmNlX3R5cGUiO3M6NjoibWFudWFsIjtzOjg6Imxhbmd1YWdlIjtzOjI6ImlkIjtzOjE2OiJ0b3BpY19jbHVzdGVyX2lkIjtOO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTo0OntzOjQ6InRhZ3MiO3M6NToiYXJyYXkiO3M6MTI6InB1Ymxpc2hlZF9hdCI7czo4OiJkYXRldGltZSI7czoxMToiaXNfZmVhdHVyZWQiO3M6NzoiYm9vbGVhbiI7czoxMDoiZGVsZXRlZF9hdCI7czo4OiJkYXRldGltZSI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjE5OntpOjA7czo1OiJ0aXRsZSI7aToxO3M6NDoic2x1ZyI7aToyO3M6NzoiZXhjZXJwdCI7aTozO3M6NzoiY29udGVudCI7aTo0O3M6MTQ6ImZlYXR1cmVkX2ltYWdlIjtpOjU7czo4OiJjYXRlZ29yeSI7aTo2O3M6ODoibGFuZ3VhZ2UiO2k6NztzOjQ6InRhZ3MiO2k6ODtzOjY6InN0YXR1cyI7aTo5O3M6MTI6InB1Ymxpc2hlZF9hdCI7aToxMDtzOjExOiJ2aWV3c19jb3VudCI7aToxMTtzOjk6ImF1dGhvcl9pZCI7aToxMjtzOjExOiJzb3VyY2VfdHlwZSI7aToxMztzOjE2OiJ0b3BpY19jbHVzdGVyX2lkIjtpOjE0O3M6MTA6Im1ldGFfdGl0bGUiO2k6MTU7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7aToxNjtzOjEzOiJtZXRhX2tleXdvcmRzIjtpOjE3O3M6MTE6ImlzX2ZlYXR1cmVkIjtpOjE4O3M6MTI6InJlYWRpbmdfdGltZSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6ODoiACoAZGF0ZXMiO2E6Mjp7aTowO3M6MTI6InB1Ymxpc2hlZF9hdCI7aToxO3M6MTA6ImRlbGV0ZWRfYXQiO31zOjE2OiIAKgBmb3JjZURlbGV0aW5nIjtiOjA7fWk6MjtPOjE4OiJBcHBcTW9kZWxzXEFydGljbGUiOjM1OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjg6ImFydGljbGVzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MjM6e3M6MjoiaWQiO2k6MztzOjU6InRpdGxlIjtzOjc5OiJQZXJhdHVyYW4gVGVyYmFydTogUGVybWVuIExISyBOby4gNCBUYWh1biAyMDIxIHRlbnRhbmcgRGFmdGFyIFVzYWhhIFdhamliIEFNREFMIjtzOjQ6InNsdWciO3M6Nzc6InBlcmF0dXJhbi10ZXJiYXJ1LXBlcm1lbi1saGstbm8tNC10YWh1bi0yMDIxLXRlbnRhbmctZGFmdGFyLXVzYWhhLXdhamliLWFtZGFsIjtzOjc6ImV4Y2VycHQiO3M6MTA3OiJQZW1lcmludGFoIG1lbmVyYml0a2FuIHBlcmF0dXJhbiB0ZXJiYXJ1IG1lbmdlbmFpIGRhZnRhciB1c2FoYSBkYW4vYXRhdSBrZWdpYXRhbiB5YW5nIHdhamliIG1lbWlsaWtpIEFNREFMLiI7czo3OiJjb250ZW50IjtzOjg4ODoiPGgyPlBlcnViYWhhbiBTaWduaWZpa2FuPC9oMj4KICAgICAgICAgICAgICAgIDxwPlBlcm1lbiBMSEsgTm8uIDQgVGFodW4gMjAyMSBtZW5nZ2FudGlrYW4gUGVybWVuIExISyBOby4gUC4zOC9NZW5saGsvU2V0amVuL0t1bS4xLzcvMjAxOSB0ZW50YW5nIEplbmlzIFJlbmNhbmEgVXNhaGEgZGFuL2F0YXUgS2VnaWF0YW4geWFuZyBXYWppYiBNZW1pbGlraSBBTURBTC48L3A+CiAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgIDxoMj5Qb2luLVBvaW4gUGVudGluZzwvaDI+CiAgICAgICAgICAgICAgICA8dWw+CiAgICAgICAgICAgICAgICAgICAgPGxpPlBlbnllZGVyaGFuYWFuIGRhZnRhciB1c2FoYSB3YWppYiBBTURBTDwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPkludGVncmFzaSBkZW5nYW4gc2lzdGVtIE9TUyAoT25saW5lIFNpbmdsZSBTdWJtaXNzaW9uKTwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPlBlcmNlcGF0YW4gcHJvc2VzIHBlcml6aW5hbiBsaW5na3VuZ2FuPC9saT4KICAgICAgICAgICAgICAgICAgICA8bGk+UGVuZ3VhdGFuIHBlcmFuIGtvbnN1bHRhbiBsaW5na3VuZ2FuIGJlcnNlcnRpZmlrYXQ8L2xpPgogICAgICAgICAgICAgICAgPC91bD4KICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgPGgyPkRhbXBhayBiYWdpIEluZHVzdHJpPC9oMj4KICAgICAgICAgICAgICAgIDxwPlBlcmF0dXJhbiBpbmkgbWVtYmF3YSBkYW1wYWsgcG9zaXRpZiBiYWdpIGluZHVzdHJpIGRhbGFtIGhhbCBlZmlzaWVuc2kgd2FrdHUgZGFuIGJpYXlhIGRhbGFtIHBlbmd1cnVzYW4gaXppbiBsaW5na3VuZ2FuLiBOYW11biwgdGV0YXAgbWVtcGVyaGF0aWthbiBhc3BlayBwZXJsaW5kdW5nYW4gbGluZ2t1bmdhbiBoaWR1cC48L3A+IjtzOjE0OiJmZWF0dXJlZF9pbWFnZSI7TjtzOjg6ImNhdGVnb3J5IjtzOjEwOiJyZWd1bGF0aW9uIjtzOjQ6InRhZ3MiO3M6NDU6IlsicmVndWxhc2kiLCJhbWRhbCIsInBlcm1lbiBsaGsiLCJwZXJpemluYW4iXSI7czo2OiJzdGF0dXMiO3M6OToicHVibGlzaGVkIjtzOjEyOiJwdWJsaXNoZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTAgMTI6MDQ6NDQiO3M6MTE6InZpZXdzX2NvdW50IjtpOjA7czo5OiJhdXRob3JfaWQiO2k6MjtzOjEwOiJtZXRhX3RpdGxlIjtzOjYwOiJQZXJtZW4gTEhLIE5vLiA0IFRhaHVuIDIwMjEgdGVudGFuZyBEYWZ0YXIgVXNhaGEgV2FqaWIgQU1EQUwiO3M6MTY6Im1ldGFfZGVzY3JpcHRpb24iO3M6OTQ6IlBlbmplbGFzYW4gbGVuZ2thcCB0ZW50YW5nIFBlcm1lbiBMSEsgTm8uIDQgVGFodW4gMjAyMSB5YW5nIG1lbmdhdHVyIGRhZnRhciB1c2FoYSB3YWppYiBBTURBTC4iO3M6MTM6Im1ldGFfa2V5d29yZHMiO3M6NDk6InBlcm1lbiBsaGssIGFtZGFsLCByZWd1bGFzaSBsaW5na3VuZ2FuLCBwZXJpemluYW4iO3M6MTE6ImlzX2ZlYXR1cmVkIjtiOjA7czoxMjoicmVhZGluZ190aW1lIjtpOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNC0xNSAxMjowNDo0NCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNC0xNSAxMjowNDo0NCI7czoxMDoiZGVsZXRlZF9hdCI7TjtzOjExOiJzb3VyY2VfdHlwZSI7czo2OiJtYW51YWwiO3M6ODoibGFuZ3VhZ2UiO3M6MjoiaWQiO3M6MTY6InRvcGljX2NsdXN0ZXJfaWQiO047fXM6MTE6IgAqAG9yaWdpbmFsIjthOjIzOntzOjI6ImlkIjtpOjM7czo1OiJ0aXRsZSI7czo3OToiUGVyYXR1cmFuIFRlcmJhcnU6IFBlcm1lbiBMSEsgTm8uIDQgVGFodW4gMjAyMSB0ZW50YW5nIERhZnRhciBVc2FoYSBXYWppYiBBTURBTCI7czo0OiJzbHVnIjtzOjc3OiJwZXJhdHVyYW4tdGVyYmFydS1wZXJtZW4tbGhrLW5vLTQtdGFodW4tMjAyMS10ZW50YW5nLWRhZnRhci11c2FoYS13YWppYi1hbWRhbCI7czo3OiJleGNlcnB0IjtzOjEwNzoiUGVtZXJpbnRhaCBtZW5lcmJpdGthbiBwZXJhdHVyYW4gdGVyYmFydSBtZW5nZW5haSBkYWZ0YXIgdXNhaGEgZGFuL2F0YXUga2VnaWF0YW4geWFuZyB3YWppYiBtZW1pbGlraSBBTURBTC4iO3M6NzoiY29udGVudCI7czo4ODg6IjxoMj5QZXJ1YmFoYW4gU2lnbmlmaWthbjwvaDI+CiAgICAgICAgICAgICAgICA8cD5QZXJtZW4gTEhLIE5vLiA0IFRhaHVuIDIwMjEgbWVuZ2dhbnRpa2FuIFBlcm1lbiBMSEsgTm8uIFAuMzgvTWVubGhrL1NldGplbi9LdW0uMS83LzIwMTkgdGVudGFuZyBKZW5pcyBSZW5jYW5hIFVzYWhhIGRhbi9hdGF1IEtlZ2lhdGFuIHlhbmcgV2FqaWIgTWVtaWxpa2kgQU1EQUwuPC9wPgogICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8aDI+UG9pbi1Qb2luIFBlbnRpbmc8L2gyPgogICAgICAgICAgICAgICAgPHVsPgogICAgICAgICAgICAgICAgICAgIDxsaT5QZW55ZWRlcmhhbmFhbiBkYWZ0YXIgdXNhaGEgd2FqaWIgQU1EQUw8L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5JbnRlZ3Jhc2kgZGVuZ2FuIHNpc3RlbSBPU1MgKE9ubGluZSBTaW5nbGUgU3VibWlzc2lvbik8L2xpPgogICAgICAgICAgICAgICAgICAgIDxsaT5QZXJjZXBhdGFuIHByb3NlcyBwZXJpemluYW4gbGluZ2t1bmdhbjwvbGk+CiAgICAgICAgICAgICAgICAgICAgPGxpPlBlbmd1YXRhbiBwZXJhbiBrb25zdWx0YW4gbGluZ2t1bmdhbiBiZXJzZXJ0aWZpa2F0PC9saT4KICAgICAgICAgICAgICAgIDwvdWw+CiAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgIDxoMj5EYW1wYWsgYmFnaSBJbmR1c3RyaTwvaDI+CiAgICAgICAgICAgICAgICA8cD5QZXJhdHVyYW4gaW5pIG1lbWJhd2EgZGFtcGFrIHBvc2l0aWYgYmFnaSBpbmR1c3RyaSBkYWxhbSBoYWwgZWZpc2llbnNpIHdha3R1IGRhbiBiaWF5YSBkYWxhbSBwZW5ndXJ1c2FuIGl6aW4gbGluZ2t1bmdhbi4gTmFtdW4sIHRldGFwIG1lbXBlcmhhdGlrYW4gYXNwZWsgcGVybGluZHVuZ2FuIGxpbmdrdW5nYW4gaGlkdXAuPC9wPiI7czoxNDoiZmVhdHVyZWRfaW1hZ2UiO047czo4OiJjYXRlZ29yeSI7czoxMDoicmVndWxhdGlvbiI7czo0OiJ0YWdzIjtzOjQ1OiJbInJlZ3VsYXNpIiwiYW1kYWwiLCJwZXJtZW4gbGhrIiwicGVyaXppbmFuIl0iO3M6Njoic3RhdHVzIjtzOjk6InB1Ymxpc2hlZCI7czoxMjoicHVibGlzaGVkX2F0IjtzOjE5OiIyMDI2LTA0LTEwIDEyOjA0OjQ0IjtzOjExOiJ2aWV3c19jb3VudCI7aTowO3M6OToiYXV0aG9yX2lkIjtpOjI7czoxMDoibWV0YV90aXRsZSI7czo2MDoiUGVybWVuIExISyBOby4gNCBUYWh1biAyMDIxIHRlbnRhbmcgRGFmdGFyIFVzYWhhIFdhamliIEFNREFMIjtzOjE2OiJtZXRhX2Rlc2NyaXB0aW9uIjtzOjk0OiJQZW5qZWxhc2FuIGxlbmdrYXAgdGVudGFuZyBQZXJtZW4gTEhLIE5vLiA0IFRhaHVuIDIwMjEgeWFuZyBtZW5nYXR1ciBkYWZ0YXIgdXNhaGEgd2FqaWIgQU1EQUwuIjtzOjEzOiJtZXRhX2tleXdvcmRzIjtzOjQ5OiJwZXJtZW4gbGhrLCBhbWRhbCwgcmVndWxhc2kgbGluZ2t1bmdhbiwgcGVyaXppbmFuIjtzOjExOiJpc19mZWF0dXJlZCI7YjowO3M6MTI6InJlYWRpbmdfdGltZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDQtMTUgMTI6MDQ6NDQiO3M6MTA6ImRlbGV0ZWRfYXQiO047czoxMToic291cmNlX3R5cGUiO3M6NjoibWFudWFsIjtzOjg6Imxhbmd1YWdlIjtzOjI6ImlkIjtzOjE2OiJ0b3BpY19jbHVzdGVyX2lkIjtOO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTo0OntzOjQ6InRhZ3MiO3M6NToiYXJyYXkiO3M6MTI6InB1Ymxpc2hlZF9hdCI7czo4OiJkYXRldGltZSI7czoxMToiaXNfZmVhdHVyZWQiO3M6NzoiYm9vbGVhbiI7czoxMDoiZGVsZXRlZF9hdCI7czo4OiJkYXRldGltZSI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjE5OntpOjA7czo1OiJ0aXRsZSI7aToxO3M6NDoic2x1ZyI7aToyO3M6NzoiZXhjZXJwdCI7aTozO3M6NzoiY29udGVudCI7aTo0O3M6MTQ6ImZlYXR1cmVkX2ltYWdlIjtpOjU7czo4OiJjYXRlZ29yeSI7aTo2O3M6ODoibGFuZ3VhZ2UiO2k6NztzOjQ6InRhZ3MiO2k6ODtzOjY6InN0YXR1cyI7aTo5O3M6MTI6InB1Ymxpc2hlZF9hdCI7aToxMDtzOjExOiJ2aWV3c19jb3VudCI7aToxMTtzOjk6ImF1dGhvcl9pZCI7aToxMjtzOjExOiJzb3VyY2VfdHlwZSI7aToxMztzOjE2OiJ0b3BpY19jbHVzdGVyX2lkIjtpOjE0O3M6MTA6Im1ldGFfdGl0bGUiO2k6MTU7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7aToxNjtzOjEzOiJtZXRhX2tleXdvcmRzIjtpOjE3O3M6MTE6ImlzX2ZlYXR1cmVkIjtpOjE4O3M6MTI6InJlYWRpbmdfdGltZSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6ODoiACoAZGF0ZXMiO2E6Mjp7aTowO3M6MTI6InB1Ymxpc2hlZF9hdCI7aToxO3M6MTA6ImRlbGV0ZWRfYXQiO31zOjE2OiIAKgBmb3JjZURlbGV0aW5nIjtiOjA7fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1776230087
bizmark-administration-cache-neural_metrics:2026-04-15-12	a:14:{i:0;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:7.31;s:9:"timestamp";i:1776229410;}i:1;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:5.17;s:9:"timestamp";i:1776229439;}i:2;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:16;s:9:"timestamp";i:1776229487;}i:3;a:3:{s:5:"route";s:11:"admin.login";s:13:"response_time";d:1.57;s:9:"timestamp";i:1776229508;}i:4;a:3:{s:5:"route";N;s:13:"response_time";d:408.6;s:9:"timestamp";i:1776229513;}i:5;a:3:{s:5:"route";N;s:13:"response_time";d:0.89;s:9:"timestamp";i:1776229513;}i:6;a:3:{s:5:"route";s:9:"dashboard";s:13:"response_time";d:79.21;s:9:"timestamp";i:1776229513;}i:7;a:3:{s:5:"route";s:16:"api.screen-width";s:13:"response_time";d:2.49;s:9:"timestamp";i:1776229513;}i:8;a:3:{s:5:"route";s:14:"articles.index";s:13:"response_time";d:47.1;s:9:"timestamp";i:1776229517;}i:9;a:3:{s:5:"route";s:16:"api.screen-width";s:13:"response_time";d:2.25;s:9:"timestamp";i:1776229517;}i:10;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:7.92;s:9:"timestamp";i:1776229531;}i:11;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:14.54;s:9:"timestamp";i:1776229537;}i:12;a:3:{s:5:"route";s:32:"programmatic.service-location.id";s:13:"response_time";d:10.18;s:9:"timestamp";i:1776229559;}i:13;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:4.65;s:9:"timestamp";i:1776229644;}}	1776316044
bizmark-administration-cache-admin@bizmark.id|162.158.108.13:timer	i:1776228934;	1776228934
bizmark-administration-cache-admin@bizmark.id|162.158.108.13	i:1;	1776228934
bizmark-administration-cache-bb7f2d8edef7d5722294ebe3972dc600dd685699:timer	i:1776229572;	1776229572
bizmark-administration-cache-aa7a56f063e6229f446e53e362f4ab6d40146913:timer	i:1776228925;	1776228925
bizmark-administration-cache-bb7f2d8edef7d5722294ebe3972dc600dd685699	i:1;	1776229572
bizmark-administration-cache-hadez@bizmark.id|162.158.108.13:timer	i:1776228925;	1776228925
bizmark-administration-cache-aa7a56f063e6229f446e53e362f4ab6d40146913	i:3;	1776228925
bizmark-administration-cache-hadez@bizmark.id|162.158.108.13	i:2;	1776228925
bizmark-administration-cache-neural_metrics:2026-04-15-11	a:35:{i:0;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:6.24;s:9:"timestamp";i:1776225695;}i:1;a:3:{s:5:"route";s:32:"programmatic.service-location.id";s:13:"response_time";d:11.94;s:9:"timestamp";i:1776225956;}i:2;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:11.95;s:9:"timestamp";i:1776226516;}i:3;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:7.13;s:9:"timestamp";i:1776226748;}i:4;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:3.42;s:9:"timestamp";i:1776226796;}i:5;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:10.42;s:9:"timestamp";i:1776226842;}i:6;a:3:{s:5:"route";s:15:"blog.article.en";s:13:"response_time";d:4.23;s:9:"timestamp";i:1776226918;}i:7;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:3.51;s:9:"timestamp";i:1776227170;}i:8;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:5.52;s:9:"timestamp";i:1776227254;}i:9;a:3:{s:5:"route";s:16:"services.show.id";s:13:"response_time";d:6.42;s:9:"timestamp";i:1776227265;}i:10;a:3:{s:5:"route";s:16:"services.show.id";s:13:"response_time";d:3.07;s:9:"timestamp";i:1776227275;}i:11;a:3:{s:5:"route";s:16:"services.show.id";s:13:"response_time";d:2.43;s:9:"timestamp";i:1776227280;}i:12;a:3:{s:5:"route";s:16:"services.show.id";s:13:"response_time";d:1.78;s:9:"timestamp";i:1776227285;}i:13;a:3:{s:5:"route";s:15:"blog.article.id";s:13:"response_time";d:8.27;s:9:"timestamp";i:1776227383;}i:14;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:6.96;s:9:"timestamp";i:1776227435;}i:15;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:15.11;s:9:"timestamp";i:1776227855;}i:16;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:5.02;s:9:"timestamp";i:1776227891;}i:17;a:3:{s:5:"route";s:20:"programmatic.city.id";s:13:"response_time";d:4.78;s:9:"timestamp";i:1776227999;}i:18;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:6.55;s:9:"timestamp";i:1776228089;}i:19;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:7.97;s:9:"timestamp";i:1776228091;}i:20;a:3:{s:5:"route";s:16:"blog.category.en";s:13:"response_time";d:8.28;s:9:"timestamp";i:1776228181;}i:21;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:5.18;s:9:"timestamp";i:1776228388;}i:22;a:3:{s:5:"route";s:5:"login";s:13:"response_time";d:3.62;s:9:"timestamp";i:1776228422;}i:23;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:16.59;s:9:"timestamp";i:1776228790;}i:24;a:3:{s:5:"route";s:10:"landing.id";s:13:"response_time";d:6.08;s:9:"timestamp";i:1776228802;}i:25;a:3:{s:5:"route";s:16:"services.show.en";s:13:"response_time";d:6.01;s:9:"timestamp";i:1776228814;}i:26;a:3:{s:5:"route";s:11:"blog.tag.id";s:13:"response_time";d:5.1;s:9:"timestamp";i:1776228814;}i:27;a:3:{s:5:"route";s:13:"blog.index.id";s:13:"response_time";d:6.1;s:9:"timestamp";i:1776228824;}i:28;a:3:{s:5:"route";s:11:"admin.login";s:13:"response_time";d:2.78;s:9:"timestamp";i:1776228859;}i:29;a:3:{s:5:"route";N;s:13:"response_time";d:414.44;s:9:"timestamp";i:1776228865;}i:30;a:3:{s:5:"route";s:11:"admin.login";s:13:"response_time";d:1.75;s:9:"timestamp";i:1776228866;}i:31;a:3:{s:5:"route";N;s:13:"response_time";d:408.71;s:9:"timestamp";i:1776228874;}i:32;a:3:{s:5:"route";s:11:"admin.login";s:13:"response_time";d:1.36;s:9:"timestamp";i:1776228874;}i:33;a:3:{s:5:"route";N;s:13:"response_time";d:406.37;s:9:"timestamp";i:1776228879;}i:34;a:3:{s:5:"route";s:11:"admin.login";s:13:"response_time";d:1.03;s:9:"timestamp";i:1776228879;}}	1776315279
bizmark-administration-cache-dashboard_data_2	YToxMDp7czoxNDoiY3JpdGljYWxBbGVydHMiO2E6ODp7czoxNjoib3ZlcmR1ZV9wcm9qZWN0cyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6MjI6Im92ZXJkdWVfcHJvamVjdHNfY291bnQiO2k6MDtzOjEzOiJvdmVyZHVlX3Rhc2tzIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czoxOToib3ZlcmR1ZV90YXNrc19jb3VudCI7aTowO3M6OToiZHVlX3RvZGF5IjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czoxNToiZHVlX3RvZGF5X2NvdW50IjtpOjA7czoxMjoidG90YWxfdXJnZW50IjtpOjA7czoxOToiaGFzX2NyaXRpY2FsX2FsZXJ0cyI7YjowO31zOjE0OiJjYXNoRmxvd1N0YXR1cyI7YTo4OntzOjEzOiJ0b3RhbF9iYWxhbmNlIjtpOjA7czoxNDoiYXZhaWxhYmxlX2Nhc2giO2k6MDtzOjE1OiJjdXJyZW50X2JhbGFuY2UiO2k6MDtzOjE3OiJtb250aGx5X2J1cm5fcmF0ZSI7aTowO3M6MTM6InJ1bndheV9tb250aHMiO2Q6OTk7czoxNjoib3ZlcmR1ZV9pbnZvaWNlcyI7aTowO3M6Njoic3RhdHVzIjtzOjc6ImhlYWx0aHkiO3M6MTI6InN0YXR1c19jb2xvciI7czo3OiIjMzRDNzU5Ijt9czoxNjoicGVuZGluZ0FwcHJvdmFscyI7YTo1OntzOjE2OiJwZW5kaW5nX2ludm9pY2VzIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czoyMjoicGVuZGluZ19pbnZvaWNlc19jb3VudCI7aTowO3M6MTc6InBlbmRpbmdfZG9jdW1lbnRzIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czoyMzoicGVuZGluZ19kb2N1bWVudHNfY291bnQiO2k6MDtzOjEzOiJ0b3RhbF9wZW5kaW5nIjtpOjA7fXM6MTU6ImNhc2hGbG93U3VtbWFyeSI7YToxNzp7czoxODoidG90YWxfY2FzaF9iYWxhbmNlIjtpOjA7czoxNzoidGhpc19tb250aF9pbmNvbWUiO2k6MDtzOjE5OiJ0aGlzX21vbnRoX2V4cGVuc2VzIjtpOjA7czoxOToicGF5bWVudHNfdGhpc19tb250aCI7aTowO3M6MTk6ImV4cGVuc2VzX3RoaXNfbW9udGgiO2k6MDtzOjE0OiJuZXRfdGhpc19tb250aCI7aTowO3M6MTI6InBheW1lbnRzX3l0ZCI7aTowO3M6MTI6ImV4cGVuc2VzX3l0ZCI7aTowO3M6NzoibmV0X3l0ZCI7aTowO3M6MTk6InBheW1lbnRzX2xhc3RfbW9udGgiO2k6MDtzOjE5OiJleHBlbnNlc19sYXN0X21vbnRoIjtpOjA7czoxNDoibmV0X2xhc3RfbW9udGgiO2k6MDtzOjE1OiJwYXltZW50c19ncm93dGgiO2k6MDtzOjE1OiJleHBlbnNlc19ncm93dGgiO2k6MDtzOjEzOiJpc19wcm9maXRhYmxlIjtiOjA7czoxNDoidG90YWxfaW52b2ljZWQiO2k6MDtzOjE0OiJ0b3RhbF9yZWNlaXZlZCI7aTowO31zOjE2OiJyZWNlaXZhYmxlc0FnaW5nIjthOjg6e3M6NToiYWdpbmciO2E6NDp7czo4OiJ1bmRlcl8zMCI7aTowO3M6MTA6ImRheXNfMzBfNjAiO2k6MDtzOjEwOiJkYXlzXzYwXzkwIjtpOjA7czo3OiJvdmVyXzkwIjtpOjA7fXM6MTc6InRvdGFsX3JlY2VpdmFibGVzIjtpOjA7czoxOToiaW52b2ljZV9yZWNlaXZhYmxlcyI7aTowO3M6MjA6ImludGVybmFsX3JlY2VpdmFibGVzIjtpOjA7czoxNDoiaW50ZXJuYWxfYWdpbmciO2E6NDp7czo4OiJ1bmRlcl8zMCI7aTowO3M6MTA6ImRheXNfMzBfNjAiO2k6MDtzOjEwOiJkYXlzXzYwXzkwIjtpOjA7czo3OiJvdmVyXzkwIjtpOjA7fXM6MTM6Imludm9pY2VfY291bnQiO2k6MDtzOjE0OiJpbnRlcm5hbF9jb3VudCI7aTowO3M6MTM6ImludGVybmFsX2xpc3QiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMjoiYnVkZ2V0U3RhdHVzIjthOjQ6e3M6MTI6InRvcF9wcm9qZWN0cyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6MTI6InRvdGFsX2J1ZGdldCI7aTowO3M6MTE6InRvdGFsX3NwZW50IjtpOjA7czoxOToib3ZlcmFsbF91dGlsaXphdGlvbiI7aTowO31zOjg6InRoaXNXZWVrIjthOjU6e3M6NToidGFza3MiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjg6InByb2plY3RzIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czoxMjoicGVyaW9kX3N0YXJ0IjtzOjY6IjE1IEFwciI7czoxMDoicGVyaW9kX2VuZCI7czo2OiIxNSBNYXkiO3M6MTE6InRvdGFsX2l0ZW1zIjtpOjA7fXM6MjU6InByb2plY3RTdGF0dXNEaXN0cmlidXRpb24iO2E6Mjp7czo2OiJncm91cHMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjU6InRvdGFsIjtpOjA7fXM6MTY6InJlY2VudEFjdGl2aXRpZXMiO2E6Mjp7czoxMDoiYWN0aXZpdGllcyI7TzoyOToiSWxsdW1pbmF0ZVxTdXBwb3J0XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo1OiJjb3VudCI7aTowO31zOjEwOiJyYWdNZXRyaWNzIjthOjU6e3M6MTU6InRvdGFsX3Byb2Nlc3NlZCI7aTowO3M6MTQ6ImF2Z19jb25maWRlbmNlIjtkOjA7czoxNToiaGlnaF9jb25maWRlbmNlIjtpOjA7czoxNDoibG93X2NvbmZpZGVuY2UiO2k6MDtzOjY6InJlY2VudCI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX19	1776229813
bizmark-administration-cache-bizmark_nav_counts	a:8:{s:8:"projects";i:0;s:5:"tasks";i:0;s:13:"pending_tasks";i:0;s:9:"documents";i:0;s:12:"institutions";i:6;s:7:"clients";i:0;s:12:"permit_types";i:0;s:16:"permit_templates";i:0;}	1776229813
bizmark-administration-cache-bizmark_permit_notifications	a:5:{s:9:"submitted";i:0;s:12:"under_review";i:0;s:12:"unread_notes";i:0;s:16:"pending_payments";i:0;s:5:"total";i:0;}	1776229573
bizmark-administration-cache-bizmark_other_notifications	a:3:{s:16:"pending_job_apps";i:0;s:13:"unread_emails";i:0;s:23:"pending_reconciliations";i:0;}	1776229573
\.


--
-- TOC entry 5743 (class 0 OID 156924)
-- Dependencies: 224
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- TOC entry 5874 (class 0 OID 158582)
-- Dependencies: 355
-- Data for Name: cash_account_balance_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_account_balance_history (id, cash_account_id, old_balance, new_balance, change_amount, change_type, reference_id, reference_type, description, changed_by, changed_at) FROM stdin;
\.


--
-- TOC entry 5762 (class 0 OID 157142)
-- Dependencies: 243
-- Data for Name: cash_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_accounts (id, account_name, account_type, account_number, bank_name, account_holder, current_balance, initial_balance, is_active, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5788 (class 0 OID 157476)
-- Dependencies: 269
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, name, company_name, industry, contact_person, email, phone, mobile, address, city, province, postal_code, npwp, tax_name, tax_address, client_type, status, notes, created_at, updated_at, deleted_at, password, email_verified_at, remember_token, profile_picture) FROM stdin;
\.


--
-- TOC entry 5924 (class 0 OID 159188)
-- Dependencies: 405
-- Data for Name: competitor_analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.competitor_analyses (id, keyword, our_url, our_position, top_competitors, content_gaps, recommendations, search_volume, difficulty, analyzed_at, created_at, updated_at, data_source) FROM stdin;
\.


--
-- TOC entry 5820 (class 0 OID 157834)
-- Dependencies: 301
-- Data for Name: compliance_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_checks (id, draft_id, document_type, overall_score, structure_score, compliance_score, formatting_score, completeness_score, issues, status, error_message, total_issues, critical_issues, warning_issues, info_issues, checked_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5892 (class 0 OID 158824)
-- Dependencies: 373
-- Data for Name: consult_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consult_requests (id, name, email, phone, company_name, kbli_code, business_size, location, location_type, investment_level, employee_count, project_description, deliverables_requested, estimate_status, auto_estimate, final_quote, confidence_score, admin_notes, reviewed_by, reviewed_at, contacted, contacted_at, converted_to_client, client_id, ip_address, user_agent, referrer_url, utm_params, created_at, updated_at, deleted_at, rag_insights, rag_confidence, rag_processed_at) FROM stdin;
\.


--
-- TOC entry 5914 (class 0 OID 159100)
-- Dependencies: 395
-- Data for Name: content_gaps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_gaps (id, suggested_title, suggested_slug, description, target_keyword, search_intent, category, service_slug, language, priority, status, article_topic_id, topic_cluster_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5922 (class 0 OID 159170)
-- Dependencies: 403
-- Data for Name: content_refresh_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_refresh_logs (id, article_id, status, changes, before_snapshot, after_snapshot, error_message, triggered_by, ai_tokens_used, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5908 (class 0 OID 159041)
-- Dependencies: 389
-- Data for Name: content_syndications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_syndications (id, article_id, platform, platform_url, status, published_at, metrics, error_message, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5818 (class 0 OID 157795)
-- Dependencies: 299
-- Data for Name: document_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_drafts (id, project_id, template_id, ai_log_id, title, content, sections, status, created_by, approved_at, approved_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 5814 (class 0 OID 157742)
-- Dependencies: 295
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_templates (id, name, permit_type, description, file_name, file_path, file_size, mime_type, page_count, required_fields, is_active, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 5758 (class 0 OID 157054)
-- Dependencies: 239
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, project_id, task_id, title, description, category, document_type, file_name, file_path, file_size, mime_type, version, parent_document_id, is_latest_version, status, document_date, submission_date, approval_date, uploaded_by, is_confidential, access_permissions, notes, download_count, last_accessed_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5836 (class 0 OID 158032)
-- Dependencies: 317
-- Data for Name: email_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_accounts (id, email, name, type, department, description, is_active, auto_reply_enabled, auto_reply_message, signature, assigned_users, total_received, total_sent, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 5838 (class 0 OID 158053)
-- Dependencies: 319
-- Data for Name: email_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_assignments (id, email_account_id, user_id, role, can_send, can_receive, can_delete, can_assign_others, notify_on_receive, notify_on_reply, notify_on_mention, priority, is_active, assigned_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5830 (class 0 OID 157940)
-- Dependencies: 311
-- Data for Name: email_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_campaigns (id, name, subject, template_id, content, plain_content, status, recipient_type, recipient_tags, scheduled_at, sent_at, total_recipients, sent_count, opened_count, clicked_count, bounced_count, unsubscribed_count, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5834 (class 0 OID 157999)
-- Dependencies: 315
-- Data for Name: email_inbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_inbox (id, message_id, from_email, from_name, to_email, subject, body_html, body_text, attachments, is_read, is_starred, category, labels, replied_to, assigned_to, received_at, created_at, updated_at, email_account_id, department, priority, status, first_responded_at, resolved_at, response_time_minutes, resolution_time_minutes, handled_by, tags, internal_notes, sentiment) FROM stdin;
\.


--
-- TOC entry 5832 (class 0 OID 157971)
-- Dependencies: 313
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, campaign_id, subscriber_id, recipient_email, subject, status, sent_at, opened_at, clicked_at, bounced_at, tracking_id, error_message, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5826 (class 0 OID 157910)
-- Dependencies: 307
-- Data for Name: email_subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_subscribers (id, email, name, phone, status, source, tags, custom_fields, subscribed_at, unsubscribed_at, unsubscribe_reason, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5828 (class 0 OID 157926)
-- Dependencies: 309
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_templates (id, name, subject, content, plain_content, thumbnail, category, is_active, variables, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5806 (class 0 OID 157684)
-- Dependencies: 287
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expense_categories (id, slug, name, "group", icon, is_default, is_active, sort_order, created_at, updated_at) FROM stdin;
1	personnel	Gaji & Honor	SDM & Personel	briefcase	t	t	10	2026-04-15 12:04:07	2026-04-15 12:04:07
2	commission	Komisi	SDM & Personel	handshake	t	t	20	2026-04-15 12:04:07	2026-04-15 12:04:07
3	allowance	Tunjangan & Bonus	SDM & Personel	money-bill-wave	t	t	30	2026-04-15 12:04:07	2026-04-15 12:04:07
4	subcontractor	Subkontraktor	Rekanan & Subkontraktor	hard-hat	t	t	40	2026-04-15 12:04:07	2026-04-15 12:04:07
5	consultant	Konsultan Eksternal	Rekanan & Subkontraktor	user-tie	t	t	50	2026-04-15 12:04:07	2026-04-15 12:04:07
6	supplier	Rekanan/Partner	Rekanan & Subkontraktor	handshake	t	t	60	2026-04-15 12:04:07	2026-04-15 12:04:07
7	laboratory	Laboratorium	Layanan Teknis	microscope	t	t	70	2026-04-15 12:04:07	2026-04-15 12:04:07
8	survey	Survey & Pengukuran	Layanan Teknis	ruler-combined	t	t	80	2026-04-15 12:04:07	2026-04-15 12:04:07
9	testing	Testing & Inspeksi	Layanan Teknis	vial	t	t	90	2026-04-15 12:04:07	2026-04-15 12:04:07
10	certification	Sertifikasi	Layanan Teknis	certificate	t	t	100	2026-04-15 12:04:07	2026-04-15 12:04:07
11	equipment_rental	Sewa Alat	Peralatan & Perlengkapan	truck-moving	t	t	110	2026-04-15 12:04:07	2026-04-15 12:04:07
12	equipment_purchase	Pembelian Alat	Peralatan & Perlengkapan	tools	t	t	120	2026-04-15 12:04:07	2026-04-15 12:04:07
13	materials	Perlengkapan & Supplies	Peralatan & Perlengkapan	box	t	t	130	2026-04-15 12:04:07	2026-04-15 12:04:07
14	maintenance	Maintenance & Perbaikan	Peralatan & Perlengkapan	wrench	t	t	140	2026-04-15 12:04:07	2026-04-15 12:04:07
15	travel	Perjalanan Dinas	Operasional	plane	t	t	150	2026-04-15 12:04:07	2026-04-15 12:04:07
16	accommodation	Akomodasi	Operasional	hotel	t	t	160	2026-04-15 12:04:07	2026-04-15 12:04:07
17	transportation	Transportasi	Operasional	car	t	t	170	2026-04-15 12:04:07	2026-04-15 12:04:07
18	communication	Komunikasi & Internet	Operasional	phone	t	t	180	2026-04-15 12:04:07	2026-04-15 12:04:07
19	office_supplies	ATK & Supplies	Operasional	file-alt	t	t	190	2026-04-15 12:04:07	2026-04-15 12:04:07
20	printing	Printing & Dokumen	Operasional	print	t	t	200	2026-04-15 12:04:07	2026-04-15 12:04:07
21	permit	Perizinan	Legal & Administrasi	file-contract	t	t	210	2026-04-15 12:04:07	2026-04-15 12:04:07
22	insurance	Asuransi	Legal & Administrasi	shield-alt	t	t	220	2026-04-15 12:04:07	2026-04-15 12:04:07
23	tax	Pajak & Retribusi	Legal & Administrasi	dollar-sign	t	t	230	2026-04-15 12:04:07	2026-04-15 12:04:07
24	legal	Legal & Notaris	Legal & Administrasi	balance-scale	t	t	240	2026-04-15 12:04:07	2026-04-15 12:04:07
25	administration	Administrasi	Legal & Administrasi	clipboard-list	t	t	250	2026-04-15 12:04:07	2026-04-15 12:04:07
26	marketing	Marketing & Promosi	Marketing & Lainnya	bullhorn	t	t	260	2026-04-15 12:04:07	2026-04-15 12:04:07
27	entertainment	Entertainment & Jamuan	Marketing & Lainnya	utensils	t	t	270	2026-04-15 12:04:07	2026-04-15 12:04:07
28	donation	Donasi & CSR	Marketing & Lainnya	gift	t	t	280	2026-04-15 12:04:07	2026-04-15 12:04:07
29	other	Lainnya	Marketing & Lainnya	ellipsis-h	t	t	999	2026-04-15 12:04:07	2026-04-15 12:04:07
\.


--
-- TOC entry 5748 (class 0 OID 156949)
-- Dependencies: 229
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- TOC entry 5750 (class 0 OID 156961)
-- Dependencies: 231
-- Data for Name: institutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutions (id, name, type, address, phone, email, contact_person, contact_position, notes, is_active, created_at, updated_at) FROM stdin;
1	Dinas Lingkungan Hidup Provinsi	DLH	Jl. Lingkungan Hidup No. 1	021-1234567	dlh@provinsi.go.id	Dr. Ahmad Hidayat	Kepala Bidang Perizinan	Untuk izin lingkungan hidup dan AMDAL	t	2026-04-15 12:04:07	2026-04-15 12:04:07
2	Badan Pertanahan Nasional	BPN	Jl. Pertanahan No. 2	021-2345678	bpn@go.id	Ir. Siti Nurhaliza	Kepala Seksi Hak Tanah	Untuk sertifikat tanah dan Pertek	t	2026-04-15 12:04:07	2026-04-15 12:04:07
3	Online Single Submission (OSS)	OSS	Portal Digital	1500-033	support@oss.go.id	Call Center OSS	Customer Service	Perizinan berusaha online	t	2026-04-15 12:04:07	2026-04-15 12:04:07
4	Notaris Andri Wijaya, S.H., M.Kn	Notaris	Jl. Hukum No. 3, Jakarta	021-3456789	notaris.andri@example.com	Andri Wijaya	Notaris	Untuk akta notaris dan pendirian badan usaha	t	2026-04-15 12:04:07	2026-04-15 12:04:07
5	Dinas Perhubungan Provinsi	DISHUB	Jl. Transportasi No. 4	021-4567890	dishub@provinsi.go.id	Drs. Bambang Sutrisno	Kepala Bidang Lalu Lintas	Untuk izin andalalin (analisis dampak lalu lintas)	t	2026-04-15 12:04:07	2026-04-15 12:04:07
6	Dinas Kesehatan Provinsi	DINKES	Jl. Kesehatan No. 5	021-5678901	dinkes@provinsi.go.id	dr. Maya Sari, M.Kes	Kepala Bidang Perizinan Kesehatan	Untuk izin rumah sakit dan fasilitas kesehatan	t	2026-04-15 12:04:07	2026-04-15 12:04:07
\.


--
-- TOC entry 5878 (class 0 OID 158642)
-- Dependencies: 359
-- Data for Name: interview_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interview_feedback (id, interview_schedule_id, interviewer_id, technical_skills, communication, problem_solving, cultural_fit, motivation, overall_rating, strengths, weaknesses, detailed_notes, recommendation, submitted_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5876 (class 0 OID 158612)
-- Dependencies: 357
-- Data for Name: interview_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interview_schedules (id, job_application_id, interview_type, interview_stage, scheduled_at, duration_minutes, location, meeting_type, meeting_link, meeting_password, interviewer_ids, status, notes, reminder_sent_at, completed_at, created_by, created_at, updated_at, recruitment_stage_id) FROM stdin;
\.


--
-- TOC entry 5782 (class 0 OID 157408)
-- Dependencies: 263
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_items (id, invoice_id, description, quantity, unit_price, amount, "order", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5780 (class 0 OID 157380)
-- Dependencies: 261
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, project_id, invoice_number, invoice_date, due_date, subtotal, tax_rate, tax_amount, total_amount, paid_amount, remaining_amount, status, notes, client_name, client_address, client_tax_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 5824 (class 0 OID 157883)
-- Dependencies: 305
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_applications (id, job_vacancy_id, full_name, email, phone, birth_date, gender, address, education_level, major, institution, graduation_year, gpa, work_experience, has_experience_ukl_upl, skills, cv_path, portfolio_path, cover_letter, expected_salary, available_from, status, notes, reviewed_at, reviewed_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5746 (class 0 OID 156941)
-- Dependencies: 227
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- TOC entry 5822 (class 0 OID 157864)
-- Dependencies: 303
-- Data for Name: job_vacancies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_vacancies (id, title, slug, "position", description, responsibilities, qualifications, benefits, employment_type, location, salary_min, salary_max, salary_negotiable, deadline, status, google_form_url, applications_count, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 5745 (class 0 OID 156932)
-- Dependencies: 226
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- TOC entry 5854 (class 0 OID 158319)
-- Dependencies: 335
-- Data for Name: kbli; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kbli (id, code, description, sector, notes, created_at, updated_at, category, activities, examples, complexity_level, default_direct_costs, default_hours_estimate, default_hourly_rates, regulatory_flags, recommended_services, is_active, usage_count, deleted_at) FROM stdin;
\.


--
-- TOC entry 5856 (class 0 OID 158334)
-- Dependencies: 337
-- Data for Name: kbli_permit_recommendations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kbli_permit_recommendations (id, kbli_code, business_scale, location_type, recommended_permits, required_documents, risk_assessment, estimated_timeline, additional_notes, ai_model, ai_prompt_hash, confidence_score, cache_hits, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5890 (class 0 OID 158797)
-- Dependencies: 371
-- Data for Name: kblis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kblis (id, code, title, category, description, activities, complexity_level, default_direct_costs, default_hours_estimate, default_hourly_rates, regulatory_flags, recommended_services, examples, notes, is_active, usage_count, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 5910 (class 0 OID 159064)
-- Dependencies: 391
-- Data for Name: keyword_clusters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keyword_clusters (id, seed_keyword, cluster_name, search_intent, keywords, long_tail_keywords, language, category, service_slug, estimated_volume, difficulty_score, priority, articles_count, status, last_researched_at, created_at, updated_at, gsc_clicks, gsc_impressions, gsc_avg_position, gsc_ctr, gsc_synced_at) FROM stdin;
\.


--
-- TOC entry 5934 (class 0 OID 159294)
-- Dependencies: 415
-- Data for Name: keyword_position_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keyword_position_history (id, keyword, our_url, "position", previous_position, position_change, data_source, top_competitors, search_volume, search_intent, tracked_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5926 (class 0 OID 159199)
-- Dependencies: 407
-- Data for Name: meta_ab_tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meta_ab_tests (id, article_id, test_type, variant_a_title, variant_a_description, variant_b_title, variant_b_description, variant_a_impressions, variant_a_clicks, variant_b_impressions, variant_b_clicks, winner, confidence, status, started_at, ended_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5737 (class 0 OID 156884)
-- Dependencies: 218
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_10_01_154236_create_institutions_table	1
5	2025_10_01_154240_create_project_statuses_table	1
6	2025_10_01_154249_create_projects_table	1
7	2025_10_01_154250_create_tasks_table	1
8	2025_10_01_154251_create_documents_table	1
9	2025_10_01_154252_create_project_logs_table	1
10	2025_10_01_154525_modify_users_table_for_perizinan	1
11	2025_10_01_162642_update_projects_table_structure	1
12	2025_10_01_162947_update_project_logs_user_id_nullable	1
13	2025_10_02_083808_add_financial_columns_to_projects_table	1
14	2025_10_02_083820_create_cash_accounts_table	1
15	2025_10_02_083827_create_project_payments_table	1
16	2025_10_02_083833_create_project_expenses_table	1
17	2025_10_02_091228_fix_payment_method_enum_values	1
18	2025_10_02_094020_create_permit_types_table	1
19	2025_10_02_094048_create_permit_templates_table	1
20	2025_10_02_094049_create_permit_template_items_table	1
21	2025_10_02_094050_create_permit_template_dependencies_table	1
22	2025_10_02_094102_create_project_permits_table	1
23	2025_10_02_094103_create_project_permit_dependencies_table	1
24	2025_10_02_155735_create_invoices_table	1
25	2025_10_02_155743_create_invoice_items_table	1
26	2025_10_02_155750_create_payment_schedules_table	1
27	2025_10_02_211614_create_permit_documents_table	1
28	2025_10_03_140559_add_permit_id_to_tasks_table	1
29	2025_10_03_163452_create_clients_table	1
30	2025_10_03_163524_add_client_id_to_projects_table	1
31	2025_10_03_194740_add_receivable_fields_to_project_expenses_table	1
32	2025_10_03_200841_update_category_enum_in_project_expenses_table	1
33	2025_10_03_204402_update_payment_method_in_project_expenses_table	1
34	2025_10_03_223304_add_invoice_id_to_project_payments_table	1
35	2025_10_04_000000_add_override_fields_to_project_permits_table	1
36	2025_10_09_190642_make_client_fields_nullable_in_projects_table	1
37	2025_10_09_223659_create_roles_and_permissions_tables	1
38	2025_10_10_115340_create_milestones_table	1
39	2025_10_10_181053_create_bank_reconciliations_table	1
40	2025_10_10_181100_create_bank_statement_entries_table	1
41	2025_10_10_181107_add_reconciliation_columns_to_transactions	1
42	2025_10_10_201930_create_articles_table	1
43	2025_10_11_000000_add_role_id_to_users_table	1
44	2025_10_11_000100_create_system_settings_table	1
45	2025_10_11_000200_create_expense_categories_table	1
46	2025_10_11_000300_create_payment_methods_table	1
47	2025_10_11_000400_create_tax_rates_table	1
48	2025_10_11_000500_create_security_settings_table	1
49	2025_11_03_130751_create_document_templates_table	1
50	2025_11_03_130753_create_ai_processing_logs_table	1
51	2025_11_03_130754_create_document_drafts_table	1
52	2025_11_03_163009_add_soft_deletes_to_document_drafts_table	1
53	2025_11_03_170000_create_compliance_checks_table	1
54	2025_11_11_183329_add_auth_fields_to_clients_table	1
55	2025_11_13_064858_create_job_vacancies_table	1
56	2025_11_13_064910_create_job_applications_table	1
57	2025_11_13_072934_add_unique_email_per_job_to_job_applications	1
58	2025_11_13_081830_create_email_subscribers_table	1
59	2025_11_13_081832_create_email_templates_table	1
60	2025_11_13_081834_create_email_campaigns_table	1
61	2025_11_13_081836_create_email_logs_table	1
62	2025_11_13_081839_create_email_inbox_table	1
63	2025_11_13_141344_add_email_fields_to_users_table	1
64	2025_11_13_141345_create_email_accounts_table	1
65	2025_11_13_141346_create_email_assignments_table	1
66	2025_11_13_141347_add_assignment_fields_to_email_inbox_table	1
67	2025_11_14_000001_add_menu_permissions	1
68	2025_11_14_061948_add_user_extended_fields_to_users_table	1
69	2025_11_14_072139_create_permit_applications_table	1
70	2025_11_14_072140_create_application_documents_table	1
71	2025_11_14_072140_create_quotations_table	1
72	2025_11_14_072141_create_application_status_logs_table	1
73	2025_11_14_072141_create_notifications_table	1
74	2025_11_14_072142_create_payments_table	1
75	2025_11_14_094703_add_permit_application_id_to_projects_table	1
76	2025_11_14_112756_add_converted_to_project_status_to_permit_applications	1
77	2025_11_14_122851_add_review_fields_to_application_documents_table	1
78	2025_11_14_123519_create_application_notes_table	1
79	2025_11_14_130916_add_kbli_to_permit_applications_table	1
80	2025_11_14_133029_create_kbli_table	1
81	2025_11_14_135102_remove_category_from_kbli_table	1
82	2025_11_14_135612_remove_kbli_category_from_permit_applications_table	1
83	2025_11_14_143524_create_kbli_permit_recommendations_table	1
84	2025_11_14_143536_create_ai_query_logs_table	1
85	2025_11_14_143545_add_ai_fields_to_permit_applications_table	1
86	2025_11_14_170218_make_permit_type_id_nullable_in_permit_applications_table	1
87	2025_11_16_105656_create_push_subscriptions_table	1
88	2025_11_16_194237_add_data_column_to_notifications_table	1
89	2025_11_16_232528_make_application_notes_author_id_nullable	1
90	2025_11_17_102953_create_application_revisions_table	1
91	2025_11_17_102954_create_application_location_details_table	1
92	2025_11_17_102955_create_application_legality_documents_table	1
93	2025_11_17_102955_create_quotation_items_table	1
94	2025_11_17_114542_create_business_contexts_table	1
95	2025_11_17_173223_add_profile_picture_to_clients_table	1
96	2025_11_17_210428_add_terms_acceptance_to_permit_applications_table	1
97	2025_11_19_073938_make_client_id_nullable_in_permit_applications	1
98	2025_11_21_043131_create_service_inquiries_table	1
99	2025_11_22_181209_create_notifications_table	1
100	2025_11_22_205447_add_completed_at_to_projects_table	1
101	2025_11_22_224959_make_project_id_nullable_in_project_payments_table	1
102	2025_11_23_000815_create_cash_account_balance_history_table	1
103	2025_11_23_001129_add_cash_account_id_to_payment_schedules_table	1
104	2025_11_23_041541_add_actual_completion_date_to_projects_table	1
105	2025_11_23_111131_create_interview_schedules_table	1
106	2025_11_23_111138_create_interview_feedback_table	1
107	2025_11_23_111138_create_test_templates_table	1
108	2025_11_23_111139_create_recruitment_stages_table	1
109	2025_11_23_111139_create_technical_test_submissions_table	1
110	2025_11_23_111139_create_test_sessions_table	1
111	2025_11_23_111140_create_test_answers_table	1
112	2025_11_23_123025_add_reminder_sent_at_to_interview_schedules_table	1
113	2025_11_23_164516_add_document_editing_fields_to_test_templates_table	1
114	2025_11_23_164602_add_document_editing_fields_to_test_sessions_table	1
115	2025_11_23_174732_drop_test_type_constraint_from_test_templates	1
116	2025_11_24_120001_add_recruitment_stage_links	1
117	2025_11_25_055219_add_soft_deletes_to_test_sessions_table	1
118	2025_11_27_065746_add_reference_attachments_to_test_templates_table	1
119	2025_11_27_114641_create_kblis_table	1
120	2025_11_27_150000_create_kblis_table	1
121	2025_11_27_151000_add_pricing_fields_to_kbli_table	1
122	2025_11_27_160000_create_consult_requests_table	1
123	2025_12_04_105016_add_rag_insights_to_consult_requests	1
124	2025_12_08_165544_create_ai_settings_table	1
125	2025_12_08_172724_create_ai_setting_history_table	1
126	2025_12_12_100000_create_article_topics_table	1
127	2025_12_12_100001_create_auto_post_configs_table	1
128	2025_12_12_100002_create_auto_post_schedules_table	1
129	2025_12_12_100003_create_auto_post_logs_table	1
130	2025_12_12_100004_create_article_topic_similarities_table	1
131	2025_12_17_130415_add_source_type_to_articles_table	1
132	2025_12_17_131711_create_content_syndications_table	1
133	2026_01_03_202134_add_language_support_to_auto_post_system	1
134	2026_01_04_100801_add_language_to_articles_table	1
135	2026_04_09_100000_create_keyword_clusters_table	1
136	2026_04_09_200000_create_seo_analytics_tables	1
137	2026_04_09_210000_create_seo_enhancement_tables	1
138	2026_04_11_120000_add_data_source_to_competitor_analyses	1
139	2026_04_12_140932_create_shapefile_projects_table	1
140	2026_04_12_165126_add_lead_fields_to_shapefile_projects_table	1
141	2026_04_13_100000_add_rtrw_fields_to_shapefile_projects_table	1
142	2026_04_13_120000_add_article_id_to_auto_post_schedules_table	1
143	2026_04_13_192831_add_topic_cluster_id_to_articles_and_topics	1
144	2026_04_13_202448_create_social_posts_table	1
145	2026_04_13_212324_create_keyword_position_history_table	1
146	2026_04_13_223841_add_eeat_fields_to_users_table	1
147	2026_04_14_100000_add_gsc_columns_to_keyword_clusters	1
148	2026_04_15_120000_create_trending_topics_table	1
\.


--
-- TOC entry 5796 (class 0 OID 157556)
-- Dependencies: 277
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.milestones (id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5848 (class 0 OID 158239)
-- Dependencies: 329
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, notifiable_type, notifiable_id, type, title, message, icon, related_type, related_id, action_url, read_at, created_at, updated_at, data) FROM stdin;
\.


--
-- TOC entry 5740 (class 0 OID 156901)
-- Dependencies: 221
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- TOC entry 5808 (class 0 OID 157698)
-- Dependencies: 289
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_methods (id, code, name, description, requires_cash_account, is_default, is_active, sort_order, created_at, updated_at) FROM stdin;
1	bank_transfer	Transfer Bank	Pembayaran melalui transfer antar bank.	t	t	t	10	2026-04-15 12:04:07	2026-04-15 12:04:07
2	cash	Kas Tunai	Pembayaran langsung menggunakan uang tunai.	t	f	t	20	2026-04-15 12:04:07	2026-04-15 12:04:07
3	check	Cek	Pembayaran menggunakan cek.	t	f	t	30	2026-04-15 12:04:07	2026-04-15 12:04:07
4	giro	Giro	Pembayaran menggunakan giro/bilyet.	t	f	t	40	2026-04-15 12:04:07	2026-04-15 12:04:07
5	other	Metode Lainnya	Metode pembayaran khusus sesuai kesepakatan.	f	f	t	100	2026-04-15 12:04:07	2026-04-15 12:04:07
\.


--
-- TOC entry 5784 (class 0 OID 157425)
-- Dependencies: 265
-- Data for Name: payment_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_schedules (id, project_id, invoice_id, description, amount, due_date, paid_date, status, payment_method, reference_number, notes, created_at, updated_at, is_reconciled, reconciled_at, reconciliation_id, cash_account_id) FROM stdin;
\.


--
-- TOC entry 5850 (class 0 OID 158251)
-- Dependencies: 331
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, payment_number, payable_type, payable_id, client_id, quotation_id, amount, payment_type, payment_method, gateway_provider, gateway_transaction_id, gateway_response, status, bank_name, account_number, account_holder, transfer_proof_path, verified_by, verified_at, verification_notes, paid_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5794 (class 0 OID 157537)
-- Dependencies: 275
-- Data for Name: permission_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_role (id, role_id, permission_id, created_at, updated_at) FROM stdin;
1	1	1	\N	\N
2	1	2	\N	\N
3	1	3	\N	\N
4	1	4	\N	\N
5	1	5	\N	\N
6	1	6	\N	\N
7	1	7	\N	\N
8	1	8	\N	\N
9	1	9	\N	\N
10	1	10	\N	\N
11	1	11	\N	\N
12	1	12	\N	\N
13	1	13	\N	\N
14	1	14	\N	\N
15	1	15	\N	\N
16	1	16	\N	\N
17	1	17	\N	\N
18	1	18	\N	\N
19	1	19	\N	\N
20	1	20	\N	\N
21	1	21	\N	\N
22	1	22	\N	\N
23	1	23	\N	\N
24	1	24	\N	\N
25	1	25	\N	\N
26	1	26	\N	\N
27	1	27	\N	\N
28	1	28	\N	\N
29	1	29	\N	\N
30	1	30	\N	\N
31	1	31	\N	\N
32	1	32	\N	\N
33	1	33	\N	\N
34	1	34	\N	\N
35	1	35	\N	\N
36	1	36	\N	\N
37	1	37	\N	\N
38	1	38	\N	\N
39	1	39	\N	\N
40	1	40	\N	\N
41	1	41	\N	\N
42	1	42	\N	\N
43	1	43	\N	\N
44	1	44	\N	\N
45	1	45	\N	\N
46	1	46	\N	\N
47	1	47	\N	\N
48	1	48	\N	\N
49	1	49	\N	\N
50	1	50	\N	\N
51	1	51	\N	\N
52	1	52	\N	\N
53	1	53	\N	\N
54	1	54	\N	\N
55	1	55	\N	\N
56	1	56	\N	\N
57	1	57	\N	\N
58	1	58	\N	\N
59	1	59	\N	\N
60	1	60	\N	\N
61	2	24	\N	\N
62	2	25	\N	\N
63	2	26	\N	\N
64	2	27	\N	\N
65	2	28	\N	\N
66	2	29	\N	\N
67	2	30	\N	\N
68	2	31	\N	\N
69	2	32	\N	\N
70	2	33	\N	\N
71	2	34	\N	\N
72	2	35	\N	\N
73	2	36	\N	\N
74	2	42	\N	\N
75	2	43	\N	\N
76	2	44	\N	\N
77	2	45	\N	\N
78	2	46	\N	\N
79	2	47	\N	\N
80	2	48	\N	\N
81	2	49	\N	\N
84	3	32	\N	\N
85	3	33	\N	\N
86	3	34	\N	\N
87	3	35	\N	\N
88	3	36	\N	\N
89	3	37	\N	\N
90	3	38	\N	\N
91	3	39	\N	\N
92	3	40	\N	\N
93	3	41	\N	\N
96	4	24	\N	\N
97	4	42	\N	\N
98	4	44	\N	\N
99	4	47	\N	\N
100	4	48	\N	\N
101	5	12	\N	\N
102	5	16	\N	\N
103	5	24	\N	\N
104	5	28	\N	\N
105	5	32	\N	\N
106	5	37	\N	\N
107	5	42	\N	\N
108	5	47	\N	\N
109	5	50	\N	\N
110	5	55	\N	\N
111	2	37	\N	\N
112	2	41	\N	\N
113	3	24	\N	\N
114	3	28	\N	\N
\.


--
-- TOC entry 5792 (class 0 OID 157526)
-- Dependencies: 273
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, display_name, "group", description, created_at, updated_at) FROM stdin;
1	recruitment.view_jobs	View Jobs	recruitment	Can view job listings	2026-04-15 09:20:47	2026-04-15 09:20:47
2	recruitment.manage_jobs	Manage Jobs	recruitment	Can create, edit, and delete jobs	2026-04-15 09:20:47	2026-04-15 09:20:47
3	recruitment.view_applications	View Applications	recruitment	Can view job applications	2026-04-15 09:20:47	2026-04-15 09:20:47
4	recruitment.process_applications	Process Applications	recruitment	Can review and process applications	2026-04-15 09:20:47	2026-04-15 09:20:47
5	email.view_inbox	View Inbox	email	Can view email inbox	2026-04-15 09:20:47	2026-04-15 09:20:47
6	email.send_email	Send Email	email	Can send emails	2026-04-15 09:20:47	2026-04-15 09:20:47
7	email.manage_accounts	Manage Email Accounts	email	Can manage email accounts	2026-04-15 09:20:47	2026-04-15 09:20:47
8	email.manage_campaigns	Manage Campaigns	email	Can create and manage email campaigns	2026-04-15 09:20:47	2026-04-15 09:20:47
9	email.manage_subscribers	Manage Subscribers	email	Can manage email subscribers	2026-04-15 09:20:47	2026-04-15 09:20:47
10	email.manage_templates	Manage Templates	email	Can manage email templates	2026-04-15 09:20:47	2026-04-15 09:20:47
11	email.manage_settings	Manage Email Settings	email	Can configure email settings	2026-04-15 09:20:47	2026-04-15 09:20:47
12	institutions.view	View Institutions	institutions	Can view institutions	2026-04-15 09:20:47	2026-04-15 09:20:47
13	institutions.create	Create Institutions	institutions	Can create new institutions	2026-04-15 09:20:47	2026-04-15 09:20:47
14	institutions.edit	Edit Institutions	institutions	Can edit institutions	2026-04-15 09:20:47	2026-04-15 09:20:47
15	institutions.delete	Delete Institutions	institutions	Can delete institutions	2026-04-15 09:20:47	2026-04-15 09:20:47
16	master_data.view	View Master Data	master_data	Can view master data	2026-04-15 09:20:47	2026-04-15 09:20:47
17	master_data.edit_permit_types	Edit Permit Types	master_data	Can edit permit types	2026-04-15 09:20:47	2026-04-15 09:20:47
18	master_data.edit_permit_templates	Edit Permit Templates	master_data	Can edit permit templates	2026-04-15 09:20:47	2026-04-15 09:20:47
19	content.view_articles	View Articles	content	Can view articles	2026-04-15 09:20:47	2026-04-15 09:20:47
20	content.create_articles	Create Articles	content	Can create new articles	2026-04-15 09:20:47	2026-04-15 09:20:47
21	content.edit_articles	Edit Articles	content	Can edit articles	2026-04-15 09:20:47	2026-04-15 09:20:47
22	content.delete_articles	Delete Articles	content	Can delete articles	2026-04-15 09:20:47	2026-04-15 09:20:47
23	content.publish_articles	Publish Articles	content	Can publish articles	2026-04-15 09:20:47	2026-04-15 09:20:47
24	projects.view	View Projects	projects	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
25	projects.create	Create Projects	projects	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
26	projects.edit	Edit Projects	projects	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
27	projects.delete	Delete Projects	projects	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
28	clients.view	View Clients	clients	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
29	clients.create	Create Clients	clients	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
30	clients.edit	Edit Clients	clients	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
31	clients.delete	Delete Clients	clients	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
32	invoices.view	View Invoices	invoices	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
33	invoices.create	Create Invoices	invoices	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
34	invoices.edit	Edit Invoices	invoices	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
35	invoices.delete	Delete Invoices	invoices	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
36	invoices.approve	Approve Invoices	invoices	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
37	finances.view	View Finances	finances	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
38	finances.manage_payments	Manage Payments	finances	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
39	finances.manage_expenses	Manage Expenses	finances	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
40	finances.manage_accounts	Manage Cash Accounts	finances	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
41	finances.view_reports	View Financial Reports	finances	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
42	tasks.view	View Tasks	tasks	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
43	tasks.create	Create Tasks	tasks	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
44	tasks.edit	Edit Tasks	tasks	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
45	tasks.delete	Delete Tasks	tasks	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
46	tasks.assign	Assign Tasks	tasks	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
47	documents.view	View Documents	documents	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
48	documents.upload	Upload Documents	documents	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
49	documents.delete	Delete Documents	documents	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
50	recruitment.view	View Recruitment	recruitment	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
51	recruitment.manage	Manage Recruitment	recruitment	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
52	email.manage	Manage Email System	email	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
53	content.manage	Manage Content	content	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
54	master_data.manage	Manage Master Data	master_data	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
55	users.view	View Users	users	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
56	users.create	Create Users	users	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
57	users.edit	Edit Users	users	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
58	users.delete	Delete Users	users	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
59	settings.manage	Manage Settings	settings	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
60	roles.manage	Manage Roles	settings	\N	2026-04-15 12:04:07	2026-04-15 12:04:07
\.


--
-- TOC entry 5840 (class 0 OID 158128)
-- Dependencies: 321
-- Data for Name: permit_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_applications (id, application_number, client_id, permit_type_id, status, form_data, notes, admin_notes, reviewed_by, reviewed_at, quoted_price, quoted_at, quotation_expires_at, quotation_notes, down_payment_amount, down_payment_percentage, payment_status, project_id, converted_at, submitted_at, created_at, updated_at, deleted_at, kbli_code, kbli_description, ai_recommendation_id, business_context, terms_accepted_at, terms_version, terms_accepted_language, terms_ip_address, terms_user_agent) FROM stdin;
\.


--
-- TOC entry 5786 (class 0 OID 157450)
-- Dependencies: 267
-- Data for Name: permit_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_documents (id, project_permit_id, filename, original_filename, file_path, file_type, file_size, description, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5774 (class 0 OID 157282)
-- Dependencies: 255
-- Data for Name: permit_template_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_template_dependencies (id, template_id, permit_item_id, depends_on_item_id, dependency_type, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5772 (class 0 OID 157260)
-- Dependencies: 253
-- Data for Name: permit_template_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_template_items (id, template_id, permit_type_id, custom_permit_name, sequence_order, is_goal_permit, estimated_days, estimated_cost, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5770 (class 0 OID 157242)
-- Dependencies: 251
-- Data for Name: permit_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_templates (id, name, description, use_case, category, created_by_user_id, is_public, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5768 (class 0 OID 157222)
-- Dependencies: 249
-- Data for Name: permit_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permit_types (id, name, code, category, institution_id, avg_processing_days, description, required_documents, estimated_cost_min, estimated_cost_max, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5766 (class 0 OID 157187)
-- Dependencies: 247
-- Data for Name: project_expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_expenses (id, project_id, expense_date, vendor_name, amount, bank_account_id, description, receipt_file, is_billable, created_by, created_at, updated_at, is_receivable, receivable_from, receivable_status, receivable_paid_amount, receivable_notes, category, payment_method, is_reconciled, reconciled_at, reconciliation_id) FROM stdin;
\.


--
-- TOC entry 5760 (class 0 OID 157092)
-- Dependencies: 241
-- Data for Name: project_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_logs (id, project_id, user_id, action, entity_type, entity_id, description, old_values, new_values, notes, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5764 (class 0 OID 157157)
-- Dependencies: 245
-- Data for Name: project_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_payments (id, project_id, payment_date, amount, payment_type, bank_account_id, reference_number, description, receipt_file, created_by, created_at, updated_at, payment_method, invoice_id, is_reconciled, reconciled_at, reconciliation_id) FROM stdin;
\.


--
-- TOC entry 5778 (class 0 OID 157345)
-- Dependencies: 259
-- Data for Name: project_permit_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_permit_dependencies (id, project_permit_id, depends_on_permit_id, dependency_type, can_proceed_without, override_reason, override_document_path, overridden_by_user_id, overridden_at, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5776 (class 0 OID 157309)
-- Dependencies: 257
-- Data for Name: project_permits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_permits (id, project_id, permit_type_id, custom_permit_name, custom_institution_name, sequence_order, is_goal_permit, status, has_existing_document, existing_document_id, assigned_to_user_id, started_at, submitted_at, approved_at, rejected_at, target_date, estimated_cost, actual_cost, permit_number, valid_until, notes, created_at, updated_at, override_dependencies, override_reason, override_by_user_id, override_at) FROM stdin;
\.


--
-- TOC entry 5752 (class 0 OID 156971)
-- Dependencies: 233
-- Data for Name: project_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_statuses (id, name, code, description, color, sort_order, is_active, is_final, created_at, updated_at) FROM stdin;
1	Penawaran	PENAWARAN	Tahap penawaran ke client	#3B82F6	1	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
2	Kontrak	KONTRAK	Kontrak telah ditandatangani	#10B981	2	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
3	Pengumpulan Dokumen	PENGUMPULAN_DOK	Pengumpulan dan penyusunan dokumen	#F59E0B	3	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
4	Proses di DLH	PROSES_DLH	Dokumen sedang diproses di Dinas Lingkungan Hidup	#8B5CF6	4	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
5	Proses di BPN	PROSES_BPN	Dokumen sedang diproses di BPN	#EC4899	5	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
6	Proses di OSS	PROSES_OSS	Dokumen sedang diproses di OSS	#06B6D4	6	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
7	Proses di Notaris	PROSES_NOTARIS	Dokumen sedang diproses di Notaris	#84CC16	7	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
8	Menunggu Persetujuan	MENUNGGU_PERSETUJUAN	Menunggu persetujuan dari instansi terkait	#F97316	8	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
9	SK Terbit	SK_TERBIT	Surat Keputusan izin telah terbit	#22C55E	9	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
10	Selesai	SELESAI	Proyek selesai dan diserahkan ke client	#10B981	10	t	t	2026-04-15 12:04:07	2026-04-15 12:04:07
11	Dibatalkan	DIBATALKAN	Proyek dibatalkan	#EF4444	11	t	t	2026-04-15 12:04:07	2026-04-15 12:04:07
12	Ditunda	DITUNDA	Proyek ditunda sementara	#6B7280	12	t	f	2026-04-15 12:04:07	2026-04-15 12:04:07
\.


--
-- TOC entry 5754 (class 0 OID 156986)
-- Dependencies: 235
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, description, client_name, client_address, status_id, institution_id, notes, created_at, updated_at, client_contact, start_date, deadline, progress_percentage, budget, actual_cost, contract_value, down_payment, payment_received, total_expenses, profit_margin, payment_terms, payment_status, client_id, permit_application_id, completed_at, completion_notes, actual_completion_date) FROM stdin;
\.


--
-- TOC entry 5860 (class 0 OID 158382)
-- Dependencies: 341
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_subscriptions (id, subscribable_type, subscribable_id, endpoint, public_key, auth_token, content_encoding, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5868 (class 0 OID 158465)
-- Dependencies: 349
-- Data for Name: quotation_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotation_items (id, application_id, revision_id, item_type, permit_type_id, item_name, description, unit_price, quantity, subtotal, service_type, estimated_days, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5844 (class 0 OID 158189)
-- Dependencies: 325
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotations (id, quotation_number, application_id, client_id, base_price, additional_fees, discount_amount, tax_percentage, tax_amount, total_amount, down_payment_percentage, down_payment_amount, payment_terms, valid_until, terms_and_conditions, status, accepted_at, rejected_at, rejection_reason, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5936 (class 0 OID 159310)
-- Dependencies: 417
-- Data for Name: ranking_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ranking_alerts (id, position_history_id, keyword, alert_type, severity, old_position, new_position, message, details, is_read, is_actioned, actioned_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5882 (class 0 OID 158681)
-- Dependencies: 363
-- Data for Name: recruitment_stages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recruitment_stages (id, job_application_id, stage_name, stage_order, status, score, notes, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5790 (class 0 OID 157514)
-- Dependencies: 271
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, display_name, description, is_system, created_at, updated_at) FROM stdin;
1	admin	Administrator	Full access to all features	t	2026-04-15 12:04:07	2026-04-15 12:04:07
2	manager	Manager	Manage projects, clients, and team members	t	2026-04-15 12:04:07	2026-04-15 12:04:07
3	accountant	Accountant	Manage finances, invoices, and payments	t	2026-04-15 12:04:07	2026-04-15 12:04:07
4	staff	Staff	Basic access to projects and tasks	t	2026-04-15 12:04:07	2026-04-15 12:04:07
5	viewer	Viewer	Read-only access	t	2026-04-15 12:04:07	2026-04-15 12:04:07
\.


--
-- TOC entry 5928 (class 0 OID 159219)
-- Dependencies: 409
-- Data for Name: search_console_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.search_console_data (id, page_url, query, date, clicks, impressions, ctr, "position", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5812 (class 0 OID 157725)
-- Dependencies: 293
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_settings (id, min_password_length, require_special_char, require_number, require_mixed_case, enforce_password_expiration, password_expiration_days, session_timeout_minutes, allow_concurrent_sessions, two_factor_enabled, activity_log_enabled, created_at, updated_at) FROM stdin;
1	8	t	t	t	f	90	30	t	f	t	2026-04-15 12:04:08	2026-04-15 12:04:08
\.


--
-- TOC entry 5920 (class 0 OID 159159)
-- Dependencies: 401
-- Data for Name: seo_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_reports (id, period, period_start, period_end, metrics, top_articles, alerts, emailed, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5918 (class 0 OID 159142)
-- Dependencies: 399
-- Data for Name: seo_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_scores (id, article_id, total_score, factors, recommendations, scored_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5872 (class 0 OID 158539)
-- Dependencies: 353
-- Data for Name: service_inquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_inquiries (id, inquiry_number, email, company_name, company_type, phone, contact_person, "position", kbli_code, kbli_description, business_activity, form_data, ai_analysis, ai_model_used, ai_processing_time, ai_tokens_used, analyzed_at, status, priority, source, utm_source, utm_medium, utm_campaign, client_id, converted_to_application_id, converted_at, ip_address, user_agent, session_id, last_contacted_at, contacted_by, admin_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5741 (class 0 OID 156908)
-- Dependencies: 222
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
ErUEjacw1wcNGLhkfDxSlvGSeBnD2pDERMZt8IOe	\N	172.68.159.20	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWEpnaHRpdDBna1UzVTZCZEhtMDJ2dUpFTFZKV2hudlRFdDh0eXJ5MSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo5MDoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvOC10YXgtaW5jZW50aXZlcy1mb3ItZ3JlZW4tdGVjaG5vbG9neS1pbnZlc3RtZW50LWluLWluZG9uZXNpYS0yMDI2IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776219865
C6RqHpfE8WArMsSqQ2IZAJWoOMeUFNGnjfp56VSs	\N	172.69.178.181	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiV2lDTkJ3eXA5aWtXUzNScmx1WmdQSVkxZGc1SEdKMWtCUEQzMlNJSSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo3MToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcGFuZHVhbi1sZW5na2FwLXBlbmd1cnVzYW4taXppbi11c2FoYS11bWttLTIwMjYiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776219998
vRphb6W4MtW4BPzlqRUqOtoE62HMmghAujJbXsTo	\N	172.70.219.243	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiTzBLMXZOTWhPMVQ2a1ozSk9tTFgzaUZkc0wzNTd5d1dMRUp1Q2NydCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776220006
D5o4McDwL7gM9l9mX1TT0vjHWRrY6ReGCz2pTfdV	\N	162.158.186.251	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiTWtaT0owQmR6VjRQeXBrcFA2V1Y2OWo0dGoxRHVRZ0pwOUtJSW80byI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcmVndWxhc2ktYmFydS1wZXJsaW5kdW5nYW4tZGF0YS1wcmliYWRpLWRhbi1kYW1wYWtueWEtYmFnaS1iaXNuaXMiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776220038
JjL9Eaztv4UYFNlPOpsXYbtPF0afJFI5Sa2Cjzte	\N	162.158.167.56	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoieTRrNU9GemRlQjAydVB5YzlrM1E0QlI0TDBFbXU2WWoxMjRLRzlOMiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo5MDoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvMzAtcGVydGFueWFhbi10ZW50YW5nLWxpbWJhaC1iMy15YW5nLXBhbGluZy1zZXJpbmctZGl0YW55YWthbi0yMDI2IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776220088
e7tedXCys4RpV8Cr4RXk5iwEiAAYVWbS5fHHXI3l	\N	172.69.60.152	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiOTZ1eTNickQ5UGJCN0xPRkJSNmFrNkpDemY5dzNtMGNCc1U5Sk4wSSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2NjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvc3lhcmF0LXBlbmRpcmlhbi1wdC1jaGVja2xpc3QtbGVuZ2thcC0yMDI1IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776220111
SW4crNnoRo4nvxqF9EHMhURJUKwhB8G31JYSf1ZE	\N	162.158.88.12	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZFVGZ2VBMnA2ZUtOek0zTU5hYUNJdEFCQUl4czhNcXhHeXVKeEJXUyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvc3lhcmF0LXBlbmRpcmlhbi1wdC1jaGVja2xpc3QtbGVuZ2thcC0yMDI1P3V0bV9zb3VyY2U9Y2hhdGdwdC5jb20iO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776220130
X0bDeut190hS6ydBXL3YRPaObZMePU87VLbwlJPb	\N	172.69.221.99	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRHpMenJ4Vk1XT0ZxUXk1TkpXOGNIaUU0bk0zUkdsRVAxNFVJQTFONSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcmVndWxhc2ktYmFydS1wZXJsaW5kdW5nYW4tZGF0YS1wcmliYWRpLWRhbi1kYW1wYWtueWEtYmFnaS1iaXNuaXMiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776220140
OIxbUatV9wIUk99m5xZZIL60lJq3H4SiqKdCh3Qj	\N	172.71.194.157	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoidERwVHdwVmZyY01FNXY1QWxDUVBoYTUwb1d0TDZIOWNIMWpVSm5iaSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0MDoiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4vaXppbi1rMy9iYXRhbSI7czo1OiJyb3V0ZSI7czozMjoicHJvZ3JhbW1hdGljLnNlcnZpY2UtbG9jYXRpb24uaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776220563
IP8Jyaz10isjTxqUEkoSbiD44o3SHgb58R9297zE	\N	162.158.39.251	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoienExdjRhU21kekk4OENMdHVKYmZJenZRZUs4cGhqSjlYcmlHTTBsRSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcmVndWxhc2ktYmFydS1wZXJsaW5kdW5nYW4tZGF0YS1wcmliYWRpLWRhbi1kYW1wYWtueWEtYmFnaS1iaXNuaXMiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776220583
mHotiekJEuorAwFwObrB0PQ8e2djbdFsZ9ncdfGm	\N	172.68.87.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiVnIzRHc1N1l0cWZ4OHE0bFAxVGxyM2M1VnUyRHlYWFFzdVN2S2ZnNyI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODk6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nL3RpcHMtbWVuZ3VydXMtc2VydGlmaWthc2ktaGFsYWwtYnBqcGgtdW50dWstcGVsYWt1LXVzYWhhLWtlY2lsIjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuZW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776220653
AO67KwsBNxPgQuYeW3tTZAP0jOqPpayVkTtBvMCY	\N	104.22.20.13	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZ0xJcWhXRzJrdWk3QzRuZzZ6akJTQ3ZxOW94RnZ1UEYzWTFPN0ljMyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo1MzoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL3RhbnlhJTIwamF3YWIlMjBwZXJpemluYW4iO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776220697
Q23K8Glfnlcx7xgARTF7SQUhvWZquoDKYNTXElcB	\N	172.70.39.7	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15 (Applebot/0.1; +http://www.apple.com/go/applebot)	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiYlhvdXBqR3BWV053N1NOZUdyZlEweTdFM3lsVmJmM01pRmw0MTlUZyI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDg6Imh0dHBzOi8vd3d3LmJpem1hcmsuaWQvZW4vc2VydmljZXMvbGFuZC1idWlsZGluZyI7czo1OiJyb3V0ZSI7czoxNjoic2VydmljZXMuc2hvdy5lbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776220761
jVQpQBG8ZlJLN9qkifptfCW9nx6qsMJQRL4xNEWu	\N	162.158.186.40	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWU00NTJ0VVRwWjVHUDl4YmVPTkRyWGp1Q3JBaUtZRGhyUEJwNUdxaCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcmVndWxhc2ktYmFydS1wZXJsaW5kdW5nYW4tZGF0YS1wcmliYWRpLWRhbi1kYW1wYWtueWEtYmFnaS1iaXNuaXMiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776220795
jhAB8Z666MRiKwabnsDS7EWyh3pNGLdryxsvl1sW	\N	162.158.107.77	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNHlRcGhXZVB3eTVuR3dpU1hZWm81cHBFYTZXYWVka0FQblQ5Y051RyI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTA1OiJodHRwczovL2Jpem1hcmsuaWQvZW4vYmxvZy9mcm9tLWFwcGxpY2F0aW9uLXRvLWFwcHJvdmFsLXN3aXNzLWZvb2QtY29tcGFueXMtam91cm5leS10by1icG9tLWNlcnRpZmljYXRpb24iO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5lbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776220841
QYObnVf8eJFTzNF9WV0ONBkB9s3WPdT25RruDlDB	\N	172.71.195.73	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoialJzaWpxS1pKQUVvdzlLZWpGMEtJN1lMTHdEek9CQTY5Q1NrMU9ueiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0MToiaHR0cHM6Ly93d3cuYml6bWFyay5pZC9sYXlhbmFuL2tvdGEvZHVtYWkiO3M6NToicm91dGUiO3M6MjA6InByb2dyYW1tYXRpYy5jaXR5LmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776220913
g0CFmq3yz8jchTw4lLWMaXGPhVrx6No54ZNl2v2M	\N	104.23.175.32	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoicVhvb21GeUVBV3Iwc3o1TFJLRGJDNXdrWHRKUm5idlBLcno5Nk1jbSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2ODoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcGFuZHVhbi1sZW5na2FwLWl6aW4tbGltYmFoLWIzLWthcmF3YW5nLTIwMjUiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776221292
xoVaGlNEKDIC3MIaonNeY3F1EG8bcvlBKijWPKn2	\N	172.71.194.156	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoibThpSFRleEtVYnFrSmpPT1lGbWszVlY1SGVmMWxGc2prOHZETldjUiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4NzoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvNTAtZmFxLWl6aW4tbGluZ2t1bmdhbi1pbmRvbmVzaWEtamF3YWJhbi1sZW5na2FwLWRhcmktYWhsaS0yMDI2IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776221297
ywvpHIoKhnY5mxVTc0MIW4c9NoC4Ztow27yYIi2A	\N	172.68.210.183	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoibFdsbzd3Z0wwYkRGeHk0WW9Hb0dpUWs3WHJuUE5peFZFbm4zejluUSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2NjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvbmliLW9ubGluZS1jYXJhLWRhZnRhci1zeWFyYXQtdGVyYmFydS0yMDI1IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776221394
lsff8H5CS1TvUpILmn5LiIzDfFhv3wDfNYQh8tTs	\N	172.71.211.6	Mozilla/5.0 (Linux; Android 9; 13 Ultra; Build/PQ1A.251203.173) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.244 Mobile Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiamNlNFBBcXdnSHhYSFZQNnR5UUFHZ2JVTUMxV09JajJEYkNXUWVDUyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776221445
4s2Yj3G8kAhjFZ0KRbAZxp9hDjHFI5HHvoQdWOON	\N	104.23.213.69	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZjY3ZjBYYk9DUjdobGc2UlhuQUk3eTFOWk1GZUVNcnEwRFdVOURaUCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0MzoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cva2F0ZWdvcmkvY29tcGFyaXNvbiI7czo1OiJyb3V0ZSI7czoxNjoiYmxvZy5jYXRlZ29yeS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776221559
BxNd99XmxEIRLmnx1DqW19x3DEmDhw9DY26ggcwK	\N	162.159.106.157	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUFh0Q20wTktRYWRXdE5WV3ZxZWFqNTJpck1MSVBHVVQ0Y0s3cWVleSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776221740
m9z7N7N8NzEZUA73tlIrJ9EMTrtwdwHV6FFLesZc	\N	104.22.66.12	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3.1 Safari/605.1.15	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMVFBVHVHRW1BSVR6R29oa3dFOEhVRDBNcE8wMElqTGtxMjBIZUs3SCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozODoiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4va290YS9zb3JvbmciO3M6NToicm91dGUiO3M6MjA6InByb2dyYW1tYXRpYy5jaXR5LmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776221755
WvwjIohUJHv4VK9FQtcDKfS78riHTG8ajxr0Rrtt	\N	104.22.18.49	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoick90VEtYWko2Smd0WUlqdDZ0NnNMZWN1dENPaW5PaFp1bmxYV1ZSRCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4NzoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvNTAtZmFxLWl6aW4tbGluZ2t1bmdhbi1pbmRvbmVzaWEtamF3YWJhbi1sZW5na2FwLWRhcmktYWhsaS0yMDI2IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776221903
ZZwXmGaSj6a5Vg4h85km4z0xQ0rOSMRSGiXVsivO	\N	162.158.163.84	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiOHRDOFFEdldyUDAzazRET3RyM0NoVnZ2cUZZS2FpcGl1Z3ZKbnNZYSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo5MDoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvOC10YXgtaW5jZW50aXZlcy1mb3ItZ3JlZW4tdGVjaG5vbG9neS1pbnZlc3RtZW50LWluLWluZG9uZXNpYS0yMDI2IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776222079
hLFYrA0XcUU5rWHY0cBAKjyEkcf445VnjRYpPotB	\N	162.158.108.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiaWR2cUJldlRCTHdKbjZ2eGlpU2VScnJhelFwUkZpb0E4aGdmT0lxMSI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODc6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nL3BhbmR1YW4tcmVndWxhc2ktZXNnLXJlcG9ydGluZy11bnR1ay1wZXJ1c2FoYWFuLXRlcmJ1a2EtMjAyNiI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776222148
PM5E8FNzlcn5xVqkRwQvDQNh1jmK6EZquzX8a0R3	\N	172.71.124.199	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.197 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUGxmYWF6azZ6T0xweFo4RkMzeXVtaUY3UkFnU3ZWUU1QM2g5Tm85QyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo3MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvYmVyYXBhLWxhbWEtcHJvc2VzLWl6aW4tbGluZ2t1bmdhbi10aW1lbGluZS0yMDI1IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776222185
nY36ORVRHo2pW6fPzS91PrKKhrARWeVNcos4cuyZ	\N	162.158.163.84	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRkVJYnRqdjMxMFFyQ3lTY0J3cVp4UUZJTGM3eDRJWGZGZUlzbWhGSCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo3MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvYmVyYXBhLWxhbWEtcHJvc2VzLWl6aW4tbGluZ2t1bmdhbi10aW1lbGluZS0yMDI1IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776222185
pizyn18cdXBa3FCCkYe680yrJ1Vzg9KTXUUloVlm	\N	172.69.89.142	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoielJhenM0YU9pOXpuRDZsY1pCbnowdG92N0N2SWxlbDUwZzJreU1ZUSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0MToiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4vcGJnLXNsZi9iZWthc2kiO3M6NToicm91dGUiO3M6MzI6InByb2dyYW1tYXRpYy5zZXJ2aWNlLWxvY2F0aW9uLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776222295
lTntps4bk9qgQk83RzDWHnvWISU6r7cwivCNkEtn	\N	104.23.175.33	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoic3FaVUFQS00yT0lLVkJUZldWdHhRaUlHdUZ6UWR0WlFJMXhUejVaNiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776222473
t8GCZk4Vn8AauUePQw3G7ZBTtyA1P7o5GaV5JJG2	\N	172.68.87.232	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQmp6VGxOdWVjN01IRGJJSG9CeGpnWnl2WFNHekpycDhxZGRKSlYweCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776222476
a8ClXSOpmMAg3SjMXl1vqPc0v1LlQCz638uBJ7gF	\N	172.69.60.152	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWjhZc0xzUlM3RmtxZlo5ODFUbkxpOFFtTEJSUXh0YlRUdW5Lazh5ayI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776222956
GsmhJz47PpLox3Z8NkjZQvtPwtdCuVbY10cN9IYL	\N	108.162.249.144	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiN09nd1NhV2JtZEVLNGFDdjBnSUIzdGlvZjRsRW1yTFV6VkNkd3dLNyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776222956
ftRfQ3KPjj7N2mLZCWpQVoQ17Gwtl9SAafDlFzED	\N	172.70.142.75	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRTV1QmY1V1RJWE5qOEpXTU1yRVJxQ3FMM1BFa0VwUlZuVFlkQ0FNUyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoyMzoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2ciO3M6NToicm91dGUiO3M6MTM6ImJsb2cuaW5kZXguaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776223029
nnK1p7zFKZL9QKX8gZTWDoCUahYyjNxET0KONQPH	\N	104.22.18.53	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiQ1NyN0xXWWpicElqRkgwV09Ta3hzVHBXRXlMaU85cmg1SlZLcTgxdCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0NjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL3Blcml6aW5hbi1pbmR1c3RyaSI7czo1OiJyb3V0ZSI7czoxMToiYmxvZy50YWcuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776223089
NIRj5Ysv9ZDK6c3ranmxyXrifOPPjVgsVsplJRlX	\N	162.158.79.24	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiSUVVb00zd3V3S2k4REJ6eFJ2bk1hMjBnUlpibnpydjNCNXhvTlNndCI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDk6Imh0dHBzOi8vd3d3LmJpem1hcmsuaWQvZW4vYmxvZy90YWcvU3VzdGFpbmFiaWxpdHkiO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776223121
S1epZqeeYR9OBZwprQhV6O7xfekosWcVyHBXdJZO	\N	172.71.82.93	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiU0VldHBKb1dOTWdUSjBBSGJFUVhuSkk0MXlTb2hpMUw4elpMS2tuSyI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6OTM6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nLzgtdGF4LWluY2VudGl2ZXMtZm9yLWdyZWVuLXRlY2hub2xvZ3ktaW52ZXN0bWVudC1pbi1pbmRvbmVzaWEtMjAyNiI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776223257
QHYbmO78EcvQCVKEUNsKjLu96vMptSIouJtz5982	\N	172.68.87.232	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMTBCM1ZsVExiT212Yzl2alFoNnpZTU05eVRzVjQ3dDFyRUxSZXpSdiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGltZWxpbmUtcHJvc2VzLXBlcml6aW5hbi1iZXJhcGEtbGFtYS1zZXRpYXAtaXppbi1kaXByb3NlcyI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776223682
1Zj9Lte8AqxSKx6AKaIIE5Y3e54PuSWBGAw64ydU	\N	172.70.42.165	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiQUhSNVJQSlFBVGk1cGhGVHF4SGVWQ2dKMFl6c1JmZ0NFekpKdTEzbCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo1MzoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL3RhbnlhJTIwamF3YWIlMjBwZXJpemluYW4iO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776223759
n3kOFjNKrj5VgI1n4HNSLnI91dAjMnKpTnWZVzro	\N	172.70.208.31	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWkFOZGJJWGhpREllME1iQ2c0QW1VbUFWN2FNc21BUWZVWGJvam54cCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2ODoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcGFuZHVhbi1sZW5na2FwLWl6aW4tbGltYmFoLWIzLWthcmF3YW5nLTIwMjUiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776223770
a7qs97rlwWBT65M7aZZPSqM2LdefeXAJnIyiNBK8	\N	104.22.66.130	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiY1B4b000THBHeWdoZmNpaXluQWV3c1ZJS0ZiMW44bjMxZ0ZjZzlwcyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2MToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvNS1rZXNhbGFoYW4tZmF0YWwtbWVuZ3VydXMtYW1kYWwtMjAyNSI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776223882
my9ZuXEGA5TvygIIKiQRkQ7IvwVcUH7XyljaJ0Db	\N	108.162.249.144	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoic2dRTEs5dDlFT2cxc2FPWUZYcFFhaFpmS25GZU80b3RFWVJMdXFDZyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4NDoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvbmF2aWdhdGluZy1pbmRvbmVzaWFzLW1lZGljYWwtZGV2aWNlLXJlZ2lzdHJhdGlvbi1ldXJvcGVhbi1tIjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776223985
UaCiGTLyuBhAySrnqlIdpGbDoN5v3xRFU3x576gJ	\N	108.162.249.144	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRmx5UmZvWmJRWDAzT2t6cG41SlpENzA0bEl3MWdEY3VkU3JLQ0gwdiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4ODoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcGFuZHVhbi1sZW5na2FwLWNhcmEtbWVuZ3VydXMtaXppbi1rMy11bnR1ay1wZXJ1c2FoYWFuLWFuZGEtMjAyNiI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776224150
z9h18wXIKcHnRcjKDthWK2Kq7aJCA8KhLGKIn7aC	\N	172.69.176.12	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiQ1JWZ0QwcUx2WDZIR0VGWTNaVkE3UWEyMW5tSlcydTM2YlFUQ2VIcSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozOToiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4va290YS9jaWxhY2FwIjtzOjU6InJvdXRlIjtzOjIwOiJwcm9ncmFtbWF0aWMuY2l0eS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776224154
1RHrBiBfrhdNZS8ki7mKK66qERWIOXIKDavDGDjY	\N	104.22.42.139	Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.177 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTo1OntzOjY6Il90b2tlbiI7czo0MDoicmlNNGRXeVdRMkwzS0NLSnhXMjhucmU3YWN2VDhPRlZPTnVDcWdiYSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo1OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL2l6aW4rdXNhaGEramFzYStrb25zdHJ1a3NpKzIwMjYiO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776224222
dhApvOROFOuSs7xQkI0gWqu4GoUdSHEekHRemZ36	\N	162.158.48.227	Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRlROQmZ3RkprMEZ6VzNCZklYM1Frb1pyTGx2TVJLb1YxZTU1cmQ1WCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo5MDoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvNy1jcml0aWNhbC1jaGFuZ2VzLXRvLWluZG9uZXNpYXMtaW52ZXN0bWVudC1wcmlvcml0eS1saXN0LWRzcC0yMDI2IjtzOjU6InJvdXRlIjtzOjE1OiJibG9nLmFydGljbGUuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776224231
iXXzB2M3m5yyEpzt5SF4F2KBrNzYWtOGzXqmCHkQ	\N	172.68.18.104	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWk9rTndDS2g4Zk9idkhlSHlqWVYxVGlLYncxczc3RUxQUVJrUGFuRiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozNToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL3VrbC11cGwiO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776224242
YPl39i0YkF59QPi1FanmM5tXp7tGNGA1P2GbUewv	\N	172.71.195.74	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRk9qM0NJNG02amZMRU53aThsQ3J6bkVoMTlQczNxS3BDcG4wbk1jcCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4ODoiaHR0cHM6Ly93d3cuYml6bWFyay5pZC9ibG9nL2NvbXBsZXRlLWd1aWRlLXRvLWluZG9uZXNpYXMtbmV3LWZvcmVpZ24td29ya2VyLXBlcm1pdC1zeXN0ZSI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776224257
NkCBQZ0B5AGGieiglB7bsIXyPo5Y9ESiTnagvtcn	\N	162.158.108.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiM2RvbVNTZnhERE1heUlJM2FuVUZ2ZXRzVzhBRmdGU21Vd2plUldNbCI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODc6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nL25hdmlnYXRpbmctaW5kb25lc2lhcy1tZWRpY2FsLWRldmljZS1yZWdpc3RyYXRpb24tZXVyb3BlYW4tbSI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776224478
a41rJgjezDkAkyEU4TfdDMNVT0IkQGzZ876skgPU	\N	162.158.88.12	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNUVwZ09wVmhvSm5LaDFTQ0kybzVSMjlmUHFwMmZZMW5Ba0FOMEpyUyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozOToiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4va290YS9ib250YW5nIjtzOjU6InJvdXRlIjtzOjIwOiJwcm9ncmFtbWF0aWMuY2l0eS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776224480
Ekj8QYsMxroinGytWbXD7FZcL7Zfll109ftkTN5B	\N	162.158.102.245	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUzJOQmVoY2IxTDVmWjBrN1IwWTkxNzFsbVN5WTJPSGRlRHE3V2I0VCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776225019
A5bCG7BiCyoPx2SEPIvCX2zEcbvIRYmKNuGenvDs	\N	162.158.172.153	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNDg3dXh3VXp1dWV0R1Vtb0J5VU14dWJWUlNTTktFVVVxb1dwOHNZTyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776225019
PGyPSDK3ob22QREhboQTWxatT9WhwIA9rf5KCVek	\N	104.23.175.32	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRjNLckpObGpPb1Azb2NqYjdKSDJsWlVNV1JWRmhhY1NlYTc3QW5XTSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2ODoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcGFuZHVhbi1sZW5na2FwLWl6aW4tbGltYmFoLWIzLWthcmF3YW5nLTIwMjUiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776225236
pNmGXRmRcGugxFt12AEwS4DGYh6vdKaogInpwKfr	\N	172.68.210.183	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiVjFDZmFOMTFOZTZBemhqMVBmWW5rVW9hREFFdk45VDgyUmlnWGtMYyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776225325
4wwFyZsKQVlY9XBH9PRssN2FucRgH1JhvzRCeh5G	\N	104.23.209.187	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoidDZTMTJTc3FqcmlMSGdYc3dmSXlpRTlvalFMWVRsNHBZYWxGOTltRCI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vd3d3LmJpem1hcmsuaWQvZW4vYmxvZy90YWcvYW1kYWwiO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776225359
n01mh86icLiJKDs36tZY4CXXaChHGVu9uh8pqcyr	\N	172.69.94.249	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZmlmTUNVa0VMY1oxSUd0TEV5MjBLblNoMkZlOGxZc1Ewb0pIbUtJSSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcmVndWxhc2ktYmFydS1wZXJsaW5kdW5nYW4tZGF0YS1wcmliYWRpLWRhbi1kYW1wYWtueWEtYmFnaS1iaXNuaXMiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776225553
UQG8tY76IemDpHwKWndQwdlldFYjLugAccoXvg7B	\N	172.70.142.199	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZXlReEF1VWN5eEJXVmNHdUg0T2w4eEhoNngxRldvZWhrTHhGYjdpdSI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTE3OiJodHRwczovL2Jpem1hcmsuaWQvZW4vYmxvZy9zdWNjZXNzLXN0b3J5LWhvdy1hLXVzLXJlbmV3YWJsZS1lbmVyZ3ktY29tcGFueS1uYXZpZ2F0ZWQtaW5kb25lc2lhcy1wb3dlci1wbGFudC1saWNlbnNpbmciO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5lbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776225695
VwK6T9nyVBR9hlC7nD5mEAYqTywMVOMof7LHno5W	\N	162.158.170.218	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiTG1mRXR5bWRoOXB3T0NhY0hrTWloWmt1dU1mV3NNVkZkcXEyTzFpNCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2MToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvYW1kYWwtdnMtdWtsLXVwbC1wYW5kdWFuLWxlbmdrYXAtMjAyNSI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776227383
WiuB1EQVARszEbWIKiUNCkHUhbg3muc7T0uRkWR1	\N	172.70.34.34	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiY1BwamFQcEwyeE1MZW9ONXpad2JIaVdmaVFDbldaYnNaemVvQmlIbCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0NToiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4vaXppbi1rMy9iYWxpa3BhcGFuIjtzOjU6InJvdXRlIjtzOjMyOiJwcm9ncmFtbWF0aWMuc2VydmljZS1sb2NhdGlvbi5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776225956
29cNyRPXX8a9QmzrkemUPJjg6hA0qkinMSxkWHDG	\N	172.71.215.130	Mozilla/5.0 (Linux; Android 8.0.0; SM-J330G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36 EdgA/114.0.1823.74	YTo1OntzOjY6Il90b2tlbiI7czo0MDoidk53R3NDMmdXSmxFYTBXeWt3b2JJOUNwd2ZuRldOVmJhc0NEUXFvQiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL2NhcmElMjBtZW1idWF0JTIwTlBXUCI7czo1OiJyb3V0ZSI7czoxMToiYmxvZy50YWcuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776226516
m5SYLVEZrblAunQ4ULjjHAhEcH3qHQ6hdZ1y9ysB	\N	104.23.170.39	Mozilla/5.0 (compatible; OpenindexSpider; +https://www.openindex.io/saas/about-our-spider/)	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNVJMR3Zrc1ExU0x6MUFLSno1cFZ5OEtIdHlSRTlwWmlOdXBiaDVFVSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo3NDoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGlwcy1tZW55dXN1bi11a2wtdXBsLXlhbmctZGlzZXR1anVpLWRhbGFtLTE0LWhhcmkiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776226748
63BCwwuFuXsXiaAJdfNzfY5LaehOg16GPgzrF1WH	\N	172.68.87.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUmlzMXhNN3o3RUNKTGQxV0x2RW1jeVE0WURzNGw5dlByVVFWVmZyZCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGltZWxpbmUtcHJvc2VzLXBlcml6aW5hbi1iZXJhcGEtbGFtYS1zZXRpYXAtaXppbi1kaXByb3NlcyI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776226796
cnIi4qatVvZYfFp9H6MgvUOwMwKRVTyMcThleXIH	\N	104.22.17.6	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiakZHaXR6ak5SODZqd0ttSWd4TU0yZUVvS0NIYmFwZTZLYzJ2ckpiOSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776226842
gXYHjyTcJJZoZ6fP88oyoLZ4pvDawLnSuLC4uful	\N	172.70.142.199	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiOXFqV1g0N0haUzB3RXdoM2NTbzA2Y1R3blBHNkI0aEFwYWxseFYxcyI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODc6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nL2Nhc2Utc3R1ZHktdGVjaC1zdGFydHVwLXN1Y2Nlc3NmdWxseS1uYXZpZ2F0ZXMtcG1hLWxpY2Vuc2luZyI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmVuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776226918
xgrn2v4SyZOhmCa8hWohj2WVeGSWxtk7VAKivdEs	\N	172.68.87.232	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiT2cwczRTMFkxQzBrVll3eGFVQU8yRG1pZG5KdjJQU09RU0NneThoZSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvNS1rZXNhbGFoYW4tdW11bS1zYWF0LW1lbmd1cnVzLW5pYi1kYW4tY2FyYS1tZW5naGluZGFyaW55YSI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776227170
QEZpp48hEXMXpBoO2IcNfOJOPef61uv9Z4zF1Z2T	\N	104.22.66.130	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.47 Mobile/15E148 Safari/604.1	YTo1OntzOjY6Il90b2tlbiI7czo0MDoia1hUS0N6eTQ3Z0tmdGs1dHM2WWZlZnMzQURLTEFid0xNMkFBYlp0TiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0NzoiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4va29uc3VsdGFuLWxpbmdrdW5nYW4iO3M6NToicm91dGUiO3M6MTY6InNlcnZpY2VzLnNob3cuaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776227285
N2npfi6eIVglROVgZ5OWESVAJSepMUco19CR18nT	\N	172.71.164.185	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMXJHSjB0Sm9WR3FlaHlyYldCNHcxM2ZaSUtGTWE2MW1JZjJuc0Y3OSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776227435
rFs1BxDWIfSX5kdGLQIBjSSTFBoiWPuNR62f91Kp	\N	172.68.193.193	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoieHFhQ3BmSHJWY2cya1p5T2U0aEhLOEROM2preVJyVnhPQ3lDelpnVCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoyMjoiaHR0cHM6Ly93d3cuYml6bWFyay5pZCI7czo1OiJyb3V0ZSI7czoxMDoibGFuZGluZy5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776227855
Z8WYmlOGcOg7nTY8H36urNXVyADPe0qcoZIBqBQs	\N	172.71.148.39	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWHVkSUUxQlh6eTZ1aE9OWlh6VlR4QzJYakU0ZGlMbmZ4clJhSDdDUCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776227891
fuxRGlt7KsdBI6ssRfAmRZHnB6GIVqE7i9SLXyRI	\N	172.71.82.92	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0	YTo1OntzOjY6Il90b2tlbiI7czo0MDoia0N2bXpZQm0ySWczanJobzBIbmpqUFFISVBKQm5VMTZFVnIzdmdpQyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4va290YS95b2d5YWthcnRhIjtzOjU6InJvdXRlIjtzOjIwOiJwcm9ncmFtbWF0aWMuY2l0eS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776227999
lo7lN2zKnhfs2HDHVEp6CGfm1cyELF9mKqsXhvSB	\N	172.71.191.73	meta-webindexer/1.1 (+https://developers.facebook.com/docs/sharing/webmasters/crawler)	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiang3dUN4R2I1azBHblJ5NEx1Qmt0a2M1NHBVMVdIYnUwa29laG8wYSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0NzoiaHR0cHM6Ly9iaXptYXJrLmlkL3BhbmR1YW4vcGFuZHVhbi1vc3MtbmliLTIwMjYiO3M6NToicm91dGUiO3M6MTE6InBpbGxhci5zaG93Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776228050
ec1z8AQijK3Nxtxe62Cx2Yu6BfXZCWiI8Qjm1Y83	\N	104.23.211.194	Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Mobile Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMHJDQjN1Tml6RHV3a1F6TEs5eEdQcHpFaGthUU1wUmc4UlFwM2p6dCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo1MzoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL2JlcmFwYSUyMGxhbWElMjBpemluJTIwYjMiO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776228091
bqVkuKYLfX0xskixy25Nc3A7Z02OQLn3oKsatBRe	\N	162.158.163.84	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiQmg3VXdmdkdORWtWVlJkbG00eXFhSm5CelZxZEN5aHNhOTVQSFpPTiI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nL2NhdGVnb3J5L3Blcml6aW5hbiI7czo1OiJyb3V0ZSI7czoxNjoiYmxvZy5jYXRlZ29yeS5lbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776228180
Q7QYuMhksPEfTD5qitSqrxLaRd83XqdrzGQ3Sc1P	\N	172.69.17.39	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiY1E3Uld1Q0xkN1Vzb1JIR09TbjZHQWtDYmZXVHdpVzQ4Q3lHT000aSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoyNDoiaHR0cHM6Ly9iaXptYXJrLmlkL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776228422
hpH0EO9wrXHwNIWGsWZs2I5qLDDImIFTiIsDtHbm	\N	172.70.108.243	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZGtHMVZ2dXNySnk1VGk4aXhWdEU2M3lCYzZFWUNYQjBOOWhLTWNYZCI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776228790
HvnhhcWZ7qdeWipKRAN7N5gpzLmCOw6CE8E7xafX	\N	172.68.22.187	Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.177 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTo1OntzOjY6Il90b2tlbiI7czo0MDoid0UzV2MxdVdJbEtJTXp4Z2Y0N1FxOFBwdnNaUDhCallCNlY4cmFObCI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTE6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9zZXJ2aWNlcy9pbW1pZ3JhdGlvbi1zZXJ2aWNlcyI7czo1OiJyb3V0ZSI7czoxNjoic2VydmljZXMuc2hvdy5lbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776228814
WA0jMI7UZOUNtuwBUCeqKIh4hFXe8KW1HW4AhC1l	\N	108.162.245.10	Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.177 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiaW93Qzg0a1ZQd2dmdzR1SFVoS25FRWFTcjljVWc3UkRHcTZhOFVubSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozMjoiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvdGFnL0VTRE0iO3M6NToicm91dGUiO3M6MTE6ImJsb2cudGFnLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776228814
8SRNuUBtSDfrjAvuDoXogn1RUjiDOML4mKD6IAL4	\N	162.158.88.12	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoicU9CQkRndlh3ZDhKMFRNdkZKeDlPUXJGUUFiN1dmaDVkT1hZSU1IeCI7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjM6InBtYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODI6Imh0dHBzOi8vYml6bWFyay5pZC9lbi9ibG9nL2Nhc2Utc3R1ZHktc3VjY2Vzc2Z1bC1wbWEtc2V0dXAtaW4tbWFudWZhY3R1cmluZy1zZWN0b3IiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5lbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776229410
1MOai1FxO0as0VO1KDHURd1Uotc6Tg78QMw5EIc2	\N	172.70.179.185	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiTmNjUVhya1JxNkRrckwzN2ROZVllbmpZRlh5TmJNdWRXY1lpbXlURyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo4OToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvcmVndWxhc2ktYmFydS1wZXJsaW5kdW5nYW4tZGF0YS1wcmliYWRpLWRhbi1kYW1wYWtueWEtYmFnaS1iaXNuaXMiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1776229439
tPki0vwxOKrcu3liJcTVwcUlqf0TDhfCB8Bd7OdA	\N	108.162.249.145	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRGhqalR2WkUweVRQcVh1Z1FWTHhLc0h6Z0F3cGlCVnEzem5RWXpxSiI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxODoiaHR0cHM6Ly9iaXptYXJrLmlkIjtzOjU6InJvdXRlIjtzOjEwOiJsYW5kaW5nLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776229487
1yuj9rRtMSF5gQXmdnXpy0u4Aqqsd514W86uqxCi	2	172.69.176.12	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo4OntzOjY6Il90b2tlbiI7czo0MDoiT2p4WDBLbnFiNmRnUlZTYjFWTUdDSW9CZVNwek92MGg5N0JJUjc1SyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoxMDM6Imh0dHBzOi8vYml6bWFyay5pZC9ibG9nL3B0LWNhbmdhaC1wYWphcmF0YW4tbWFuZGlyaS1yYWloLXBlbmdoYXJnYWFuLWJlc3QtZW52aXJvbm1lbnRhbC1jb25zdWx0YW50LTIwMjQiO3M6NToicm91dGUiO3M6MTU6ImJsb2cuYXJ0aWNsZS5pZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjI7czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzc2MjI5NTEzO31zOjEyOiJzY3JlZW5fd2lkdGgiO2k6MTQ0MDt9	1776229537
kgJZHqsgF2dqzOlnFjtede40HcjtxJBsLd42EJDH	\N	172.70.142.199	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiamppRlVCR2pnOGZ6NTZVakhqUzVqdHF0NmtvNnI1Q0RGZmhubEdLSSI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo1MjoiaHR0cHM6Ly9iaXptYXJrLmlkL2xheWFuYW4vbW9uaXRvcmluZy1kaWdpdGFsL3N1YmFuZyI7czo1OiJyb3V0ZSI7czozMjoicHJvZ3JhbW1hdGljLnNlcnZpY2UtbG9jYXRpb24uaWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1776229559
Wh596IhqmTqupFBEuzNK1Y62oirKAFwn6mBr6irJ	\N	104.23.175.32	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTo1OntzOjY6Il90b2tlbiI7czo0MDoiODZ3ZEQya21rTU1ZVkZGeUYzWjJSVXdsYm10QTMya3VCZzVtQnVjNyI7czo2OiJsb2NhbGUiO3M6MjoiaWQiO3M6MTQ6Im1hcmtldF9zZWdtZW50IjtzOjU6ImxvY2FsIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo2MToiaHR0cHM6Ly9iaXptYXJrLmlkL2Jsb2cvYW1kYWwtdnMtdWtsLXVwbC1wYW5kdWFuLWxlbmdrYXAtMjAyNSI7czo1OiJyb3V0ZSI7czoxNToiYmxvZy5hcnRpY2xlLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1776229644
\.


--
-- TOC entry 5930 (class 0 OID 159237)
-- Dependencies: 411
-- Data for Name: shapefile_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shapefile_projects (id, user_id, name, geojson, area_m2, area_ha, perimeter_m, metadata, file_path, session_token, created_at, updated_at, company_name, contact_person, email, phone, agreed_terms_at, service_inquiry_id, ip_address, user_agent, rtrw_zona, rtrw_perda, rtrw_remark, rtrw_raw) FROM stdin;
\.


--
-- TOC entry 5932 (class 0 OID 159276)
-- Dependencies: 413
-- Data for Name: social_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_posts (id, article_id, platform, caption, platform_post_id, platform_url, status, posted_at, scheduled_for, metrics, error_message, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5804 (class 0 OID 157673)
-- Dependencies: 285
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, company_name, company_email, company_phone, company_website, company_address, maintenance_mode, email_notifications, created_at, updated_at) FROM stdin;
1	Bizmark.ID	cs@bizmark.id	0812-1234-5678	https://bizmark.id	Jl. Contoh No. 123, Jakarta	f	t	2026-04-15 12:04:07	2026-04-15 12:04:07
\.


--
-- TOC entry 5756 (class 0 OID 157017)
-- Dependencies: 237
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, project_id, title, description, sop_notes, assigned_user_id, due_date, started_at, completed_at, status, priority, institution_id, depends_on_task_id, completion_notes, estimated_hours, actual_hours, sort_order, created_at, updated_at, project_permit_id) FROM stdin;
\.


--
-- TOC entry 5810 (class 0 OID 157713)
-- Dependencies: 291
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_rates (id, name, rate, description, is_default, is_active, sort_order, created_at, updated_at) FROM stdin;
1	Tanpa Pajak	0.00	Digunakan untuk transaksi tanpa pajak.	f	t	0	2026-04-15 12:04:07	2026-04-15 12:04:07
2	PPN 11%	11.00	Tarif PPN nasional 11%.	t	t	10	2026-04-15 12:04:08	2026-04-15 12:04:08
3	PPH 23 2%	2.00	Potongan PPH 23 sebesar 2%.	f	t	20	2026-04-15 12:04:08	2026-04-15 12:04:08
\.


--
-- TOC entry 5884 (class 0 OID 158701)
-- Dependencies: 365
-- Data for Name: technical_test_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technical_test_submissions (id, job_application_id, test_title, test_description, original_file_path, submission_file_path, file_type, format_score, format_issues, reviewer_id, review_score, review_notes, reviewed_at, status, submitted_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5888 (class 0 OID 158753)
-- Dependencies: 369
-- Data for Name: test_answers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_answers (id, test_session_id, question_id, answer_data, is_correct, points_earned, time_spent_seconds, answered_at) FROM stdin;
\.


--
-- TOC entry 5886 (class 0 OID 158725)
-- Dependencies: 367
-- Data for Name: test_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_sessions (id, job_application_id, test_template_id, session_token, status, starts_at, expires_at, started_at, completed_at, score, passed, time_taken_minutes, ip_address, user_agent, tab_switches, created_at, updated_at, submitted_file_path, submitted_at, evaluation_scores, evaluator_id, evaluator_notes, evaluated_at, requires_manual_review, recruitment_stage_id, deleted_at) FROM stdin;
\.


--
-- TOC entry 5880 (class 0 OID 158664)
-- Dependencies: 361
-- Data for Name: test_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_templates (id, title, test_type, description, duration_minutes, passing_score, questions_data, instructions, is_active, created_by, created_at, updated_at, template_file_path, evaluation_criteria) FROM stdin;
\.


--
-- TOC entry 5912 (class 0 OID 159084)
-- Dependencies: 393
-- Data for Name: topic_clusters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.topic_clusters (id, pillar_title, pillar_slug, pillar_description, service_slug, language, subtopics, article_ids, keyword_cluster_ids, status, internal_links_built, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5938 (class 0 OID 159330)
-- Dependencies: 419
-- Data for Name: trending_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trending_topics (id, topic, category, language, data_source, trend_score, search_volume, related_keywords, top_sources, sample_headline, is_processed, article_id, discovered_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5739 (class 0 OID 156891)
-- Dependencies: 220
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, full_name, "position", phone, is_active, last_login_at, notes, avatar, role_id, company_email, department, email_signature, job_title, notification_preferences, working_hours, username, employee_id, bio, expertise, linkedin_url, twitter_url) FROM stdin;
2	hadez	hadez@bizmark.id	2026-04-15 12:04:39	$2y$12$Uz3qto9TtIbhZs9H6SBx8uaq1Cv7vh1d77gzohaEA0EeqOvsJgITG	\N	2026-04-15 12:04:39	2026-04-15 12:04:39	Hadez Administrator	System Administrator	6283879602855	t	\N	Administrator utama sistem	\N	1	\N	general	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	manager	manager@bizmark.id	2026-04-15 12:04:39	$2y$12$FF248QSA/ljQmFWAysBN8uAtZPiQ/P2J8eLF713HQNMgU.9qB8VAa	\N	2026-04-15 12:04:39	2026-04-15 12:04:39	Budi Santoso	Project Manager	0838796028551	t	\N	Manager proyek perizinan	\N	1	\N	general	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4	staff1	siti@bizmark.id	2026-04-15 12:04:39	$2y$12$Q792Q5cIoY..VuZ/5CmIS.NXi/QGwU/jO9frhwbg5kbIw6GQuGwkC	\N	2026-04-15 12:04:39	2026-04-15 12:04:39	Siti Aminah	Konsultan Senior	0838796028552	t	\N	Konsultan perizinan lingkungan	\N	4	\N	technical	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5	staff2	ahmad@bizmark.id	2026-04-15 12:04:39	$2y$12$NIE3oC2x1.OoKSApCUHH/eZ5PyqObtu3nbDYHNd2Bpa1u0qEyZASu	\N	2026-04-15 12:04:40	2026-04-15 12:04:40	Ahmad Fadli	Konsultan Junior	0838796028553	t	\N	Konsultan perizinan lalu lintas	\N	4	\N	technical	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	staff3	maya@bizmark.id	2026-04-15 12:04:39	$2y$12$duO7cbQjXf2T.1f3sYXsPe1skYex0px9Weoli89J4LeM3dcf1lgTG	\N	2026-04-15 12:04:40	2026-04-15 12:04:40	Maya Dewi	Document Controller	0838796028554	t	\N	Pengendali dokumen dan administrasi	\N	4	\N	support	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 6172 (class 0 OID 0)
-- Dependencies: 296
-- Name: ai_processing_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_processing_logs_id_seq', 1, false);


--
-- TOC entry 6173 (class 0 OID 0)
-- Dependencies: 338
-- Name: ai_query_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_query_logs_id_seq', 1, false);


--
-- TOC entry 6174 (class 0 OID 0)
-- Dependencies: 376
-- Name: ai_setting_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_setting_history_id_seq', 1, false);


--
-- TOC entry 6175 (class 0 OID 0)
-- Dependencies: 374
-- Name: ai_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_settings_id_seq', 1, false);


--
-- TOC entry 6176 (class 0 OID 0)
-- Dependencies: 322
-- Name: application_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_documents_id_seq', 1, false);


--
-- TOC entry 6177 (class 0 OID 0)
-- Dependencies: 346
-- Name: application_legality_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_legality_documents_id_seq', 1, false);


--
-- TOC entry 6178 (class 0 OID 0)
-- Dependencies: 344
-- Name: application_location_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_location_details_id_seq', 1, false);


--
-- TOC entry 6179 (class 0 OID 0)
-- Dependencies: 332
-- Name: application_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_notes_id_seq', 1, false);


--
-- TOC entry 6180 (class 0 OID 0)
-- Dependencies: 342
-- Name: application_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_revisions_id_seq', 1, false);


--
-- TOC entry 6181 (class 0 OID 0)
-- Dependencies: 326
-- Name: application_status_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.application_status_logs_id_seq', 1, false);


--
-- TOC entry 6182 (class 0 OID 0)
-- Dependencies: 386
-- Name: article_topic_similarities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_topic_similarities_id_seq', 1, false);


--
-- TOC entry 6183 (class 0 OID 0)
-- Dependencies: 378
-- Name: article_topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_topics_id_seq', 1, false);


--
-- TOC entry 6184 (class 0 OID 0)
-- Dependencies: 396
-- Name: article_view_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.article_view_logs_id_seq', 1, false);


--
-- TOC entry 6185 (class 0 OID 0)
-- Dependencies: 282
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.articles_id_seq', 5, true);


--
-- TOC entry 6186 (class 0 OID 0)
-- Dependencies: 380
-- Name: auto_post_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_post_configs_id_seq', 1, true);


--
-- TOC entry 6187 (class 0 OID 0)
-- Dependencies: 384
-- Name: auto_post_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_post_logs_id_seq', 1, false);


--
-- TOC entry 6188 (class 0 OID 0)
-- Dependencies: 382
-- Name: auto_post_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_post_schedules_id_seq', 1, false);


--
-- TOC entry 6189 (class 0 OID 0)
-- Dependencies: 278
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_reconciliations_id_seq', 1, false);


--
-- TOC entry 6190 (class 0 OID 0)
-- Dependencies: 280
-- Name: bank_statement_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_statement_entries_id_seq', 1, false);


--
-- TOC entry 6191 (class 0 OID 0)
-- Dependencies: 350
-- Name: business_contexts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.business_contexts_id_seq', 1, false);


--
-- TOC entry 6192 (class 0 OID 0)
-- Dependencies: 354
-- Name: cash_account_balance_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cash_account_balance_history_id_seq', 1, false);


--
-- TOC entry 6193 (class 0 OID 0)
-- Dependencies: 242
-- Name: cash_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cash_accounts_id_seq', 1, false);


--
-- TOC entry 6194 (class 0 OID 0)
-- Dependencies: 268
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clients_id_seq', 1, false);


--
-- TOC entry 6195 (class 0 OID 0)
-- Dependencies: 404
-- Name: competitor_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.competitor_analyses_id_seq', 1, false);


--
-- TOC entry 6196 (class 0 OID 0)
-- Dependencies: 300
-- Name: compliance_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.compliance_checks_id_seq', 1, false);


--
-- TOC entry 6197 (class 0 OID 0)
-- Dependencies: 372
-- Name: consult_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.consult_requests_id_seq', 1, false);


--
-- TOC entry 6198 (class 0 OID 0)
-- Dependencies: 394
-- Name: content_gaps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_gaps_id_seq', 1, false);


--
-- TOC entry 6199 (class 0 OID 0)
-- Dependencies: 402
-- Name: content_refresh_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_refresh_logs_id_seq', 1, false);


--
-- TOC entry 6200 (class 0 OID 0)
-- Dependencies: 388
-- Name: content_syndications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_syndications_id_seq', 1, false);


--
-- TOC entry 6201 (class 0 OID 0)
-- Dependencies: 298
-- Name: document_drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_drafts_id_seq', 1, false);


--
-- TOC entry 6202 (class 0 OID 0)
-- Dependencies: 294
-- Name: document_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_templates_id_seq', 1, false);


--
-- TOC entry 6203 (class 0 OID 0)
-- Dependencies: 238
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- TOC entry 6204 (class 0 OID 0)
-- Dependencies: 316
-- Name: email_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_accounts_id_seq', 1, false);


--
-- TOC entry 6205 (class 0 OID 0)
-- Dependencies: 318
-- Name: email_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_assignments_id_seq', 1, false);


--
-- TOC entry 6206 (class 0 OID 0)
-- Dependencies: 310
-- Name: email_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_campaigns_id_seq', 1, false);


--
-- TOC entry 6207 (class 0 OID 0)
-- Dependencies: 314
-- Name: email_inbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_inbox_id_seq', 1, false);


--
-- TOC entry 6208 (class 0 OID 0)
-- Dependencies: 312
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_logs_id_seq', 1, false);


--
-- TOC entry 6209 (class 0 OID 0)
-- Dependencies: 306
-- Name: email_subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_subscribers_id_seq', 1, false);


--
-- TOC entry 6210 (class 0 OID 0)
-- Dependencies: 308
-- Name: email_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_templates_id_seq', 1, false);


--
-- TOC entry 6211 (class 0 OID 0)
-- Dependencies: 286
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 29, true);


--
-- TOC entry 6212 (class 0 OID 0)
-- Dependencies: 228
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- TOC entry 6213 (class 0 OID 0)
-- Dependencies: 230
-- Name: institutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.institutions_id_seq', 6, true);


--
-- TOC entry 6214 (class 0 OID 0)
-- Dependencies: 358
-- Name: interview_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.interview_feedback_id_seq', 1, false);


--
-- TOC entry 6215 (class 0 OID 0)
-- Dependencies: 356
-- Name: interview_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.interview_schedules_id_seq', 1, false);


--
-- TOC entry 6216 (class 0 OID 0)
-- Dependencies: 262
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 1, false);


--
-- TOC entry 6217 (class 0 OID 0)
-- Dependencies: 260
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- TOC entry 6218 (class 0 OID 0)
-- Dependencies: 304
-- Name: job_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_applications_id_seq', 1, false);


--
-- TOC entry 6219 (class 0 OID 0)
-- Dependencies: 302
-- Name: job_vacancies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_vacancies_id_seq', 1, false);


--
-- TOC entry 6220 (class 0 OID 0)
-- Dependencies: 225
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- TOC entry 6221 (class 0 OID 0)
-- Dependencies: 334
-- Name: kbli_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kbli_id_seq', 1, true);


--
-- TOC entry 6222 (class 0 OID 0)
-- Dependencies: 336
-- Name: kbli_permit_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kbli_permit_recommendations_id_seq', 1, false);


--
-- TOC entry 6223 (class 0 OID 0)
-- Dependencies: 370
-- Name: kblis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kblis_id_seq', 1, false);


--
-- TOC entry 6224 (class 0 OID 0)
-- Dependencies: 390
-- Name: keyword_clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.keyword_clusters_id_seq', 1, false);


--
-- TOC entry 6225 (class 0 OID 0)
-- Dependencies: 414
-- Name: keyword_position_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.keyword_position_history_id_seq', 1, false);


--
-- TOC entry 6226 (class 0 OID 0)
-- Dependencies: 406
-- Name: meta_ab_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meta_ab_tests_id_seq', 1, false);


--
-- TOC entry 6227 (class 0 OID 0)
-- Dependencies: 217
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 148, true);


--
-- TOC entry 6228 (class 0 OID 0)
-- Dependencies: 276
-- Name: milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.milestones_id_seq', 1, false);


--
-- TOC entry 6229 (class 0 OID 0)
-- Dependencies: 328
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- TOC entry 6230 (class 0 OID 0)
-- Dependencies: 288
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 5, true);


--
-- TOC entry 6231 (class 0 OID 0)
-- Dependencies: 264
-- Name: payment_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_schedules_id_seq', 1, false);


--
-- TOC entry 6232 (class 0 OID 0)
-- Dependencies: 330
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- TOC entry 6233 (class 0 OID 0)
-- Dependencies: 274
-- Name: permission_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permission_role_id_seq', 114, true);


--
-- TOC entry 6234 (class 0 OID 0)
-- Dependencies: 272
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 60, true);


--
-- TOC entry 6235 (class 0 OID 0)
-- Dependencies: 320
-- Name: permit_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_applications_id_seq', 1, false);


--
-- TOC entry 6236 (class 0 OID 0)
-- Dependencies: 266
-- Name: permit_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_documents_id_seq', 1, false);


--
-- TOC entry 6237 (class 0 OID 0)
-- Dependencies: 254
-- Name: permit_template_dependencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_template_dependencies_id_seq', 1, false);


--
-- TOC entry 6238 (class 0 OID 0)
-- Dependencies: 252
-- Name: permit_template_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_template_items_id_seq', 1, false);


--
-- TOC entry 6239 (class 0 OID 0)
-- Dependencies: 250
-- Name: permit_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_templates_id_seq', 1, false);


--
-- TOC entry 6240 (class 0 OID 0)
-- Dependencies: 248
-- Name: permit_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permit_types_id_seq', 1, false);


--
-- TOC entry 6241 (class 0 OID 0)
-- Dependencies: 246
-- Name: project_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_expenses_id_seq', 1, false);


--
-- TOC entry 6242 (class 0 OID 0)
-- Dependencies: 240
-- Name: project_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_logs_id_seq', 1, false);


--
-- TOC entry 6243 (class 0 OID 0)
-- Dependencies: 244
-- Name: project_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_payments_id_seq', 1, false);


--
-- TOC entry 6244 (class 0 OID 0)
-- Dependencies: 258
-- Name: project_permit_dependencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_permit_dependencies_id_seq', 1, false);


--
-- TOC entry 6245 (class 0 OID 0)
-- Dependencies: 256
-- Name: project_permits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_permits_id_seq', 1, false);


--
-- TOC entry 6246 (class 0 OID 0)
-- Dependencies: 232
-- Name: project_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_statuses_id_seq', 13, true);


--
-- TOC entry 6247 (class 0 OID 0)
-- Dependencies: 234
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- TOC entry 6248 (class 0 OID 0)
-- Dependencies: 340
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 1, false);


--
-- TOC entry 6249 (class 0 OID 0)
-- Dependencies: 348
-- Name: quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotation_items_id_seq', 1, false);


--
-- TOC entry 6250 (class 0 OID 0)
-- Dependencies: 324
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, false);


--
-- TOC entry 6251 (class 0 OID 0)
-- Dependencies: 416
-- Name: ranking_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ranking_alerts_id_seq', 1, false);


--
-- TOC entry 6252 (class 0 OID 0)
-- Dependencies: 362
-- Name: recruitment_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recruitment_stages_id_seq', 1, false);


--
-- TOC entry 6253 (class 0 OID 0)
-- Dependencies: 270
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- TOC entry 6254 (class 0 OID 0)
-- Dependencies: 408
-- Name: search_console_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.search_console_data_id_seq', 1, false);


--
-- TOC entry 6255 (class 0 OID 0)
-- Dependencies: 292
-- Name: security_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.security_settings_id_seq', 1, true);


--
-- TOC entry 6256 (class 0 OID 0)
-- Dependencies: 400
-- Name: seo_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_reports_id_seq', 1, false);


--
-- TOC entry 6257 (class 0 OID 0)
-- Dependencies: 398
-- Name: seo_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_scores_id_seq', 1, false);


--
-- TOC entry 6258 (class 0 OID 0)
-- Dependencies: 352
-- Name: service_inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_inquiries_id_seq', 1, true);


--
-- TOC entry 6259 (class 0 OID 0)
-- Dependencies: 410
-- Name: shapefile_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shapefile_projects_id_seq', 1, false);


--
-- TOC entry 6260 (class 0 OID 0)
-- Dependencies: 412
-- Name: social_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_posts_id_seq', 1, false);


--
-- TOC entry 6261 (class 0 OID 0)
-- Dependencies: 284
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, true);


--
-- TOC entry 6262 (class 0 OID 0)
-- Dependencies: 236
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- TOC entry 6263 (class 0 OID 0)
-- Dependencies: 290
-- Name: tax_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tax_rates_id_seq', 3, true);


--
-- TOC entry 6264 (class 0 OID 0)
-- Dependencies: 364
-- Name: technical_test_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.technical_test_submissions_id_seq', 1, false);


--
-- TOC entry 6265 (class 0 OID 0)
-- Dependencies: 368
-- Name: test_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.test_answers_id_seq', 1, false);


--
-- TOC entry 6266 (class 0 OID 0)
-- Dependencies: 366
-- Name: test_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.test_sessions_id_seq', 1, false);


--
-- TOC entry 6267 (class 0 OID 0)
-- Dependencies: 360
-- Name: test_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.test_templates_id_seq', 1, false);


--
-- TOC entry 6268 (class 0 OID 0)
-- Dependencies: 392
-- Name: topic_clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.topic_clusters_id_seq', 1, false);


--
-- TOC entry 6269 (class 0 OID 0)
-- Dependencies: 418
-- Name: trending_topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trending_topics_id_seq', 1, false);


--
-- TOC entry 6270 (class 0 OID 0)
-- Dependencies: 219
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- TOC entry 5087 (class 2606 OID 157770)
-- Name: ai_processing_logs ai_processing_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5218 (class 2606 OID 158361)
-- Name: ai_query_logs ai_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5331 (class 2606 OID 158903)
-- Name: ai_setting_history ai_setting_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history
    ADD CONSTRAINT ai_setting_history_pkey PRIMARY KEY (id);


--
-- TOC entry 5324 (class 2606 OID 158893)
-- Name: ai_settings ai_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_key_unique UNIQUE (key);


--
-- TOC entry 5326 (class 2606 OID 158880)
-- Name: ai_settings ai_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 5171 (class 2606 OID 158175)
-- Name: application_documents application_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_pkey PRIMARY KEY (id);


--
-- TOC entry 5241 (class 2606 OID 158455)
-- Name: application_legality_documents application_legality_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_legality_documents
    ADD CONSTRAINT application_legality_documents_pkey PRIMARY KEY (id);


--
-- TOC entry 5232 (class 2606 OID 158444)
-- Name: application_location_details application_location_details_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details
    ADD CONSTRAINT application_location_details_application_id_unique UNIQUE (application_id);


--
-- TOC entry 5235 (class 2606 OID 158434)
-- Name: application_location_details application_location_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details
    ADD CONSTRAINT application_location_details_pkey PRIMARY KEY (id);


--
-- TOC entry 5196 (class 2606 OID 158306)
-- Name: application_notes application_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes
    ADD CONSTRAINT application_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 5228 (class 2606 OID 158410)
-- Name: application_revisions application_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions
    ADD CONSTRAINT application_revisions_pkey PRIMARY KEY (id);


--
-- TOC entry 5181 (class 2606 OID 158230)
-- Name: application_status_logs application_status_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_status_logs
    ADD CONSTRAINT application_status_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5354 (class 2606 OID 159024)
-- Name: article_topic_similarities article_topic_similarities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_pkey PRIMARY KEY (id);


--
-- TOC entry 5357 (class 2606 OID 159036)
-- Name: article_topic_similarities article_topic_similarities_topic_a_id_topic_b_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_topic_a_id_topic_b_id_unique UNIQUE (topic_a_id, topic_b_id);


--
-- TOC entry 5335 (class 2606 OID 158930)
-- Name: article_topics article_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_pkey PRIMARY KEY (id);


--
-- TOC entry 5338 (class 2606 OID 158942)
-- Name: article_topics article_topics_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_slug_unique UNIQUE (slug);


--
-- TOC entry 5342 (class 2606 OID 158940)
-- Name: article_topics article_topics_title_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_title_unique UNIQUE (title);


--
-- TOC entry 5379 (class 2606 OID 159139)
-- Name: article_view_logs article_view_logs_article_id_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs
    ADD CONSTRAINT article_view_logs_article_id_date_unique UNIQUE (article_id, date);


--
-- TOC entry 5382 (class 2606 OID 159132)
-- Name: article_view_logs article_view_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs
    ADD CONSTRAINT article_view_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5061 (class 2606 OID 157655)
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- TOC entry 5063 (class 2606 OID 157666)
-- Name: articles articles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_unique UNIQUE (slug);


--
-- TOC entry 5344 (class 2606 OID 158970)
-- Name: auto_post_configs auto_post_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_configs
    ADD CONSTRAINT auto_post_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 5352 (class 2606 OID 159000)
-- Name: auto_post_logs auto_post_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5346 (class 2606 OID 158982)
-- Name: auto_post_schedules auto_post_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules
    ADD CONSTRAINT auto_post_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 5049 (class 2606 OID 157577)
-- Name: bank_reconciliations bank_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_pkey PRIMARY KEY (id);


--
-- TOC entry 5054 (class 2606 OID 157615)
-- Name: bank_statement_entries bank_statement_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_entries
    ADD CONSTRAINT bank_statement_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 5251 (class 2606 OID 158517)
-- Name: business_contexts business_contexts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts
    ADD CONSTRAINT business_contexts_pkey PRIMARY KEY (id);


--
-- TOC entry 4934 (class 2606 OID 156930)
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- TOC entry 4932 (class 2606 OID 156923)
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- TOC entry 5266 (class 2606 OID 158590)
-- Name: cash_account_balance_history cash_account_balance_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history
    ADD CONSTRAINT cash_account_balance_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4971 (class 2606 OID 157154)
-- Name: cash_accounts cash_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_accounts
    ADD CONSTRAINT cash_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 5028 (class 2606 OID 157862)
-- Name: clients clients_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_email_unique UNIQUE (email);


--
-- TOC entry 5031 (class 2606 OID 157487)
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- TOC entry 5397 (class 2606 OID 159195)
-- Name: competitor_analyses competitor_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_analyses
    ADD CONSTRAINT competitor_analyses_pkey PRIMARY KEY (id);


--
-- TOC entry 5098 (class 2606 OID 157852)
-- Name: compliance_checks compliance_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_pkey PRIMARY KEY (id);


--
-- TOC entry 5319 (class 2606 OID 158842)
-- Name: consult_requests consult_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 5375 (class 2606 OID 159111)
-- Name: content_gaps content_gaps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps
    ADD CONSTRAINT content_gaps_pkey PRIMARY KEY (id);


--
-- TOC entry 5392 (class 2606 OID 159179)
-- Name: content_refresh_logs content_refresh_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_refresh_logs
    ADD CONSTRAINT content_refresh_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5360 (class 2606 OID 159049)
-- Name: content_syndications content_syndications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_syndications
    ADD CONSTRAINT content_syndications_pkey PRIMARY KEY (id);


--
-- TOC entry 5091 (class 2606 OID 157804)
-- Name: document_drafts document_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_pkey PRIMARY KEY (id);


--
-- TOC entry 5084 (class 2606 OID 157751)
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4960 (class 2606 OID 157067)
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- TOC entry 5151 (class 2606 OID 158051)
-- Name: email_accounts email_accounts_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_accounts
    ADD CONSTRAINT email_accounts_email_unique UNIQUE (email);


--
-- TOC entry 5154 (class 2606 OID 158047)
-- Name: email_accounts email_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_accounts
    ADD CONSTRAINT email_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 5157 (class 2606 OID 158088)
-- Name: email_assignments email_assignments_email_account_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_email_account_id_user_id_unique UNIQUE (email_account_id, user_id);


--
-- TOC entry 5159 (class 2606 OID 158071)
-- Name: email_assignments email_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 5124 (class 2606 OID 157957)
-- Name: email_campaigns email_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 5142 (class 2606 OID 158028)
-- Name: email_inbox email_inbox_message_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_message_id_unique UNIQUE (message_id);


--
-- TOC entry 5144 (class 2606 OID 158011)
-- Name: email_inbox email_inbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_pkey PRIMARY KEY (id);


--
-- TOC entry 5129 (class 2606 OID 157981)
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5134 (class 2606 OID 157997)
-- Name: email_logs email_logs_tracking_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_tracking_id_unique UNIQUE (tracking_id);


--
-- TOC entry 5115 (class 2606 OID 157924)
-- Name: email_subscribers email_subscribers_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_subscribers
    ADD CONSTRAINT email_subscribers_email_unique UNIQUE (email);


--
-- TOC entry 5117 (class 2606 OID 157920)
-- Name: email_subscribers email_subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_subscribers
    ADD CONSTRAINT email_subscribers_pkey PRIMARY KEY (id);


--
-- TOC entry 5122 (class 2606 OID 157936)
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 5070 (class 2606 OID 157694)
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 5072 (class 2606 OID 157696)
-- Name: expense_categories expense_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_slug_unique UNIQUE (slug);


--
-- TOC entry 4941 (class 2606 OID 156957)
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 4943 (class 2606 OID 156959)
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- TOC entry 4945 (class 2606 OID 156969)
-- Name: institutions institutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_pkey PRIMARY KEY (id);


--
-- TOC entry 5275 (class 2606 OID 158650)
-- Name: interview_feedback interview_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT interview_feedback_pkey PRIMARY KEY (id);


--
-- TOC entry 5270 (class 2606 OID 158627)
-- Name: interview_schedules interview_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 5015 (class 2606 OID 157417)
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- TOC entry 5008 (class 2606 OID 157406)
-- Name: invoices invoices_invoice_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_unique UNIQUE (invoice_number);


--
-- TOC entry 5010 (class 2606 OID 157395)
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- TOC entry 5109 (class 2606 OID 157893)
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (id);


--
-- TOC entry 4939 (class 2606 OID 156947)
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- TOC entry 5102 (class 2606 OID 157877)
-- Name: job_vacancies job_vacancies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_vacancies
    ADD CONSTRAINT job_vacancies_pkey PRIMARY KEY (id);


--
-- TOC entry 5104 (class 2606 OID 157881)
-- Name: job_vacancies job_vacancies_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_vacancies
    ADD CONSTRAINT job_vacancies_slug_unique UNIQUE (slug);


--
-- TOC entry 4936 (class 2606 OID 156939)
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 5200 (class 2606 OID 158332)
-- Name: kbli kbli_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli
    ADD CONSTRAINT kbli_code_unique UNIQUE (code);


--
-- TOC entry 5212 (class 2606 OID 158342)
-- Name: kbli_permit_recommendations kbli_permit_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli_permit_recommendations
    ADD CONSTRAINT kbli_permit_recommendations_pkey PRIMARY KEY (id);


--
-- TOC entry 5205 (class 2606 OID 158326)
-- Name: kbli kbli_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli
    ADD CONSTRAINT kbli_pkey PRIMARY KEY (id);


--
-- TOC entry 5305 (class 2606 OID 158810)
-- Name: kblis kblis_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kblis
    ADD CONSTRAINT kblis_code_unique UNIQUE (code);


--
-- TOC entry 5309 (class 2606 OID 158808)
-- Name: kblis kblis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kblis
    ADD CONSTRAINT kblis_pkey PRIMARY KEY (id);


--
-- TOC entry 5364 (class 2606 OID 159078)
-- Name: keyword_clusters keyword_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_clusters
    ADD CONSTRAINT keyword_clusters_pkey PRIMARY KEY (id);


--
-- TOC entry 5419 (class 2606 OID 159303)
-- Name: keyword_position_history keyword_position_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_position_history
    ADD CONSTRAINT keyword_position_history_pkey PRIMARY KEY (id);


--
-- TOC entry 5400 (class 2606 OID 159211)
-- Name: meta_ab_tests meta_ab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_ab_tests
    ADD CONSTRAINT meta_ab_tests_pkey PRIMARY KEY (id);


--
-- TOC entry 4916 (class 2606 OID 156889)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 5046 (class 2606 OID 157561)
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- TOC entry 5184 (class 2606 OID 158246)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 4926 (class 2606 OID 156907)
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- TOC entry 5074 (class 2606 OID 157711)
-- Name: payment_methods payment_methods_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_code_unique UNIQUE (code);


--
-- TOC entry 5076 (class 2606 OID 157709)
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- TOC entry 5020 (class 2606 OID 157434)
-- Name: payment_schedules payment_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 5190 (class 2606 OID 158282)
-- Name: payments payments_payment_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_number_unique UNIQUE (payment_number);


--
-- TOC entry 5192 (class 2606 OID 158262)
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- TOC entry 5042 (class 2606 OID 157542)
-- Name: permission_role permission_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_pkey PRIMARY KEY (id);


--
-- TOC entry 5044 (class 2606 OID 157554)
-- Name: permission_role permission_role_role_id_permission_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_role_id_permission_id_unique UNIQUE (role_id, permission_id);


--
-- TOC entry 5038 (class 2606 OID 157535)
-- Name: permissions permissions_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_unique UNIQUE (name);


--
-- TOC entry 5040 (class 2606 OID 157533)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 5162 (class 2606 OID 158164)
-- Name: permit_applications permit_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_application_number_unique UNIQUE (application_number);


--
-- TOC entry 5165 (class 2606 OID 158139)
-- Name: permit_applications permit_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_pkey PRIMARY KEY (id);


--
-- TOC entry 5024 (class 2606 OID 157457)
-- Name: permit_documents permit_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents
    ADD CONSTRAINT permit_documents_pkey PRIMARY KEY (id);


--
-- TOC entry 4994 (class 2606 OID 157291)
-- Name: permit_template_dependencies permit_template_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_pkey PRIMARY KEY (id);


--
-- TOC entry 4991 (class 2606 OID 157269)
-- Name: permit_template_items permit_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items
    ADD CONSTRAINT permit_template_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4989 (class 2606 OID 157251)
-- Name: permit_templates permit_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_templates
    ADD CONSTRAINT permit_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4982 (class 2606 OID 157240)
-- Name: permit_types permit_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types
    ADD CONSTRAINT permit_types_code_unique UNIQUE (code);


--
-- TOC entry 4985 (class 2606 OID 157231)
-- Name: permit_types permit_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types
    ADD CONSTRAINT permit_types_pkey PRIMARY KEY (id);


--
-- TOC entry 4978 (class 2606 OID 157198)
-- Name: project_expenses project_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_pkey PRIMARY KEY (id);


--
-- TOC entry 4966 (class 2606 OID 157099)
-- Name: project_logs project_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs
    ADD CONSTRAINT project_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4974 (class 2606 OID 157168)
-- Name: project_payments project_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 5001 (class 2606 OID 157378)
-- Name: project_permit_dependencies project_permit_dep_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dep_unique UNIQUE (project_permit_id, depends_on_permit_id);


--
-- TOC entry 5003 (class 2606 OID 157355)
-- Name: project_permit_dependencies project_permit_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_pkey PRIMARY KEY (id);


--
-- TOC entry 4997 (class 2606 OID 157321)
-- Name: project_permits project_permits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_pkey PRIMARY KEY (id);


--
-- TOC entry 4947 (class 2606 OID 156984)
-- Name: project_statuses project_statuses_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT project_statuses_code_unique UNIQUE (code);


--
-- TOC entry 4949 (class 2606 OID 156982)
-- Name: project_statuses project_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT project_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4952 (class 2606 OID 156995)
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- TOC entry 5221 (class 2606 OID 158392)
-- Name: push_subscriptions push_subscriptions_endpoint_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_unique UNIQUE (endpoint);


--
-- TOC entry 5223 (class 2606 OID 158389)
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 5246 (class 2606 OID 158479)
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- TOC entry 5175 (class 2606 OID 158201)
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- TOC entry 5177 (class 2606 OID 158220)
-- Name: quotations quotations_quotation_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_quotation_number_unique UNIQUE (quotation_number);


--
-- TOC entry 5427 (class 2606 OID 159319)
-- Name: ranking_alerts ranking_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranking_alerts
    ADD CONSTRAINT ranking_alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 5283 (class 2606 OID 158690)
-- Name: recruitment_stages recruitment_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages
    ADD CONSTRAINT recruitment_stages_pkey PRIMARY KEY (id);


--
-- TOC entry 5034 (class 2606 OID 157524)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 5036 (class 2606 OID 157522)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 5403 (class 2606 OID 159232)
-- Name: search_console_data search_console_data_page_url_query_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_console_data
    ADD CONSTRAINT search_console_data_page_url_query_date_unique UNIQUE (page_url, query, date);


--
-- TOC entry 5405 (class 2606 OID 159230)
-- Name: search_console_data search_console_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_console_data
    ADD CONSTRAINT search_console_data_pkey PRIMARY KEY (id);


--
-- TOC entry 5080 (class 2606 OID 157740)
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 5389 (class 2606 OID 159167)
-- Name: seo_reports seo_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_reports
    ADD CONSTRAINT seo_reports_pkey PRIMARY KEY (id);


--
-- TOC entry 5384 (class 2606 OID 159157)
-- Name: seo_scores seo_scores_article_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores
    ADD CONSTRAINT seo_scores_article_id_unique UNIQUE (article_id);


--
-- TOC entry 5386 (class 2606 OID 159150)
-- Name: seo_scores seo_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores
    ADD CONSTRAINT seo_scores_pkey PRIMARY KEY (id);


--
-- TOC entry 5256 (class 2606 OID 158571)
-- Name: service_inquiries service_inquiries_inquiry_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_inquiry_number_unique UNIQUE (inquiry_number);


--
-- TOC entry 5258 (class 2606 OID 158552)
-- Name: service_inquiries service_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_pkey PRIMARY KEY (id);


--
-- TOC entry 4929 (class 2606 OID 156914)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 5409 (class 2606 OID 159247)
-- Name: shapefile_projects shapefile_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects
    ADD CONSTRAINT shapefile_projects_pkey PRIMARY KEY (id);


--
-- TOC entry 5413 (class 2606 OID 159284)
-- Name: social_posts social_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_posts
    ADD CONSTRAINT social_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 5068 (class 2606 OID 157682)
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4956 (class 2606 OID 157029)
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- TOC entry 5078 (class 2606 OID 157723)
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- TOC entry 5289 (class 2606 OID 158711)
-- Name: technical_test_submissions technical_test_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions
    ADD CONSTRAINT technical_test_submissions_pkey PRIMARY KEY (id);


--
-- TOC entry 5300 (class 2606 OID 158761)
-- Name: test_answers test_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_answers
    ADD CONSTRAINT test_answers_pkey PRIMARY KEY (id);


--
-- TOC entry 5293 (class 2606 OID 158736)
-- Name: test_sessions test_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 5297 (class 2606 OID 158751)
-- Name: test_sessions test_sessions_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_session_token_unique UNIQUE (session_token);


--
-- TOC entry 5279 (class 2606 OID 158673)
-- Name: test_templates test_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_templates
    ADD CONSTRAINT test_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 5369 (class 2606 OID 159098)
-- Name: topic_clusters topic_clusters_pillar_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topic_clusters
    ADD CONSTRAINT topic_clusters_pillar_slug_unique UNIQUE (pillar_slug);


--
-- TOC entry 5371 (class 2606 OID 159094)
-- Name: topic_clusters topic_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topic_clusters
    ADD CONSTRAINT topic_clusters_pkey PRIMARY KEY (id);


--
-- TOC entry 5432 (class 2606 OID 159342)
-- Name: trending_topics trending_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trending_topics
    ADD CONSTRAINT trending_topics_pkey PRIMARY KEY (id);


--
-- TOC entry 5112 (class 2606 OID 157908)
-- Name: job_applications unique_email_per_job; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT unique_email_per_job UNIQUE (job_vacancy_id, email);


--
-- TOC entry 5277 (class 2606 OID 158662)
-- Name: interview_feedback unique_feedback; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT unique_feedback UNIQUE (interview_schedule_id, interviewer_id);


--
-- TOC entry 5286 (class 2606 OID 158697)
-- Name: recruitment_stages unique_stage; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages
    ADD CONSTRAINT unique_stage UNIQUE (job_application_id, stage_name);


--
-- TOC entry 4918 (class 2606 OID 156900)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 4920 (class 2606 OID 158115)
-- Name: users users_employee_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_id_unique UNIQUE (employee_id);


--
-- TOC entry 4922 (class 2606 OID 156898)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4924 (class 2606 OID 158113)
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- TOC entry 5085 (class 1259 OID 157793)
-- Name: ai_processing_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_processing_logs_created_at_index ON public.ai_processing_logs USING btree (created_at);


--
-- TOC entry 5088 (class 1259 OID 157792)
-- Name: ai_processing_logs_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_processing_logs_project_id_index ON public.ai_processing_logs USING btree (project_id);


--
-- TOC entry 5089 (class 1259 OID 157791)
-- Name: ai_processing_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_processing_logs_status_index ON public.ai_processing_logs USING btree (status);


--
-- TOC entry 5214 (class 1259 OID 158367)
-- Name: ai_query_logs_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_client_id_index ON public.ai_query_logs USING btree (client_id);


--
-- TOC entry 5215 (class 1259 OID 158369)
-- Name: ai_query_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_created_at_index ON public.ai_query_logs USING btree (created_at);


--
-- TOC entry 5216 (class 1259 OID 158368)
-- Name: ai_query_logs_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_kbli_code_index ON public.ai_query_logs USING btree (kbli_code);


--
-- TOC entry 5219 (class 1259 OID 158370)
-- Name: ai_query_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_query_logs_status_index ON public.ai_query_logs USING btree (status);


--
-- TOC entry 5327 (class 1259 OID 158915)
-- Name: ai_setting_history_changed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_changed_by_index ON public.ai_setting_history USING btree (changed_by);


--
-- TOC entry 5328 (class 1259 OID 158916)
-- Name: ai_setting_history_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_created_at_index ON public.ai_setting_history USING btree (created_at);


--
-- TOC entry 5329 (class 1259 OID 158917)
-- Name: ai_setting_history_key_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_key_index ON public.ai_setting_history USING btree (key);


--
-- TOC entry 5332 (class 1259 OID 158914)
-- Name: ai_setting_history_setting_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_setting_history_setting_id_index ON public.ai_setting_history USING btree (setting_id);


--
-- TOC entry 5321 (class 1259 OID 158891)
-- Name: ai_settings_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_settings_category_index ON public.ai_settings USING btree (category);


--
-- TOC entry 5322 (class 1259 OID 158894)
-- Name: ai_settings_group_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_settings_group_name_index ON public.ai_settings USING btree (group_name);


--
-- TOC entry 5168 (class 1259 OID 158186)
-- Name: application_documents_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_documents_application_id_index ON public.application_documents USING btree (application_id);


--
-- TOC entry 5169 (class 1259 OID 158187)
-- Name: application_documents_document_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_documents_document_type_index ON public.application_documents USING btree (document_type);


--
-- TOC entry 5237 (class 1259 OID 158461)
-- Name: application_legality_documents_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_legality_documents_application_id_index ON public.application_legality_documents USING btree (application_id);


--
-- TOC entry 5238 (class 1259 OID 158462)
-- Name: application_legality_documents_document_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_legality_documents_document_category_index ON public.application_legality_documents USING btree (document_category);


--
-- TOC entry 5239 (class 1259 OID 158463)
-- Name: application_legality_documents_is_available_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_legality_documents_is_available_index ON public.application_legality_documents USING btree (is_available);


--
-- TOC entry 5230 (class 1259 OID 158440)
-- Name: application_location_details_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_location_details_application_id_index ON public.application_location_details USING btree (application_id);


--
-- TOC entry 5233 (class 1259 OID 158442)
-- Name: application_location_details_city_regency_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_location_details_city_regency_index ON public.application_location_details USING btree (city_regency);


--
-- TOC entry 5236 (class 1259 OID 158441)
-- Name: application_location_details_province_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_location_details_province_index ON public.application_location_details USING btree (province);


--
-- TOC entry 5194 (class 1259 OID 158317)
-- Name: application_notes_application_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_notes_application_id_created_at_index ON public.application_notes USING btree (application_id, created_at);


--
-- TOC entry 5225 (class 1259 OID 158421)
-- Name: application_revisions_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_revisions_application_id_index ON public.application_revisions USING btree (application_id);


--
-- TOC entry 5226 (class 1259 OID 158422)
-- Name: application_revisions_application_id_revision_number_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_revisions_application_id_revision_number_index ON public.application_revisions USING btree (application_id, revision_number);


--
-- TOC entry 5229 (class 1259 OID 158423)
-- Name: application_revisions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_revisions_status_index ON public.application_revisions USING btree (status);


--
-- TOC entry 5178 (class 1259 OID 158236)
-- Name: application_status_logs_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_status_logs_application_id_index ON public.application_status_logs USING btree (application_id);


--
-- TOC entry 5179 (class 1259 OID 158237)
-- Name: application_status_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_status_logs_created_at_index ON public.application_status_logs USING btree (created_at);


--
-- TOC entry 5355 (class 1259 OID 159037)
-- Name: article_topic_similarities_similarity_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topic_similarities_similarity_score_index ON public.article_topic_similarities USING btree (similarity_score);


--
-- TOC entry 5333 (class 1259 OID 158937)
-- Name: article_topics_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_category_index ON public.article_topics USING btree (category);


--
-- TOC entry 5336 (class 1259 OID 158938)
-- Name: article_topics_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_scheduled_for_index ON public.article_topics USING btree (scheduled_for);


--
-- TOC entry 5339 (class 1259 OID 159060)
-- Name: article_topics_status_language_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_status_language_priority_index ON public.article_topics USING btree (status, language, priority);


--
-- TOC entry 5340 (class 1259 OID 158936)
-- Name: article_topics_status_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_topics_status_priority_index ON public.article_topics USING btree (status, priority);


--
-- TOC entry 5380 (class 1259 OID 159140)
-- Name: article_view_logs_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX article_view_logs_date_index ON public.article_view_logs USING btree (date);


--
-- TOC entry 5057 (class 1259 OID 157662)
-- Name: articles_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_category_index ON public.articles USING btree (category);


--
-- TOC entry 5058 (class 1259 OID 157663)
-- Name: articles_is_featured_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_is_featured_index ON public.articles USING btree (is_featured);


--
-- TOC entry 5059 (class 1259 OID 159062)
-- Name: articles_language_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_language_index ON public.articles USING btree (language);


--
-- TOC entry 5064 (class 1259 OID 159039)
-- Name: articles_source_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_source_type_index ON public.articles USING btree (source_type);


--
-- TOC entry 5065 (class 1259 OID 157661)
-- Name: articles_status_published_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_status_published_at_index ON public.articles USING btree (status, published_at);


--
-- TOC entry 5066 (class 1259 OID 157664)
-- Name: articles_title_content_fulltext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX articles_title_content_fulltext ON public.articles USING gin (((to_tsvector('english'::regconfig, (title)::text) || to_tsvector('english'::regconfig, content))));


--
-- TOC entry 5349 (class 1259 OID 159016)
-- Name: auto_post_logs_created_at_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_logs_created_at_level_index ON public.auto_post_logs USING btree (created_at, level);


--
-- TOC entry 5350 (class 1259 OID 159017)
-- Name: auto_post_logs_event_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_logs_event_index ON public.auto_post_logs USING btree (event);


--
-- TOC entry 5347 (class 1259 OID 158988)
-- Name: auto_post_schedules_scheduled_at_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_schedules_scheduled_at_status_index ON public.auto_post_schedules USING btree (scheduled_at, status);


--
-- TOC entry 5348 (class 1259 OID 158989)
-- Name: auto_post_schedules_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_post_schedules_status_index ON public.auto_post_schedules USING btree (status);


--
-- TOC entry 5047 (class 1259 OID 157598)
-- Name: bank_reconciliations_cash_account_id_reconciliation_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_reconciliations_cash_account_id_reconciliation_date_index ON public.bank_reconciliations USING btree (cash_account_id, reconciliation_date);


--
-- TOC entry 5050 (class 1259 OID 157600)
-- Name: bank_reconciliations_start_date_end_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_reconciliations_start_date_end_date_index ON public.bank_reconciliations USING btree (start_date, end_date);


--
-- TOC entry 5051 (class 1259 OID 157599)
-- Name: bank_reconciliations_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_reconciliations_status_index ON public.bank_reconciliations USING btree (status);


--
-- TOC entry 5052 (class 1259 OID 157623)
-- Name: bank_statement_entries_is_matched_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_entries_is_matched_index ON public.bank_statement_entries USING btree (is_matched);


--
-- TOC entry 5055 (class 1259 OID 157621)
-- Name: bank_statement_entries_reconciliation_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_entries_reconciliation_id_index ON public.bank_statement_entries USING btree (reconciliation_id);


--
-- TOC entry 5056 (class 1259 OID 157622)
-- Name: bank_statement_entries_transaction_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_entries_transaction_date_index ON public.bank_statement_entries USING btree (transaction_date);


--
-- TOC entry 5248 (class 1259 OID 158529)
-- Name: business_contexts_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX business_contexts_client_id_index ON public.business_contexts USING btree (client_id);


--
-- TOC entry 5249 (class 1259 OID 158528)
-- Name: business_contexts_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX business_contexts_kbli_code_index ON public.business_contexts USING btree (kbli_code);


--
-- TOC entry 5252 (class 1259 OID 158530)
-- Name: business_contexts_submitted_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX business_contexts_submitted_at_index ON public.business_contexts USING btree (submitted_at);


--
-- TOC entry 5262 (class 1259 OID 158601)
-- Name: cash_account_balance_history_cash_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_cash_account_id_index ON public.cash_account_balance_history USING btree (cash_account_id);


--
-- TOC entry 5263 (class 1259 OID 158604)
-- Name: cash_account_balance_history_change_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_change_type_index ON public.cash_account_balance_history USING btree (change_type);


--
-- TOC entry 5264 (class 1259 OID 158602)
-- Name: cash_account_balance_history_changed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_changed_at_index ON public.cash_account_balance_history USING btree (changed_at);


--
-- TOC entry 5267 (class 1259 OID 158603)
-- Name: cash_account_balance_history_reference_type_reference_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_account_balance_history_reference_type_reference_id_index ON public.cash_account_balance_history USING btree (reference_type, reference_id);


--
-- TOC entry 4969 (class 1259 OID 157155)
-- Name: cash_accounts_account_type_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_accounts_account_type_is_active_index ON public.cash_accounts USING btree (account_type, is_active);


--
-- TOC entry 5026 (class 1259 OID 157489)
-- Name: clients_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clients_email_index ON public.clients USING btree (email);


--
-- TOC entry 5029 (class 1259 OID 157488)
-- Name: clients_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clients_name_index ON public.clients USING btree (name);


--
-- TOC entry 5032 (class 1259 OID 157490)
-- Name: clients_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clients_status_index ON public.clients USING btree (status);


--
-- TOC entry 5394 (class 1259 OID 159197)
-- Name: competitor_analyses_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX competitor_analyses_analyzed_at_index ON public.competitor_analyses USING btree (analyzed_at);


--
-- TOC entry 5395 (class 1259 OID 159196)
-- Name: competitor_analyses_keyword_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX competitor_analyses_keyword_index ON public.competitor_analyses USING btree (keyword);


--
-- TOC entry 5095 (class 1259 OID 157858)
-- Name: compliance_checks_draft_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compliance_checks_draft_id_index ON public.compliance_checks USING btree (draft_id);


--
-- TOC entry 5096 (class 1259 OID 157860)
-- Name: compliance_checks_overall_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compliance_checks_overall_score_index ON public.compliance_checks USING btree (overall_score);


--
-- TOC entry 5099 (class 1259 OID 157859)
-- Name: compliance_checks_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compliance_checks_status_index ON public.compliance_checks USING btree (status);


--
-- TOC entry 5310 (class 1259 OID 158862)
-- Name: consult_requests_business_size_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_business_size_index ON public.consult_requests USING btree (business_size);


--
-- TOC entry 5311 (class 1259 OID 158863)
-- Name: consult_requests_contacted_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_contacted_index ON public.consult_requests USING btree (contacted);


--
-- TOC entry 5312 (class 1259 OID 158864)
-- Name: consult_requests_converted_to_client_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_converted_to_client_index ON public.consult_requests USING btree (converted_to_client);


--
-- TOC entry 5313 (class 1259 OID 158865)
-- Name: consult_requests_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_created_at_index ON public.consult_requests USING btree (created_at);


--
-- TOC entry 5314 (class 1259 OID 158858)
-- Name: consult_requests_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_email_index ON public.consult_requests USING btree (email);


--
-- TOC entry 5315 (class 1259 OID 158861)
-- Name: consult_requests_estimate_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_estimate_status_index ON public.consult_requests USING btree (estimate_status);


--
-- TOC entry 5316 (class 1259 OID 158860)
-- Name: consult_requests_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_kbli_code_index ON public.consult_requests USING btree (kbli_code);


--
-- TOC entry 5317 (class 1259 OID 158859)
-- Name: consult_requests_phone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_phone_index ON public.consult_requests USING btree (phone);


--
-- TOC entry 5320 (class 1259 OID 158866)
-- Name: consult_requests_rag_confidence_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consult_requests_rag_confidence_index ON public.consult_requests USING btree (rag_confidence);


--
-- TOC entry 5376 (class 1259 OID 159123)
-- Name: content_gaps_service_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_gaps_service_slug_index ON public.content_gaps USING btree (service_slug);


--
-- TOC entry 5377 (class 1259 OID 159122)
-- Name: content_gaps_status_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_gaps_status_priority_index ON public.content_gaps USING btree (status, priority);


--
-- TOC entry 5390 (class 1259 OID 159185)
-- Name: content_refresh_logs_article_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_refresh_logs_article_id_created_at_index ON public.content_refresh_logs USING btree (article_id, created_at);


--
-- TOC entry 5393 (class 1259 OID 159186)
-- Name: content_refresh_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_refresh_logs_status_index ON public.content_refresh_logs USING btree (status);


--
-- TOC entry 5358 (class 1259 OID 159055)
-- Name: content_syndications_article_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_syndications_article_id_status_index ON public.content_syndications USING btree (article_id, status);


--
-- TOC entry 5361 (class 1259 OID 159056)
-- Name: content_syndications_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX content_syndications_platform_index ON public.content_syndications USING btree (platform);


--
-- TOC entry 5092 (class 1259 OID 157831)
-- Name: document_drafts_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_drafts_project_id_index ON public.document_drafts USING btree (project_id);


--
-- TOC entry 5093 (class 1259 OID 157832)
-- Name: document_drafts_project_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_drafts_project_id_status_index ON public.document_drafts USING btree (project_id, status);


--
-- TOC entry 5094 (class 1259 OID 157830)
-- Name: document_drafts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_drafts_status_index ON public.document_drafts USING btree (status);


--
-- TOC entry 5081 (class 1259 OID 157758)
-- Name: document_templates_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_templates_is_active_index ON public.document_templates USING btree (is_active);


--
-- TOC entry 5082 (class 1259 OID 157757)
-- Name: document_templates_permit_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_templates_permit_type_index ON public.document_templates USING btree (permit_type);


--
-- TOC entry 4961 (class 1259 OID 157088)
-- Name: documents_project_id_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_project_id_category_index ON public.documents USING btree (project_id, category);


--
-- TOC entry 4962 (class 1259 OID 157089)
-- Name: documents_status_is_latest_version_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_status_is_latest_version_index ON public.documents USING btree (status, is_latest_version);


--
-- TOC entry 4963 (class 1259 OID 157090)
-- Name: documents_uploaded_by_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_uploaded_by_created_at_index ON public.documents USING btree (uploaded_by, created_at);


--
-- TOC entry 5149 (class 1259 OID 158048)
-- Name: email_accounts_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_accounts_email_index ON public.email_accounts USING btree (email);


--
-- TOC entry 5152 (class 1259 OID 158049)
-- Name: email_accounts_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_accounts_is_active_index ON public.email_accounts USING btree (is_active);


--
-- TOC entry 5155 (class 1259 OID 158089)
-- Name: email_assignments_email_account_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_assignments_email_account_id_is_active_index ON public.email_assignments USING btree (email_account_id, is_active);


--
-- TOC entry 5160 (class 1259 OID 158090)
-- Name: email_assignments_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_assignments_user_id_is_active_index ON public.email_assignments USING btree (user_id, is_active);


--
-- TOC entry 5125 (class 1259 OID 157969)
-- Name: email_campaigns_scheduled_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_campaigns_scheduled_at_index ON public.email_campaigns USING btree (scheduled_at);


--
-- TOC entry 5126 (class 1259 OID 157968)
-- Name: email_campaigns_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_campaigns_status_index ON public.email_campaigns USING btree (status);


--
-- TOC entry 5135 (class 1259 OID 158111)
-- Name: email_inbox_assigned_to_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_assigned_to_is_read_index ON public.email_inbox USING btree (assigned_to, is_read);


--
-- TOC entry 5136 (class 1259 OID 158025)
-- Name: email_inbox_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_category_index ON public.email_inbox USING btree (category);


--
-- TOC entry 5137 (class 1259 OID 158108)
-- Name: email_inbox_department_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_department_index ON public.email_inbox USING btree (department);


--
-- TOC entry 5138 (class 1259 OID 158107)
-- Name: email_inbox_email_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_email_account_id_index ON public.email_inbox USING btree (email_account_id);


--
-- TOC entry 5139 (class 1259 OID 158022)
-- Name: email_inbox_from_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_from_email_index ON public.email_inbox USING btree (from_email);


--
-- TOC entry 5140 (class 1259 OID 158024)
-- Name: email_inbox_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_is_read_index ON public.email_inbox USING btree (is_read);


--
-- TOC entry 5145 (class 1259 OID 158110)
-- Name: email_inbox_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_priority_index ON public.email_inbox USING btree (priority);


--
-- TOC entry 5146 (class 1259 OID 158026)
-- Name: email_inbox_received_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_received_at_index ON public.email_inbox USING btree (received_at);


--
-- TOC entry 5147 (class 1259 OID 158109)
-- Name: email_inbox_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_status_index ON public.email_inbox USING btree (status);


--
-- TOC entry 5148 (class 1259 OID 158023)
-- Name: email_inbox_to_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_inbox_to_email_index ON public.email_inbox USING btree (to_email);


--
-- TOC entry 5127 (class 1259 OID 157992)
-- Name: email_logs_campaign_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_campaign_id_index ON public.email_logs USING btree (campaign_id);


--
-- TOC entry 5130 (class 1259 OID 157994)
-- Name: email_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_status_index ON public.email_logs USING btree (status);


--
-- TOC entry 5131 (class 1259 OID 157993)
-- Name: email_logs_subscriber_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_subscriber_id_index ON public.email_logs USING btree (subscriber_id);


--
-- TOC entry 5132 (class 1259 OID 157995)
-- Name: email_logs_tracking_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_tracking_id_index ON public.email_logs USING btree (tracking_id);


--
-- TOC entry 5113 (class 1259 OID 157921)
-- Name: email_subscribers_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_subscribers_email_index ON public.email_subscribers USING btree (email);


--
-- TOC entry 5118 (class 1259 OID 157922)
-- Name: email_subscribers_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_subscribers_status_index ON public.email_subscribers USING btree (status);


--
-- TOC entry 5119 (class 1259 OID 157937)
-- Name: email_templates_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_templates_category_index ON public.email_templates USING btree (category);


--
-- TOC entry 5120 (class 1259 OID 157938)
-- Name: email_templates_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_templates_is_active_index ON public.email_templates USING btree (is_active);


--
-- TOC entry 5268 (class 1259 OID 158640)
-- Name: interview_schedules_job_application_id_interview_stage_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_job_application_id_interview_stage_index ON public.interview_schedules USING btree (job_application_id, interview_stage);


--
-- TOC entry 5271 (class 1259 OID 158795)
-- Name: interview_schedules_recruitment_stage_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_recruitment_stage_id_index ON public.interview_schedules USING btree (recruitment_stage_id);


--
-- TOC entry 5272 (class 1259 OID 158638)
-- Name: interview_schedules_scheduled_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_scheduled_at_index ON public.interview_schedules USING btree (scheduled_at);


--
-- TOC entry 5273 (class 1259 OID 158639)
-- Name: interview_schedules_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interview_schedules_status_index ON public.interview_schedules USING btree (status);


--
-- TOC entry 5013 (class 1259 OID 157423)
-- Name: invoice_items_invoice_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoice_items_invoice_id_index ON public.invoice_items USING btree (invoice_id);


--
-- TOC entry 5005 (class 1259 OID 157404)
-- Name: invoices_invoice_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_invoice_date_index ON public.invoices USING btree (invoice_date);


--
-- TOC entry 5006 (class 1259 OID 157402)
-- Name: invoices_invoice_number_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_invoice_number_index ON public.invoices USING btree (invoice_number);


--
-- TOC entry 5011 (class 1259 OID 157401)
-- Name: invoices_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_project_id_index ON public.invoices USING btree (project_id);


--
-- TOC entry 5012 (class 1259 OID 157403)
-- Name: invoices_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_status_index ON public.invoices USING btree (status);


--
-- TOC entry 5106 (class 1259 OID 157905)
-- Name: job_applications_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_applications_email_index ON public.job_applications USING btree (email);


--
-- TOC entry 5107 (class 1259 OID 157906)
-- Name: job_applications_job_vacancy_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_applications_job_vacancy_id_status_index ON public.job_applications USING btree (job_vacancy_id, status);


--
-- TOC entry 5110 (class 1259 OID 157904)
-- Name: job_applications_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_applications_status_index ON public.job_applications USING btree (status);


--
-- TOC entry 5100 (class 1259 OID 157879)
-- Name: job_vacancies_deadline_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_vacancies_deadline_index ON public.job_vacancies USING btree (deadline);


--
-- TOC entry 5105 (class 1259 OID 157878)
-- Name: job_vacancies_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_vacancies_status_index ON public.job_vacancies USING btree (status);


--
-- TOC entry 4937 (class 1259 OID 156940)
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- TOC entry 5197 (class 1259 OID 158821)
-- Name: kbli_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_category_index ON public.kbli USING btree (category);


--
-- TOC entry 5198 (class 1259 OID 158327)
-- Name: kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_code_index ON public.kbli USING btree (code);


--
-- TOC entry 5201 (class 1259 OID 158820)
-- Name: kbli_complexity_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_complexity_level_index ON public.kbli USING btree (complexity_level);


--
-- TOC entry 5202 (class 1259 OID 158330)
-- Name: kbli_description_fulltext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_description_fulltext ON public.kbli USING btree (to_tsvector('indonesian'::regconfig, description));


--
-- TOC entry 5203 (class 1259 OID 158818)
-- Name: kbli_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_is_active_index ON public.kbli USING btree (is_active);


--
-- TOC entry 5209 (class 1259 OID 158344)
-- Name: kbli_permit_recommendations_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_permit_recommendations_expires_at_index ON public.kbli_permit_recommendations USING btree (expires_at);


--
-- TOC entry 5210 (class 1259 OID 158343)
-- Name: kbli_permit_recommendations_kbli_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_permit_recommendations_kbli_code_index ON public.kbli_permit_recommendations USING btree (kbli_code);


--
-- TOC entry 5213 (class 1259 OID 158345)
-- Name: kbli_recommendations_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_recommendations_unique ON public.kbli_permit_recommendations USING btree (kbli_code, business_scale, location_type);


--
-- TOC entry 5206 (class 1259 OID 158822)
-- Name: kbli_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_search_idx ON public.kbli USING gin (to_tsvector('indonesian'::regconfig, (((((((code)::text || ' '::text) || description) || ' '::text) || COALESCE(activities, ''::text)) || ' '::text) || (COALESCE(category, ''::character varying))::text)));


--
-- TOC entry 5207 (class 1259 OID 158328)
-- Name: kbli_sector_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_sector_index ON public.kbli USING btree (sector);


--
-- TOC entry 5208 (class 1259 OID 158819)
-- Name: kbli_usage_count_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kbli_usage_count_index ON public.kbli USING btree (usage_count);


--
-- TOC entry 5303 (class 1259 OID 158811)
-- Name: kblis_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kblis_category_index ON public.kblis USING btree (category);


--
-- TOC entry 5306 (class 1259 OID 158812)
-- Name: kblis_complexity_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kblis_complexity_level_index ON public.kblis USING btree (complexity_level);


--
-- TOC entry 5307 (class 1259 OID 158813)
-- Name: kblis_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kblis_is_active_index ON public.kblis USING btree (is_active);


--
-- TOC entry 5362 (class 1259 OID 159079)
-- Name: keyword_clusters_language_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_language_status_index ON public.keyword_clusters USING btree (language, status);


--
-- TOC entry 5365 (class 1259 OID 159082)
-- Name: keyword_clusters_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_priority_index ON public.keyword_clusters USING btree (priority);


--
-- TOC entry 5366 (class 1259 OID 159081)
-- Name: keyword_clusters_search_intent_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_search_intent_index ON public.keyword_clusters USING btree (search_intent);


--
-- TOC entry 5367 (class 1259 OID 159080)
-- Name: keyword_clusters_service_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_clusters_service_slug_index ON public.keyword_clusters USING btree (service_slug);


--
-- TOC entry 5416 (class 1259 OID 159304)
-- Name: keyword_position_history_keyword_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_keyword_index ON public.keyword_position_history USING btree (keyword);


--
-- TOC entry 5417 (class 1259 OID 159307)
-- Name: keyword_position_history_keyword_tracked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_keyword_tracked_at_index ON public.keyword_position_history USING btree (keyword, tracked_at);


--
-- TOC entry 5420 (class 1259 OID 159308)
-- Name: keyword_position_history_position_change_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_position_change_index ON public.keyword_position_history USING btree (position_change);


--
-- TOC entry 5421 (class 1259 OID 159305)
-- Name: keyword_position_history_position_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_position_index ON public.keyword_position_history USING btree ("position");


--
-- TOC entry 5422 (class 1259 OID 159306)
-- Name: keyword_position_history_tracked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keyword_position_history_tracked_at_index ON public.keyword_position_history USING btree (tracked_at);


--
-- TOC entry 5398 (class 1259 OID 159217)
-- Name: meta_ab_tests_article_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_ab_tests_article_id_status_index ON public.meta_ab_tests USING btree (article_id, status);


--
-- TOC entry 5182 (class 1259 OID 158247)
-- Name: notifications_notifiable_type_notifiable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_notifiable_type_notifiable_id_index ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- TOC entry 5185 (class 1259 OID 158248)
-- Name: notifications_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_read_at_index ON public.notifications USING btree (read_at);


--
-- TOC entry 5186 (class 1259 OID 158249)
-- Name: notifications_related_type_related_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_related_type_related_id_index ON public.notifications USING btree (related_type, related_id);


--
-- TOC entry 5016 (class 1259 OID 158610)
-- Name: payment_schedules_cash_account_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_cash_account_id_index ON public.payment_schedules USING btree (cash_account_id);


--
-- TOC entry 5017 (class 1259 OID 157448)
-- Name: payment_schedules_due_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_due_date_index ON public.payment_schedules USING btree (due_date);


--
-- TOC entry 5018 (class 1259 OID 157446)
-- Name: payment_schedules_invoice_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_invoice_id_index ON public.payment_schedules USING btree (invoice_id);


--
-- TOC entry 5021 (class 1259 OID 157445)
-- Name: payment_schedules_project_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_project_id_index ON public.payment_schedules USING btree (project_id);


--
-- TOC entry 5022 (class 1259 OID 157447)
-- Name: payment_schedules_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_schedules_status_index ON public.payment_schedules USING btree (status);


--
-- TOC entry 5187 (class 1259 OID 158279)
-- Name: payments_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_client_id_index ON public.payments USING btree (client_id);


--
-- TOC entry 5188 (class 1259 OID 158278)
-- Name: payments_payable_type_payable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_payable_type_payable_id_index ON public.payments USING btree (payable_type, payable_id);


--
-- TOC entry 5193 (class 1259 OID 158280)
-- Name: payments_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_status_index ON public.payments USING btree (status);


--
-- TOC entry 5163 (class 1259 OID 158532)
-- Name: permit_applications_client_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_applications_client_id_status_index ON public.permit_applications USING btree (client_id, status);


--
-- TOC entry 5166 (class 1259 OID 158161)
-- Name: permit_applications_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_applications_status_index ON public.permit_applications USING btree (status);


--
-- TOC entry 5167 (class 1259 OID 158162)
-- Name: permit_applications_submitted_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_applications_submitted_at_index ON public.permit_applications USING btree (submitted_at);


--
-- TOC entry 5025 (class 1259 OID 157468)
-- Name: permit_documents_project_permit_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_documents_project_permit_id_index ON public.permit_documents USING btree (project_permit_id);


--
-- TOC entry 4995 (class 1259 OID 157307)
-- Name: permit_template_dependencies_template_id_permit_item_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_template_dependencies_template_id_permit_item_id_index ON public.permit_template_dependencies USING btree (template_id, permit_item_id);


--
-- TOC entry 4992 (class 1259 OID 157280)
-- Name: permit_template_items_template_id_sequence_order_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_template_items_template_id_sequence_order_index ON public.permit_template_items USING btree (template_id, sequence_order);


--
-- TOC entry 4986 (class 1259 OID 157257)
-- Name: permit_templates_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_templates_category_index ON public.permit_templates USING btree (category);


--
-- TOC entry 4987 (class 1259 OID 157258)
-- Name: permit_templates_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_templates_is_public_index ON public.permit_templates USING btree (is_public);


--
-- TOC entry 4980 (class 1259 OID 157237)
-- Name: permit_types_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_types_category_index ON public.permit_types USING btree (category);


--
-- TOC entry 4983 (class 1259 OID 157238)
-- Name: permit_types_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permit_types_is_active_index ON public.permit_types USING btree (is_active);


--
-- TOC entry 4976 (class 1259 OID 157215)
-- Name: project_expenses_expense_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_expenses_expense_date_index ON public.project_expenses USING btree (expense_date);


--
-- TOC entry 4979 (class 1259 OID 157214)
-- Name: project_expenses_project_id_expense_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_expenses_project_id_expense_date_index ON public.project_expenses USING btree (project_id, expense_date);


--
-- TOC entry 4964 (class 1259 OID 157112)
-- Name: project_logs_entity_type_entity_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_logs_entity_type_entity_id_index ON public.project_logs USING btree (entity_type, entity_id);


--
-- TOC entry 4967 (class 1259 OID 157110)
-- Name: project_logs_project_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_logs_project_id_created_at_index ON public.project_logs USING btree (project_id, created_at);


--
-- TOC entry 4968 (class 1259 OID 157128)
-- Name: project_logs_user_id_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_logs_user_id_action_index ON public.project_logs USING btree (user_id, action);


--
-- TOC entry 4972 (class 1259 OID 157185)
-- Name: project_payments_payment_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_payments_payment_date_index ON public.project_payments USING btree (payment_date);


--
-- TOC entry 4975 (class 1259 OID 158575)
-- Name: project_payments_project_id_payment_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_payments_project_id_payment_date_index ON public.project_payments USING btree (project_id, payment_date);


--
-- TOC entry 5004 (class 1259 OID 157376)
-- Name: project_permit_dependencies_project_permit_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_permit_dependencies_project_permit_id_index ON public.project_permit_dependencies USING btree (project_permit_id);


--
-- TOC entry 4998 (class 1259 OID 157342)
-- Name: project_permits_project_id_sequence_order_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_permits_project_id_sequence_order_index ON public.project_permits USING btree (project_id, sequence_order);


--
-- TOC entry 4999 (class 1259 OID 157343)
-- Name: project_permits_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_permits_status_index ON public.project_permits USING btree (status);


--
-- TOC entry 4950 (class 1259 OID 157496)
-- Name: projects_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_client_id_index ON public.projects USING btree (client_id);


--
-- TOC entry 5224 (class 1259 OID 158390)
-- Name: push_subscriptions_subscribable_type_subscribable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subscriptions_subscribable_type_subscribable_id_index ON public.push_subscriptions USING btree (subscribable_type, subscribable_id);


--
-- TOC entry 5242 (class 1259 OID 158495)
-- Name: quotation_items_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_application_id_index ON public.quotation_items USING btree (application_id);


--
-- TOC entry 5243 (class 1259 OID 158497)
-- Name: quotation_items_item_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_item_type_index ON public.quotation_items USING btree (item_type);


--
-- TOC entry 5244 (class 1259 OID 158498)
-- Name: quotation_items_permit_type_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_permit_type_id_index ON public.quotation_items USING btree (permit_type_id);


--
-- TOC entry 5247 (class 1259 OID 158496)
-- Name: quotation_items_revision_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotation_items_revision_id_index ON public.quotation_items USING btree (revision_id);


--
-- TOC entry 5172 (class 1259 OID 158217)
-- Name: quotations_application_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotations_application_id_status_index ON public.quotations USING btree (application_id, status);


--
-- TOC entry 5173 (class 1259 OID 158218)
-- Name: quotations_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotations_client_id_index ON public.quotations USING btree (client_id);


--
-- TOC entry 5423 (class 1259 OID 159325)
-- Name: ranking_alerts_alert_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_alert_type_index ON public.ranking_alerts USING btree (alert_type);


--
-- TOC entry 5424 (class 1259 OID 159328)
-- Name: ranking_alerts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_created_at_index ON public.ranking_alerts USING btree (created_at);


--
-- TOC entry 5425 (class 1259 OID 159327)
-- Name: ranking_alerts_is_read_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_is_read_index ON public.ranking_alerts USING btree (is_read);


--
-- TOC entry 5428 (class 1259 OID 159326)
-- Name: ranking_alerts_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ranking_alerts_severity_index ON public.ranking_alerts USING btree (severity);


--
-- TOC entry 5281 (class 1259 OID 158698)
-- Name: recruitment_stages_job_application_id_stage_order_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recruitment_stages_job_application_id_stage_order_index ON public.recruitment_stages USING btree (job_application_id, stage_order);


--
-- TOC entry 5284 (class 1259 OID 158699)
-- Name: recruitment_stages_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recruitment_stages_status_index ON public.recruitment_stages USING btree (status);


--
-- TOC entry 5401 (class 1259 OID 159233)
-- Name: search_console_data_page_url_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_console_data_page_url_date_index ON public.search_console_data USING btree (page_url, date);


--
-- TOC entry 5406 (class 1259 OID 159234)
-- Name: search_console_data_query_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX search_console_data_query_date_index ON public.search_console_data USING btree (query, date);


--
-- TOC entry 5387 (class 1259 OID 159168)
-- Name: seo_reports_period_period_start_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seo_reports_period_period_start_index ON public.seo_reports USING btree (period, period_start);


--
-- TOC entry 5253 (class 1259 OID 158568)
-- Name: service_inquiries_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_created_at_index ON public.service_inquiries USING btree (created_at);


--
-- TOC entry 5254 (class 1259 OID 158572)
-- Name: service_inquiries_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_email_index ON public.service_inquiries USING btree (email);


--
-- TOC entry 5259 (class 1259 OID 158574)
-- Name: service_inquiries_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_priority_index ON public.service_inquiries USING btree (priority);


--
-- TOC entry 5260 (class 1259 OID 158573)
-- Name: service_inquiries_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_status_index ON public.service_inquiries USING btree (status);


--
-- TOC entry 5261 (class 1259 OID 158569)
-- Name: service_inquiries_status_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_inquiries_status_priority_index ON public.service_inquiries USING btree (status, priority);


--
-- TOC entry 4927 (class 1259 OID 156916)
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- TOC entry 4930 (class 1259 OID 156915)
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- TOC entry 5407 (class 1259 OID 159259)
-- Name: shapefile_projects_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shapefile_projects_email_index ON public.shapefile_projects USING btree (email);


--
-- TOC entry 5410 (class 1259 OID 159253)
-- Name: shapefile_projects_session_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shapefile_projects_session_token_index ON public.shapefile_projects USING btree (session_token);


--
-- TOC entry 5411 (class 1259 OID 159290)
-- Name: social_posts_article_id_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_posts_article_id_platform_index ON public.social_posts USING btree (article_id, platform);


--
-- TOC entry 5414 (class 1259 OID 159292)
-- Name: social_posts_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_posts_platform_index ON public.social_posts USING btree (platform);


--
-- TOC entry 5415 (class 1259 OID 159291)
-- Name: social_posts_status_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_posts_status_scheduled_for_index ON public.social_posts USING btree (status, scheduled_for);


--
-- TOC entry 4953 (class 1259 OID 157051)
-- Name: tasks_assigned_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_assigned_user_id_status_index ON public.tasks USING btree (assigned_user_id, status);


--
-- TOC entry 4954 (class 1259 OID 157052)
-- Name: tasks_due_date_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_due_date_status_index ON public.tasks USING btree (due_date, status);


--
-- TOC entry 4957 (class 1259 OID 157050)
-- Name: tasks_project_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_project_id_status_index ON public.tasks USING btree (project_id, status);


--
-- TOC entry 4958 (class 1259 OID 157474)
-- Name: tasks_project_permit_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_project_permit_id_index ON public.tasks USING btree (project_permit_id);


--
-- TOC entry 5287 (class 1259 OID 158723)
-- Name: technical_test_submissions_job_application_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX technical_test_submissions_job_application_id_index ON public.technical_test_submissions USING btree (job_application_id);


--
-- TOC entry 5290 (class 1259 OID 158722)
-- Name: technical_test_submissions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX technical_test_submissions_status_index ON public.technical_test_submissions USING btree (status);


--
-- TOC entry 5301 (class 1259 OID 158767)
-- Name: test_answers_test_session_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_answers_test_session_id_index ON public.test_answers USING btree (test_session_id);


--
-- TOC entry 5302 (class 1259 OID 158768)
-- Name: test_answers_test_session_id_question_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_answers_test_session_id_question_id_index ON public.test_answers USING btree (test_session_id, question_id);


--
-- TOC entry 5291 (class 1259 OID 158749)
-- Name: test_sessions_job_application_id_test_template_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_job_application_id_test_template_id_index ON public.test_sessions USING btree (job_application_id, test_template_id);


--
-- TOC entry 5294 (class 1259 OID 158789)
-- Name: test_sessions_recruitment_stage_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_recruitment_stage_id_index ON public.test_sessions USING btree (recruitment_stage_id);


--
-- TOC entry 5295 (class 1259 OID 158747)
-- Name: test_sessions_session_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_session_token_index ON public.test_sessions USING btree (session_token);


--
-- TOC entry 5298 (class 1259 OID 158748)
-- Name: test_sessions_status_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_sessions_status_expires_at_index ON public.test_sessions USING btree (status, expires_at);


--
-- TOC entry 5280 (class 1259 OID 158769)
-- Name: test_templates_test_type_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX test_templates_test_type_is_active_index ON public.test_templates USING btree (test_type, is_active);


--
-- TOC entry 5372 (class 1259 OID 159095)
-- Name: topic_clusters_service_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX topic_clusters_service_slug_index ON public.topic_clusters USING btree (service_slug);


--
-- TOC entry 5373 (class 1259 OID 159096)
-- Name: topic_clusters_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX topic_clusters_status_index ON public.topic_clusters USING btree (status);


--
-- TOC entry 5429 (class 1259 OID 159348)
-- Name: trending_topics_category_is_processed_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trending_topics_category_is_processed_index ON public.trending_topics USING btree (category, is_processed);


--
-- TOC entry 5430 (class 1259 OID 159350)
-- Name: trending_topics_discovered_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trending_topics_discovered_at_index ON public.trending_topics USING btree (discovered_at);


--
-- TOC entry 5433 (class 1259 OID 159349)
-- Name: trending_topics_trend_score_is_processed_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trending_topics_trend_score_is_processed_index ON public.trending_topics USING btree (trend_score, is_processed);


--
-- TOC entry 5493 (class 2606 OID 157771)
-- Name: ai_processing_logs ai_processing_logs_document_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_document_id_foreign FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- TOC entry 5494 (class 2606 OID 157786)
-- Name: ai_processing_logs ai_processing_logs_initiated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_initiated_by_foreign FOREIGN KEY (initiated_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5495 (class 2606 OID 157781)
-- Name: ai_processing_logs ai_processing_logs_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5496 (class 2606 OID 157776)
-- Name: ai_processing_logs ai_processing_logs_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_processing_logs
    ADD CONSTRAINT ai_processing_logs_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.document_templates(id) ON DELETE CASCADE;


--
-- TOC entry 5534 (class 2606 OID 158362)
-- Name: ai_query_logs ai_query_logs_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- TOC entry 5568 (class 2606 OID 158909)
-- Name: ai_setting_history ai_setting_history_changed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history
    ADD CONSTRAINT ai_setting_history_changed_by_foreign FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5569 (class 2606 OID 158904)
-- Name: ai_setting_history ai_setting_history_setting_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_setting_history
    ADD CONSTRAINT ai_setting_history_setting_id_foreign FOREIGN KEY (setting_id) REFERENCES public.ai_settings(id) ON DELETE CASCADE;


--
-- TOC entry 5566 (class 2606 OID 158881)
-- Name: ai_settings ai_settings_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5567 (class 2606 OID 158886)
-- Name: ai_settings ai_settings_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5521 (class 2606 OID 158176)
-- Name: application_documents application_documents_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5522 (class 2606 OID 158291)
-- Name: application_documents application_documents_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5523 (class 2606 OID 158181)
-- Name: application_documents application_documents_verified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_documents
    ADD CONSTRAINT application_documents_verified_by_foreign FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5538 (class 2606 OID 158456)
-- Name: application_legality_documents application_legality_documents_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_legality_documents
    ADD CONSTRAINT application_legality_documents_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5537 (class 2606 OID 158435)
-- Name: application_location_details application_location_details_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_location_details
    ADD CONSTRAINT application_location_details_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5531 (class 2606 OID 158307)
-- Name: application_notes application_notes_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes
    ADD CONSTRAINT application_notes_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5532 (class 2606 OID 158393)
-- Name: application_notes application_notes_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_notes
    ADD CONSTRAINT application_notes_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5535 (class 2606 OID 158411)
-- Name: application_revisions application_revisions_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions
    ADD CONSTRAINT application_revisions_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5536 (class 2606 OID 158416)
-- Name: application_revisions application_revisions_revised_by_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_revisions
    ADD CONSTRAINT application_revisions_revised_by_id_foreign FOREIGN KEY (revised_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5527 (class 2606 OID 158231)
-- Name: application_status_logs application_status_logs_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_status_logs
    ADD CONSTRAINT application_status_logs_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5577 (class 2606 OID 159025)
-- Name: article_topic_similarities article_topic_similarities_topic_a_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_topic_a_id_foreign FOREIGN KEY (topic_a_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- TOC entry 5578 (class 2606 OID 159030)
-- Name: article_topic_similarities article_topic_similarities_topic_b_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topic_similarities
    ADD CONSTRAINT article_topic_similarities_topic_b_id_foreign FOREIGN KEY (topic_b_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- TOC entry 5570 (class 2606 OID 158931)
-- Name: article_topics article_topics_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- TOC entry 5571 (class 2606 OID 159270)
-- Name: article_topics article_topics_topic_cluster_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_topics
    ADD CONSTRAINT article_topics_topic_cluster_id_foreign FOREIGN KEY (topic_cluster_id) REFERENCES public.topic_clusters(id) ON DELETE SET NULL;


--
-- TOC entry 5582 (class 2606 OID 159133)
-- Name: article_view_logs article_view_logs_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.article_view_logs
    ADD CONSTRAINT article_view_logs_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- TOC entry 5490 (class 2606 OID 157656)
-- Name: articles articles_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5491 (class 2606 OID 159265)
-- Name: articles articles_topic_cluster_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_topic_cluster_id_foreign FOREIGN KEY (topic_cluster_id) REFERENCES public.topic_clusters(id) ON DELETE SET NULL;


--
-- TOC entry 5574 (class 2606 OID 159006)
-- Name: auto_post_logs auto_post_logs_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- TOC entry 5575 (class 2606 OID 159001)
-- Name: auto_post_logs auto_post_logs_schedule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_schedule_id_foreign FOREIGN KEY (schedule_id) REFERENCES public.auto_post_schedules(id) ON DELETE SET NULL;


--
-- TOC entry 5576 (class 2606 OID 159011)
-- Name: auto_post_logs auto_post_logs_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_logs
    ADD CONSTRAINT auto_post_logs_topic_id_foreign FOREIGN KEY (topic_id) REFERENCES public.article_topics(id) ON DELETE SET NULL;


--
-- TOC entry 5572 (class 2606 OID 159260)
-- Name: auto_post_schedules auto_post_schedules_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules
    ADD CONSTRAINT auto_post_schedules_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- TOC entry 5573 (class 2606 OID 158983)
-- Name: auto_post_schedules auto_post_schedules_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_post_schedules
    ADD CONSTRAINT auto_post_schedules_topic_id_foreign FOREIGN KEY (topic_id) REFERENCES public.article_topics(id) ON DELETE CASCADE;


--
-- TOC entry 5485 (class 2606 OID 157593)
-- Name: bank_reconciliations bank_reconciliations_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5486 (class 2606 OID 157578)
-- Name: bank_reconciliations bank_reconciliations_cash_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_cash_account_id_foreign FOREIGN KEY (cash_account_id) REFERENCES public.cash_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 5487 (class 2606 OID 157583)
-- Name: bank_reconciliations bank_reconciliations_reconciled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_reconciled_by_foreign FOREIGN KEY (reconciled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5488 (class 2606 OID 157588)
-- Name: bank_reconciliations bank_reconciliations_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5489 (class 2606 OID 157616)
-- Name: bank_statement_entries bank_statement_entries_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_entries
    ADD CONSTRAINT bank_statement_entries_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE CASCADE;


--
-- TOC entry 5542 (class 2606 OID 158518)
-- Name: business_contexts business_contexts_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts
    ADD CONSTRAINT business_contexts_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- TOC entry 5543 (class 2606 OID 158523)
-- Name: business_contexts business_contexts_kbli_code_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_contexts
    ADD CONSTRAINT business_contexts_kbli_code_foreign FOREIGN KEY (kbli_code) REFERENCES public.kbli(code) ON DELETE CASCADE;


--
-- TOC entry 5547 (class 2606 OID 158591)
-- Name: cash_account_balance_history cash_account_balance_history_cash_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history
    ADD CONSTRAINT cash_account_balance_history_cash_account_id_foreign FOREIGN KEY (cash_account_id) REFERENCES public.cash_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 5548 (class 2606 OID 158596)
-- Name: cash_account_balance_history cash_account_balance_history_changed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_account_balance_history
    ADD CONSTRAINT cash_account_balance_history_changed_by_foreign FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5502 (class 2606 OID 157853)
-- Name: compliance_checks compliance_checks_draft_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_draft_id_foreign FOREIGN KEY (draft_id) REFERENCES public.document_drafts(id) ON DELETE CASCADE;


--
-- TOC entry 5563 (class 2606 OID 158853)
-- Name: consult_requests consult_requests_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- TOC entry 5564 (class 2606 OID 158843)
-- Name: consult_requests consult_requests_kbli_code_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_kbli_code_foreign FOREIGN KEY (kbli_code) REFERENCES public.kbli(code) ON DELETE RESTRICT;


--
-- TOC entry 5565 (class 2606 OID 158848)
-- Name: consult_requests consult_requests_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_requests
    ADD CONSTRAINT consult_requests_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5580 (class 2606 OID 159112)
-- Name: content_gaps content_gaps_article_topic_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps
    ADD CONSTRAINT content_gaps_article_topic_id_foreign FOREIGN KEY (article_topic_id) REFERENCES public.article_topics(id) ON DELETE SET NULL;


--
-- TOC entry 5581 (class 2606 OID 159117)
-- Name: content_gaps content_gaps_topic_cluster_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_gaps
    ADD CONSTRAINT content_gaps_topic_cluster_id_foreign FOREIGN KEY (topic_cluster_id) REFERENCES public.topic_clusters(id) ON DELETE SET NULL;


--
-- TOC entry 5584 (class 2606 OID 159180)
-- Name: content_refresh_logs content_refresh_logs_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_refresh_logs
    ADD CONSTRAINT content_refresh_logs_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- TOC entry 5579 (class 2606 OID 159050)
-- Name: content_syndications content_syndications_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_syndications
    ADD CONSTRAINT content_syndications_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- TOC entry 5497 (class 2606 OID 157815)
-- Name: document_drafts document_drafts_ai_log_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_ai_log_id_foreign FOREIGN KEY (ai_log_id) REFERENCES public.ai_processing_logs(id) ON DELETE CASCADE;


--
-- TOC entry 5498 (class 2606 OID 157825)
-- Name: document_drafts document_drafts_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5499 (class 2606 OID 157820)
-- Name: document_drafts document_drafts_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5500 (class 2606 OID 157805)
-- Name: document_drafts document_drafts_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5501 (class 2606 OID 157810)
-- Name: document_drafts document_drafts_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_drafts
    ADD CONSTRAINT document_drafts_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.document_templates(id) ON DELETE CASCADE;


--
-- TOC entry 5492 (class 2606 OID 157752)
-- Name: document_templates document_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- TOC entry 5444 (class 2606 OID 157078)
-- Name: documents documents_parent_document_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_parent_document_id_foreign FOREIGN KEY (parent_document_id) REFERENCES public.documents(id);


--
-- TOC entry 5445 (class 2606 OID 157068)
-- Name: documents documents_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5446 (class 2606 OID 157073)
-- Name: documents documents_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- TOC entry 5447 (class 2606 OID 157083)
-- Name: documents documents_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- TOC entry 5513 (class 2606 OID 158082)
-- Name: email_assignments email_assignments_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- TOC entry 5514 (class 2606 OID 158072)
-- Name: email_assignments email_assignments_email_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_email_account_id_foreign FOREIGN KEY (email_account_id) REFERENCES public.email_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 5515 (class 2606 OID 158077)
-- Name: email_assignments email_assignments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_assignments
    ADD CONSTRAINT email_assignments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5505 (class 2606 OID 157963)
-- Name: email_campaigns email_campaigns_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5506 (class 2606 OID 157958)
-- Name: email_campaigns email_campaigns_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.email_templates(id) ON DELETE SET NULL;


--
-- TOC entry 5509 (class 2606 OID 158017)
-- Name: email_inbox email_inbox_assigned_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_assigned_to_foreign FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5510 (class 2606 OID 158091)
-- Name: email_inbox email_inbox_email_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_email_account_id_foreign FOREIGN KEY (email_account_id) REFERENCES public.email_accounts(id) ON DELETE SET NULL;


--
-- TOC entry 5511 (class 2606 OID 158101)
-- Name: email_inbox email_inbox_handled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_handled_by_foreign FOREIGN KEY (handled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5512 (class 2606 OID 158012)
-- Name: email_inbox email_inbox_replied_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbox
    ADD CONSTRAINT email_inbox_replied_to_foreign FOREIGN KEY (replied_to) REFERENCES public.email_inbox(id) ON DELETE SET NULL;


--
-- TOC entry 5507 (class 2606 OID 157982)
-- Name: email_logs email_logs_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_campaign_id_foreign FOREIGN KEY (campaign_id) REFERENCES public.email_campaigns(id) ON DELETE CASCADE;


--
-- TOC entry 5508 (class 2606 OID 157987)
-- Name: email_logs email_logs_subscriber_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_subscriber_id_foreign FOREIGN KEY (subscriber_id) REFERENCES public.email_subscribers(id) ON DELETE CASCADE;


--
-- TOC entry 5552 (class 2606 OID 158651)
-- Name: interview_feedback interview_feedback_interview_schedule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT interview_feedback_interview_schedule_id_foreign FOREIGN KEY (interview_schedule_id) REFERENCES public.interview_schedules(id) ON DELETE CASCADE;


--
-- TOC entry 5553 (class 2606 OID 158656)
-- Name: interview_feedback interview_feedback_interviewer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_feedback
    ADD CONSTRAINT interview_feedback_interviewer_id_foreign FOREIGN KEY (interviewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5549 (class 2606 OID 158633)
-- Name: interview_schedules interview_schedules_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5550 (class 2606 OID 158628)
-- Name: interview_schedules interview_schedules_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5551 (class 2606 OID 158790)
-- Name: interview_schedules interview_schedules_recruitment_stage_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_schedules
    ADD CONSTRAINT interview_schedules_recruitment_stage_id_foreign FOREIGN KEY (recruitment_stage_id) REFERENCES public.recruitment_stages(id) ON DELETE SET NULL;


--
-- TOC entry 5476 (class 2606 OID 157418)
-- Name: invoice_items invoice_items_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- TOC entry 5475 (class 2606 OID 157396)
-- Name: invoices invoices_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5503 (class 2606 OID 157894)
-- Name: job_applications job_applications_job_vacancy_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_job_vacancy_id_foreign FOREIGN KEY (job_vacancy_id) REFERENCES public.job_vacancies(id) ON DELETE CASCADE;


--
-- TOC entry 5504 (class 2606 OID 157899)
-- Name: job_applications job_applications_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- TOC entry 5533 (class 2606 OID 158346)
-- Name: kbli_permit_recommendations kbli_permit_recommendations_kbli_code_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kbli_permit_recommendations
    ADD CONSTRAINT kbli_permit_recommendations_kbli_code_foreign FOREIGN KEY (kbli_code) REFERENCES public.kbli(code) ON DELETE CASCADE;


--
-- TOC entry 5585 (class 2606 OID 159212)
-- Name: meta_ab_tests meta_ab_tests_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_ab_tests
    ADD CONSTRAINT meta_ab_tests_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- TOC entry 5477 (class 2606 OID 158605)
-- Name: payment_schedules payment_schedules_cash_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_cash_account_id_foreign FOREIGN KEY (cash_account_id) REFERENCES public.cash_accounts(id) ON DELETE SET NULL;


--
-- TOC entry 5478 (class 2606 OID 157440)
-- Name: payment_schedules payment_schedules_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- TOC entry 5479 (class 2606 OID 157435)
-- Name: payment_schedules payment_schedules_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5480 (class 2606 OID 157637)
-- Name: payment_schedules payment_schedules_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_schedules
    ADD CONSTRAINT payment_schedules_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE SET NULL;


--
-- TOC entry 5528 (class 2606 OID 158263)
-- Name: payments payments_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- TOC entry 5529 (class 2606 OID 158268)
-- Name: payments payments_quotation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_quotation_id_foreign FOREIGN KEY (quotation_id) REFERENCES public.quotations(id) ON DELETE SET NULL;


--
-- TOC entry 5530 (class 2606 OID 158273)
-- Name: payments payments_verified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_verified_by_foreign FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5483 (class 2606 OID 157548)
-- Name: permission_role permission_role_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 5484 (class 2606 OID 157543)
-- Name: permission_role permission_role_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 5516 (class 2606 OID 158371)
-- Name: permit_applications permit_applications_ai_recommendation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_ai_recommendation_id_foreign FOREIGN KEY (ai_recommendation_id) REFERENCES public.kbli_permit_recommendations(id) ON DELETE SET NULL;


--
-- TOC entry 5517 (class 2606 OID 158533)
-- Name: permit_applications permit_applications_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- TOC entry 5518 (class 2606 OID 158376)
-- Name: permit_applications permit_applications_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5519 (class 2606 OID 158155)
-- Name: permit_applications permit_applications_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- TOC entry 5520 (class 2606 OID 158150)
-- Name: permit_applications permit_applications_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_applications
    ADD CONSTRAINT permit_applications_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5481 (class 2606 OID 157458)
-- Name: permit_documents permit_documents_project_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents
    ADD CONSTRAINT permit_documents_project_permit_id_foreign FOREIGN KEY (project_permit_id) REFERENCES public.project_permits(id) ON DELETE CASCADE;


--
-- TOC entry 5482 (class 2606 OID 157463)
-- Name: permit_documents permit_documents_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_documents
    ADD CONSTRAINT permit_documents_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5463 (class 2606 OID 157302)
-- Name: permit_template_dependencies permit_template_dependencies_depends_on_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_depends_on_item_id_foreign FOREIGN KEY (depends_on_item_id) REFERENCES public.permit_template_items(id) ON DELETE CASCADE;


--
-- TOC entry 5464 (class 2606 OID 157297)
-- Name: permit_template_dependencies permit_template_dependencies_permit_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_permit_item_id_foreign FOREIGN KEY (permit_item_id) REFERENCES public.permit_template_items(id) ON DELETE CASCADE;


--
-- TOC entry 5465 (class 2606 OID 157292)
-- Name: permit_template_dependencies permit_template_dependencies_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_dependencies
    ADD CONSTRAINT permit_template_dependencies_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.permit_templates(id) ON DELETE CASCADE;


--
-- TOC entry 5461 (class 2606 OID 157275)
-- Name: permit_template_items permit_template_items_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items
    ADD CONSTRAINT permit_template_items_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE SET NULL;


--
-- TOC entry 5462 (class 2606 OID 157270)
-- Name: permit_template_items permit_template_items_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_template_items
    ADD CONSTRAINT permit_template_items_template_id_foreign FOREIGN KEY (template_id) REFERENCES public.permit_templates(id) ON DELETE CASCADE;


--
-- TOC entry 5460 (class 2606 OID 157252)
-- Name: permit_templates permit_templates_created_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_templates
    ADD CONSTRAINT permit_templates_created_by_user_id_foreign FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5459 (class 2606 OID 157232)
-- Name: permit_types permit_types_institution_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permit_types
    ADD CONSTRAINT permit_types_institution_id_foreign FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- TOC entry 5455 (class 2606 OID 157204)
-- Name: project_expenses project_expenses_bank_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_bank_account_id_foreign FOREIGN KEY (bank_account_id) REFERENCES public.cash_accounts(id) ON DELETE SET NULL;


--
-- TOC entry 5456 (class 2606 OID 157209)
-- Name: project_expenses project_expenses_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5457 (class 2606 OID 157199)
-- Name: project_expenses project_expenses_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5458 (class 2606 OID 157631)
-- Name: project_expenses project_expenses_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_expenses
    ADD CONSTRAINT project_expenses_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE SET NULL;


--
-- TOC entry 5448 (class 2606 OID 157100)
-- Name: project_logs project_logs_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs
    ADD CONSTRAINT project_logs_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5449 (class 2606 OID 157129)
-- Name: project_logs project_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_logs
    ADD CONSTRAINT project_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 5450 (class 2606 OID 157174)
-- Name: project_payments project_payments_bank_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_bank_account_id_foreign FOREIGN KEY (bank_account_id) REFERENCES public.cash_accounts(id) ON DELETE SET NULL;


--
-- TOC entry 5451 (class 2606 OID 157179)
-- Name: project_payments project_payments_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5452 (class 2606 OID 157502)
-- Name: project_payments project_payments_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- TOC entry 5453 (class 2606 OID 158576)
-- Name: project_payments project_payments_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- TOC entry 5454 (class 2606 OID 157625)
-- Name: project_payments project_payments_reconciliation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_payments
    ADD CONSTRAINT project_payments_reconciliation_id_foreign FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id) ON DELETE SET NULL;


--
-- TOC entry 5471 (class 2606 OID 157371)
-- Name: project_permit_dependencies project_permit_dependencies_created_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_created_by_user_id_foreign FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5472 (class 2606 OID 157361)
-- Name: project_permit_dependencies project_permit_dependencies_depends_on_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_depends_on_permit_id_foreign FOREIGN KEY (depends_on_permit_id) REFERENCES public.project_permits(id) ON DELETE CASCADE;


--
-- TOC entry 5473 (class 2606 OID 157366)
-- Name: project_permit_dependencies project_permit_dependencies_overridden_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_overridden_by_user_id_foreign FOREIGN KEY (overridden_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5474 (class 2606 OID 157356)
-- Name: project_permit_dependencies project_permit_dependencies_project_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permit_dependencies
    ADD CONSTRAINT project_permit_dependencies_project_permit_id_foreign FOREIGN KEY (project_permit_id) REFERENCES public.project_permits(id) ON DELETE CASCADE;


--
-- TOC entry 5466 (class 2606 OID 157337)
-- Name: project_permits project_permits_assigned_to_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_assigned_to_user_id_foreign FOREIGN KEY (assigned_to_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5467 (class 2606 OID 157332)
-- Name: project_permits project_permits_existing_document_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_existing_document_id_foreign FOREIGN KEY (existing_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- TOC entry 5468 (class 2606 OID 157508)
-- Name: project_permits project_permits_override_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_override_by_user_id_foreign FOREIGN KEY (override_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5469 (class 2606 OID 157327)
-- Name: project_permits project_permits_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE SET NULL;


--
-- TOC entry 5470 (class 2606 OID 157322)
-- Name: project_permits project_permits_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_permits
    ADD CONSTRAINT project_permits_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5435 (class 2606 OID 157491)
-- Name: projects projects_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- TOC entry 5436 (class 2606 OID 157123)
-- Name: projects projects_institution_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_institution_id_foreign FOREIGN KEY (institution_id) REFERENCES public.institutions(id);


--
-- TOC entry 5437 (class 2606 OID 158283)
-- Name: projects projects_permit_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_permit_application_id_foreign FOREIGN KEY (permit_application_id) REFERENCES public.permit_applications(id) ON DELETE SET NULL;


--
-- TOC entry 5438 (class 2606 OID 157118)
-- Name: projects projects_status_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_status_id_foreign FOREIGN KEY (status_id) REFERENCES public.project_statuses(id);


--
-- TOC entry 5539 (class 2606 OID 158480)
-- Name: quotation_items quotation_items_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5540 (class 2606 OID 158490)
-- Name: quotation_items quotation_items_permit_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_permit_type_id_foreign FOREIGN KEY (permit_type_id) REFERENCES public.permit_types(id) ON DELETE SET NULL;


--
-- TOC entry 5541 (class 2606 OID 158485)
-- Name: quotation_items quotation_items_revision_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_revision_id_foreign FOREIGN KEY (revision_id) REFERENCES public.application_revisions(id) ON DELETE CASCADE;


--
-- TOC entry 5524 (class 2606 OID 158202)
-- Name: quotations quotations_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_application_id_foreign FOREIGN KEY (application_id) REFERENCES public.permit_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5525 (class 2606 OID 158207)
-- Name: quotations quotations_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- TOC entry 5526 (class 2606 OID 158212)
-- Name: quotations quotations_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5589 (class 2606 OID 159320)
-- Name: ranking_alerts ranking_alerts_position_history_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranking_alerts
    ADD CONSTRAINT ranking_alerts_position_history_id_foreign FOREIGN KEY (position_history_id) REFERENCES public.keyword_position_history(id) ON DELETE CASCADE;


--
-- TOC entry 5555 (class 2606 OID 158691)
-- Name: recruitment_stages recruitment_stages_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recruitment_stages
    ADD CONSTRAINT recruitment_stages_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5583 (class 2606 OID 159151)
-- Name: seo_scores seo_scores_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_scores
    ADD CONSTRAINT seo_scores_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- TOC entry 5544 (class 2606 OID 158553)
-- Name: service_inquiries service_inquiries_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- TOC entry 5545 (class 2606 OID 158563)
-- Name: service_inquiries service_inquiries_contacted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_contacted_by_foreign FOREIGN KEY (contacted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5546 (class 2606 OID 158558)
-- Name: service_inquiries service_inquiries_converted_to_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_inquiries
    ADD CONSTRAINT service_inquiries_converted_to_application_id_foreign FOREIGN KEY (converted_to_application_id) REFERENCES public.permit_applications(id) ON DELETE SET NULL;


--
-- TOC entry 5586 (class 2606 OID 159254)
-- Name: shapefile_projects shapefile_projects_service_inquiry_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects
    ADD CONSTRAINT shapefile_projects_service_inquiry_id_foreign FOREIGN KEY (service_inquiry_id) REFERENCES public.service_inquiries(id) ON DELETE SET NULL;


--
-- TOC entry 5587 (class 2606 OID 159248)
-- Name: shapefile_projects shapefile_projects_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shapefile_projects
    ADD CONSTRAINT shapefile_projects_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5588 (class 2606 OID 159285)
-- Name: social_posts social_posts_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_posts
    ADD CONSTRAINT social_posts_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- TOC entry 5439 (class 2606 OID 157035)
-- Name: tasks tasks_assigned_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_user_id_foreign FOREIGN KEY (assigned_user_id) REFERENCES public.users(id);


--
-- TOC entry 5440 (class 2606 OID 157045)
-- Name: tasks tasks_depends_on_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_depends_on_task_id_foreign FOREIGN KEY (depends_on_task_id) REFERENCES public.tasks(id);


--
-- TOC entry 5441 (class 2606 OID 157040)
-- Name: tasks tasks_institution_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_institution_id_foreign FOREIGN KEY (institution_id) REFERENCES public.institutions(id);


--
-- TOC entry 5442 (class 2606 OID 157030)
-- Name: tasks tasks_project_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_foreign FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- TOC entry 5443 (class 2606 OID 157469)
-- Name: tasks tasks_project_permit_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_permit_id_foreign FOREIGN KEY (project_permit_id) REFERENCES public.project_permits(id) ON DELETE SET NULL;


--
-- TOC entry 5556 (class 2606 OID 158712)
-- Name: technical_test_submissions technical_test_submissions_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions
    ADD CONSTRAINT technical_test_submissions_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5557 (class 2606 OID 158717)
-- Name: technical_test_submissions technical_test_submissions_reviewer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_test_submissions
    ADD CONSTRAINT technical_test_submissions_reviewer_id_foreign FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5562 (class 2606 OID 158762)
-- Name: test_answers test_answers_test_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_answers
    ADD CONSTRAINT test_answers_test_session_id_foreign FOREIGN KEY (test_session_id) REFERENCES public.test_sessions(id) ON DELETE CASCADE;


--
-- TOC entry 5558 (class 2606 OID 158778)
-- Name: test_sessions test_sessions_evaluator_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_evaluator_id_foreign FOREIGN KEY (evaluator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5559 (class 2606 OID 158737)
-- Name: test_sessions test_sessions_job_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_job_application_id_foreign FOREIGN KEY (job_application_id) REFERENCES public.job_applications(id) ON DELETE CASCADE;


--
-- TOC entry 5560 (class 2606 OID 158784)
-- Name: test_sessions test_sessions_recruitment_stage_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_recruitment_stage_id_foreign FOREIGN KEY (recruitment_stage_id) REFERENCES public.recruitment_stages(id) ON DELETE SET NULL;


--
-- TOC entry 5561 (class 2606 OID 158742)
-- Name: test_sessions test_sessions_test_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_sessions
    ADD CONSTRAINT test_sessions_test_template_id_foreign FOREIGN KEY (test_template_id) REFERENCES public.test_templates(id) ON DELETE CASCADE;


--
-- TOC entry 5554 (class 2606 OID 158674)
-- Name: test_templates test_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_templates
    ADD CONSTRAINT test_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5590 (class 2606 OID 159343)
-- Name: trending_topics trending_topics_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trending_topics
    ADD CONSTRAINT trending_topics_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE SET NULL;


--
-- TOC entry 5434 (class 2606 OID 157667)
-- Name: users users_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


-- Completed on 2026-04-15 05:10:13 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict ZGpW4VBCicKwRCdhOEFSI7OEERA1wuoaLndHihDFhmsZjLD5f42iXvhcdwjIKXZ

